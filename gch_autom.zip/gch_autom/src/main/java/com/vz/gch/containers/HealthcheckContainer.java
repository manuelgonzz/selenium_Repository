package com.vz.gch.containers;

import java.io.IOException;
import java.util.HashMap;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.vz.gch.views.CommonFunctions;
import com.vz.gch.views.HealthcheckView;

public class HealthcheckContainer {
	
	private WebDriver driver;
	public Actions action;
	
	public HealthcheckContainer(WebDriver driver)
	{
		this.driver = driver;
	}
	
	

	
	public void waitForElement(Integer timeout, String ElementString, String Type) throws IOException{
		CommonFunctions.isElementPresent(driver, timeout, ElementString, Type);
	}
	
	public WebElement getLittleArrowCLE()
	{
		return driver.findElement(By.xpath("//td[2]/div/div/a"));
	}

	public WebElement getViewProfileOption()
	{
		return driver.findElement(By.xpath("//td[2]/div/div[2]/div/a"));
	}
	
	public WebElement getCustomerContactTab()
	{
		return driver.findElement(By.xpath("//td[3]/table/tbody/tr[2]/td[2]/a/div/table/tbody/tr/td"));
	}
	
	public WebElement getCreateCPNIButton()
	{
		return driver.findElement(By.xpath("//a[contains(text(),'Create')]"));
	}
	
	public WebElement getCreateCPNIFirstNameTextBox(){
		return driver.findElement(By.xpath("//td[3]/input"));
	}
	
	public WebElement getCreateCPNILastNameTextBox(){
		return driver.findElement(By.xpath("//tr[3]/td[3]/input"));
	}
	
	public WebElement getCreateCPNIRoleDropDown(){
		return driver.findElement(By.xpath("//td[3]/select"));
	}
	
	public WebElement getCreateCPNITitleTexBox(){
		return driver.findElement(By.xpath("//tr[5]/td[3]/input"));
	}
	
	public WebElement getCreateCPNIEmailTexBox(){
		return driver.findElement(By.xpath("//tr[6]/td[3]/input"));
	}
	
	public WebElement getCreateCPNIWorkPhoneTexBox(){
		return driver.findElement(By.xpath("//td[4]/input"));
	}
	
	public WebElement getCreateCPNIAddressL1TexBox(){
		return driver.findElement(By.xpath("//td[2]/table/tbody/tr/td[3]/input"));
	}
	
	public WebElement getCreateCPNIAddressL2TexBox(){
		return driver.findElement(By.xpath("//td[2]/table/tbody/tr[2]/td[3]/input"));
	}
	
	public WebElement getCreateCPNIAddressL3TexBox(){
		return driver.findElement(By.xpath("//td[2]/table/tbody/tr[3]/td[3]/input"));
	}
	
	public WebElement getCreateCPNICityTexBox(){
		return driver.findElement(By.xpath("//tr[4]/td[3]/input"));
	}
	
	public WebElement getCreateCPNICountryDropDown(){
		return driver.findElement(By.xpath("//tr[5]/td[3]/select"));
	}
	
	public WebElement getCreateCPNIStateDropDown(){
		return driver.findElement(By.xpath("//div/select"));
	}
	
	public WebElement getCreateCPNIZipTextBox(){
		return driver.findElement(By.xpath("//tr[7]/td[3]/input"));
	}
	
	public WebElement getCreateCPNIWorkPhone(){
		return driver.findElement(By.xpath("//td[4]/input"));
	}
	
	public WebElement getCreateCPNISubmitCreateButton(){
		return driver.findElement(By.xpath("//div[3]/div[2]/a"));
	}
	
	public WebElement getCreateCPNIAddressConfirmButton(){
		return driver.findElement(By.xpath("//div[2]/div/a"));
	}
	
	public WebElement getCreateCPNISaveChangesButton(){
		return driver.findElement(By.xpath("//a[contains(text(),'Save')]"));
	}
	
	public WebElement getCreateCPNIProcessSucessfullLabel(){
		return driver.findElement(By.xpath("//div[2]/table/tbody/tr/td/span"));
	}

	public WebElement getRequestInquiryOption()
	{
		return driver.findElement(By.linkText("Request Inquiry"));
	}
	
	public WebElement getRequestInquiryDescriptionBox()
	{
		return driver.findElement(By.xpath("//textarea"));
	}
	
	public WebElement getRequestInquirySendButton()
	{
		return driver.findElement(By.xpath("//td/div/div[2]/a"));
	}
	
	public WebElement getRequestInquiryOpSuccessfull()
	{
		return driver.findElement(By.cssSelector("span.iceMsgsInfo.confirmMsg"));
	}
	
	public WebElement getSingleSearchPortal()
	{
		return driver.findElement(By.cssSelector("div.verizonLogo"));
	}
	
	public WebElement getSingleSearchBar()
	{
		return driver.findElement(By.cssSelector("#searchInputText"));
	}
	
	public WebElement getSingleSearchButton()
	{
		return driver.findElement(By.xpath("//button"));
	}
	
	public WebElement getSingleSearchCLEInfo()
	{
		return driver.findElement(By.xpath("//p/a/span"));
	}
	
	public WebElement getCustomerHierarchyDropDown(){
		action=new Actions(driver);
		return driver.findElement(By.cssSelector("a[href*='/gch/cle/']"));
	}
	
	public WebElement getCustomerSearchOption()
	{
		return driver.findElement(By.xpath("//a[contains(text(),'Customer Search')]"));
	}
	
	public WebElement getTaxAtrUpdateIcon()
	{
		return driver.findElement(By.xpath("//span[3]/div/div/div[3]/a/img"));
	}
	
	public WebElement getTaxAtrDropDown()
	{
		return driver.findElement(By.xpath("//td[3]/select"));
	}
	public WebElement getTaxAtrTextbox()
	{
		return driver.findElement(By.xpath("//td[3]/input "));
	}
	
	public WebElement getTaxAtrSaveChangesButton()
	{
		return driver.findElement(By.xpath("//a[contains(text(),'Save')]"));
	}
					
	
	//////////////////////////VICTOR MERAN'S PART/////////////////////////
	
	public WebElement getUsernameInputField() {
	      
		return driver.findElement(By.xpath("html/body/div[3]/div/div/section[2]/div[1]/div[2]/article/form/div[1]/input"));
	}
	   
	public WebElement getPasswordInputField() {
	      
		return driver.findElement(By.xpath("html/body/div[3]/div/div/section[2]/div[1]/div[2]/article/form/div[3]/input"));
	}
	   
	public WebElement getLogInButton() {
	      
		return driver.findElement(By.xpath("html/body/div[3]/div/div/section[2]/div[1]/div[2]/article/form/div[5]/a/span"));
	}
	
	public WebElement getCreateLegalEntityButton() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/center/div/a"));
	}
	
	public WebElement getLENameInputField() {
		
		return driver.findElement(By.xpath("//td[3]/input"));
	}
	
	public WebElement getLEAddressLineInputField() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[2]/table/tbody/tr/td/table/tbody/tr/td/div/table[2]/tbody/tr/td[1]/table/tbody/tr[2]/td[3]/input"));
	}
	
	public WebElement getLECityInputField() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[2]/table/tbody/tr/td/table/tbody/tr/td/div/table[2]/tbody/tr/td[1]/table/tbody/tr[5]/td[3]/input"));
	}
	
	public WebElement getLECountryDropdown() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[2]/table/tbody/tr/td/table/tbody/tr/td/div/table[2]/tbody/tr/td[1]/table/tbody/tr[6]/td[3]/select/option[240]"));
	}
	
	public WebElement getLEStateDropdown() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[2]/table/tbody/tr/td/table/tbody/tr/td/div/table[2]/tbody/tr/td[1]/table/tbody/tr[7]/td[3]/select/option[12]"));
	}
	
	public WebElement getLEZIPPostcodeInputField() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[2]/table/tbody/tr/td/table/tbody/tr/td/div/table[2]/tbody/tr/td[1]/table/tbody/tr[8]/td[3]/input"));
	}
	
	public WebElement getLEMainTelephoneNumberInputField() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[2]/table/tbody/tr/td/table/tbody/tr/td/div/table[2]/tbody/tr/td[2]/table/tbody/tr[1]/td[3]/input"));
	}
	
	public WebElement getLECreateButton() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[2]/table/tbody/tr/td/table/tbody/tr/td/div/div[3]/div[2]/a"));
	}
	
	public WebElement getLEYesButton() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[2]/table/tbody/tr/td/table/tbody/tr/td/div/table[3]/tbody/tr[2]/td/center/table/tbody/tr/td[1]/div/a"));
	}

	public WebElement getLEOKButton() {
	
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[2]/table/tbody/tr/td/table/tbody/tr/td/div/center/div/a"));
	}
	   
	public WebElement getCLESearchField() {
	      
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/center/table/tbody/tr[2]/td[1]/input"));
	}
	
	public WebElement getSearchButton() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/center/table/tbody/tr[2]/td[2]/div/a"));
	}
	
	public WebElement getArrowDropdownMenu() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[1]/table/tbody/tr/td[2]/div/table/tbody/tr[1]/td[2]/table/tbody/tr[1]/td[2]/div/div[1]/a"));
	}
	
	public WebElement getRequestLegalNameChange() {
		
		return driver.findElement(By.xpath("//*[text()='Request Legal Name Change']"));
	}
	
	public WebElement getRequestLegalNameChange1LENameInputField() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[1]/div[5]/table/tbody/tr/td/table/tbody/tr[3]/td/div/span/span/table/tbody/tr/td/table/tbody/tr[1]/td[3]/input"));
	}
	
	public WebElement getRequestLegalNameChange1SubmitButton() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[1]/div[5]/table/tbody/tr/td/table/tbody/tr[3]/td/div/div[4]/div[2]/a"));
	}
	
	public WebElement getRequestLegalNameChange1OKButton() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[1]/div[5]/table/tbody/tr/td/table/tbody/tr[3]/td/div/div/center/div/a"));
	}
	
	public WebElement getViewProfile() {
		
		return driver.findElement(By.xpath("//*[text()='View Profile']"));
	}
	
	public WebElement getEntityInformationTab() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[4]/table/tbody/tr[1]/td/table/tbody/tr/td[1]/table/tbody/tr[2]/td[2]/a"));
	}
	
	public WebElement getAddressNameChangeRequest() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[4]/table/tbody/tr[2]/td/div/div/span[1]/span[1]/div/div/div[5]/a/img"));
	}
	
	public WebElement getChangeRequestForName() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[6]/table/tbody/tr/td/table/tbody/tr[3]/td/div/table/tbody/tr/td[2]/select/option[3]"));
	}
	
	public WebElement getUpdateButton() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[6]/table/tbody/tr/td/table/tbody/tr[3]/td/div/div[2]/div[2]/a"));
	}
	
	public WebElement getRequestLegalNameChange2LENameInputField() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[6]/table/tbody/tr/td/table/tbody/tr[3]/td/div/span/span/table/tbody/tr/td/table/tbody/tr[1]/td[3]/input"));
	}
	
	public WebElement getRequestLegalNameChange2SubmitButton() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[6]/table/tbody/tr/td/table/tbody/tr[3]/td/div/div[4]/div[2]/a"));
	}
	
	public WebElement getRequestLegalNameChange2OKButton() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[6]/table/tbody/tr/td/table/tbody/tr[3]/td/div/div/center/div/a"));
	}
	
	public WebElement getRequestLegalAddressChange() {
		
		return driver.findElement(By.xpath("//*[text()='Request Legal Address Change']"));
	}
	
	public WebElement getRequestLegalAddressChangeAddressLine1InputField_1() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[1]/div[5]/table/tbody/tr/td/table/tbody/tr[3]/td/div/span/span/table/tbody/tr/td[1]/table/tbody/tr[1]/td[3]/input"));
	}
	
	public WebElement getRequestLegalAddressChangeCityInputField_1() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[1]/div[5]/table/tbody/tr/td/table/tbody/tr[3]/td/div/span/span/table/tbody/tr/td[1]/table/tbody/tr[4]/td[3]/input"));
	}
	
	public WebElement getRequestLegalAddressChangeCountrySelect_1() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[1]/div[5]/table/tbody/tr/td/table/tbody/tr[3]/td/div/span/span/table/tbody/tr/td[1]/table/tbody/tr[5]/td[3]/select/option[240]"));
	}
	
	public WebElement getRequestLegalAddressChangeStateSelect_1() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[1]/div[5]/table/tbody/tr/td/table/tbody/tr[3]/td/div/span/span/table/tbody/tr/td[1]/table/tbody/tr[6]/td[3]/div/select/option[8]"));
	}
	
	public WebElement getRequestLegalAddressChangeZIPPostCodeInputField_1() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[1]/div[5]/table/tbody/tr/td/table/tbody/tr[3]/td/div/span/span/table/tbody/tr/td[1]/table/tbody/tr[7]/td[3]/input"));
	}
	
	public WebElement getRequestLegalAddressChangeSubmitButton_1() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[1]/div[5]/table/tbody/tr/td/table/tbody/tr[3]/td/div/div[3]/div[2]/a"));
	}
	
	public WebElement getRequestLegalAddressChangeYesButton_1() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[1]/div[5]/table/tbody/tr/td/table/tbody/tr[3]/td/div/table[2]/tbody/tr[2]/td/center/table/tbody/tr/td[1]/div/a"));
	}
	
	public WebElement getRequestLegalAddressChangeOKButton_1() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[1]/div[5]/table/tbody/tr/td/table/tbody/tr[3]/td/div/div/center/div/a"));
	}
	
	public WebElement getChangeRequestForAddress() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[6]/table/tbody/tr/td/table/tbody/tr[3]/td/div/table/tbody/tr/td[2]/select/option[2]"));
	}
	
	public WebElement getRequestLegalAddressChangeAddressLine1InputField_2() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[6]/table/tbody/tr/td/table/tbody/tr[3]/td/div/span/span/table/tbody/tr/td[1]/table/tbody/tr[1]/td[3]/input"));
	}
	
	public WebElement getRequestLegalAddressChangeCityInputField_2() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[6]/table/tbody/tr/td/table/tbody/tr[3]/td/div/span/span/table/tbody/tr/td[1]/table/tbody/tr[4]/td[3]/input"));
	}
	
	public WebElement getRequestLegalAddressChangeCountrySelect_2() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[6]/table/tbody/tr/td/table/tbody/tr[3]/td/div/span/span/table/tbody/tr/td[1]/table/tbody/tr[5]/td[3]/select/option[240]"));
	}
	
	public WebElement getRequestLegalAddressChangeStateSelect_2() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[6]/table/tbody/tr/td/table/tbody/tr[3]/td/div/span/span/table/tbody/tr/td[1]/table/tbody/tr[6]/td[3]/div/select/option[8]"));
	}
	
	public WebElement getRequestLegalAddressChangeZIPPostCodeInputField_2() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[6]/table/tbody/tr/td/table/tbody/tr[3]/td/div/span/span/table/tbody/tr/td[1]/table/tbody/tr[7]/td[3]/input"));
	}
	
	public WebElement getRequestLegalAddressChangeSubmitButton_2() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[6]/table/tbody/tr/td/table/tbody/tr[3]/td/div/div[3]/div[2]/a"));
	}
	
	public WebElement getRequestLegalAddressChangeYesButton_2() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[6]/table/tbody/tr/td/table/tbody/tr[3]/td/div/table[2]/tbody/tr[2]/td/center/table/tbody/tr/td[1]/div/a"));
	}
	
	public WebElement getRequestLegalAddressChangeOKButton_2() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[6]/table/tbody/tr/td/table/tbody/tr[3]/td/div/div/center/div/a"));
	}
	
	public WebElement getRequestInquiry() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[1]/table/tbody/tr/td[2]/div/table/tbody/tr[1]/td[2]/table/tbody/tr[1]/td[2]/div/div[2]/div[6]/a/span"));
	}
	
	public WebElement getDescriptionInputField() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[1]/div[5]/table/tbody/tr/td/table/tbody/tr[4]/td/div/table[3]/tbody/tr/td[2]/span/textarea"));
	}
	
	public WebElement getSendButton() {
		
		return driver.findElement(By.xpath("html/body/form[2]/div[2]/table/tbody/tr/td/div/div[1]/div[5]/table/tbody/tr/td/table/tbody/tr[6]/td/div/div[2]/a"));
	}
	
	/////////////////////////////////////////// JOSE VARGAS' PART//////////////////////////////////////////////////////////
	public WebElement getCLESerachBar(){
		return  driver.findElement( By.id("generalForm:searchInputText"));
	}
	
	public WebElement getCLESubmitButton(){
		return driver.findElement( By.id("generalForm:searchButton"));
	}
	
	public WebElement getFirstArrowMenu(){
		return driver.findElement( By.xpath( "//td[2]/div/div/a" ));
	}
	
	public WebElement getFirstViewProfileMenuItem(){
		return driver.findElement( By.xpath("//span[text()='View Profile'][1]/.."));
	}
	
	
	public WebElement getManageBillingAccount(){
		return driver.findElement( By.xpath("//td[contains(text(),'Manage Billing')]/ancestor::a") );
	}
	
	public WebElement getCreateCustomerGroupButton(){
		return driver.findElement( By.xpath("//a[text()='Create Customer Group']") );
	}
	
	public WebElement getInputForCustomerGroupName(){
		return driver.findElement( By.xpath("//td[2]/input") );
	}
	
	public WebElement getCreateCustomerGroupSubmitButton(){
		return driver.findElement( By.xpath("//a[text()='Submit']"));
	}
	
	public WebElement getCreatedGroupMessage(String createdGroup){
		return driver.findElement( By.xpath( "//span[text()='"+createdGroup+ " created successfully.']" ) );
	}
	
	public WebElement getManageAccountNumbers(){
		return driver.findElement( By.xpath("//td[contains(text(),'Manage Account')]/ancestor::a") );
	}
	
	public WebElement getActionsButtonOnManageAccounts(){
		return driver.findElement( By.xpath("//a[text()='Actions']"));
	}
	
	public WebElement getChangeCustomerGroupID(){
		return driver.findElement( By.xpath("//a[text()='Change Customer Group ID']") );
	}
	
	public WebElement getFirstAccountNumberCheckBox(){
		return driver.findElement( By.xpath("//td/center/input"));
				
	}
	
	public WebElement getFirstCustomerGroupRadioButton(){
		return driver.findElement( By.xpath("//input[@id='generalForm:pnlCustomerSummaryTab:0:manageCGIBANTab:0:customerGroupId:0:cgiSelectRadioButton:_1']") );
	}
	
	public WebElement getMoveNotification(){
		return driver.findElement( By.xpath("//span[contains(text(),'moved to')]"));
	}
	
	public WebElement getUpdateSensitivity(){
		return driver.findElement( By.xpath("//span[text()='Update Sensitivity'][1]/.."));
	}
	
	public Select getGSAMSensitivityDropDown(){
		return new Select( driver.findElement(By.xpath("//select[@id='generalForm:gsamSensUCA']")) );
	}
	
	public Select getGSAMSensitivityCountrySelect(){
		return new Select( driver.findElement( By.xpath("//select[@id='generalForm:upCLECAPAttr_leftList']") ));
	}
	
	public WebElement getAddSelectedSensisitivityItemButton(){
		return driver.findElement( By.xpath("//input[@id='generalForm:upCLECAPAttr_addBtn']") );
	}
	
	public WebElement getSensitivitySaveChangesButton(){
		return driver.findElement( By.xpath("//a[text()='Save Changes']") );
	}
	
	public WebElement getOperationSuccesfulButton(){
		return driver.findElement( By.xpath("//a[text()='Ok']") );
	}
	
	public WebElement getManageServicesButton(){
		return driver.findElement( By.xpath("//td[contains(text(),'Manage Services')]/ancestor::a"));
	}
	
	public WebElement getAddUpdateLocationPONumber(){
		return driver.findElement( By.xpath("//a[contains(text(),'Add/Update')]") );
	}
	
	public WebElement getPONumberUpdateServiceScreen(){
		return driver.findElement( By.xpath("//h1[text()='Purchase Order Number Update - Service']") );
	}
	
	public WebElement getUpdateTaxationAttributesButton(){
		return driver.findElement( By.xpath("//a[@id='generalForm:pnlCustomerSummaryTab:0:j_id2060']") );
	}
	
	public WebElement getTaxationAttributeUpdateCheckBox(){
		return driver.findElement( By.xpath("//input[@name='generalForm:pnlCustomerSummaryTab:0:j_id1153']") );
	}
	
	public WebElement getUpdateConfirmationButton(){
		return driver.findElement( By.xpath("//a[text()='Yes']") );
	}
	
	public WebElement getCheckBoxForTaxationBanPropagation(){
		return driver.findElement( By.xpath("//input[@id='generalForm:pnlCustomerSummaryTab:0:TaxationAttributesBanTaxIdPropagationData:0:j_id2722']"));
	}
	
	public WebElement getBanPropagationConfirmationOKButton(){
		return driver.findElement( By.xpath("//a[text()='OK']") );
	}
	///STRINGS///
	
	public String getLittleArrowCLE_xpath()
	{
		return "//td[2]/div/div/a";
	}

	public String getViewProfileOption_xpath()
	{
		return "//td[2]/div/div[2]/div/a";
	}
	
	public String getCustomerContactTab_xpath()
	{
		return "//td[3]/table/tbody/tr[2]/td[2]/a/div/table/tbody/tr/td";
	}
	
	public String getCreateCPNIButton_xpath()
	{
		return "//a[contains(text(),'Create')]";
	}
	
	public String getCreateCPNIFirstNameTextBox_xpath(){
		return "//td[3]/input";
	}
	
	public String getCreateCPNILastNameTextBox_xpath(){
		return "//tr[3]/td[3]/input";
	}
	
	public String getCreateCPNIRoleDropDown_xpath(){
		return "//td[3]/select";
	}
	
	public String getCreateCPNITitleTexBox_xpath(){
		return "//tr[5]/td[3]/input";
	}
	
	public String getCreateCPNIEmailTexBox_xpath(){
		return "//tr[6]/td[3]/input";
	}
	
	public String getCreateCPNIWorkPhoneTexBox_xpath(){
		return "//td[4]/input";
	}
	
	public String getCreateCPNIAddressL1TexBox_xpath(){
		return "//td[2]/table/tbody/tr/td[3]/input";
	}
	
	public String getCreateCPNIAddressL2TexBox_xpath(){
		return "//td[2]/table/tbody/tr[2]/td[3]/input";
	}
	
	public String getCreateCPNIAddressL3TexBox_xpath(){
		return "//td[2]/table/tbody/tr[3]/td[3]/input";
	}
	
	public String getCreateCPNICityTexBox_xpath(){
		return "//tr[4]/td[3]/input";
	}
	
	public String getCreateCPNICountryDropDown_xpath(){
		return "//tr[5]/td[3]/select";
	}
	
	public String getCreateCPNIStateDropDown_xpath(){
		return "//div/select";
	}
	
	public String getCreateCPNIZipTextBox_xpath(){
		return "//tr[7]/td[3]/input";
	}
	
	public String getCreateCPNIWorkPhone_xpath(){
		return "//td[4]/input";
	}
	
	public String getCreateCPNISubmitCreateButton_xpath(){
		return "//div[3]/div[2]/a";
	}
	
	public String getCreateCPNIAddressConfirmButton_xpath(){
		return "//div[2]/div/a";
	}
	
	public String getCreateCPNISaveChangesButton_xpath(){
		return "//a[contains(text(),'Save')]";
	}
	
	public String getCreateCPNIProcessSucessfullLabel_xpath(){
		return "//div[2]/table/tbody/tr/td/span";
	}
	
	public String getRequestInquiryOption_link()
	{
		return "Request Inquiry";
	}
	
	public String getRequestInquiryDescriptionBox_xpath()
	{
		return "//textarea";
	}
	
	public String getRequestInquirySendButton_xpath()
	{
		return "//td/div/div[2]/a";
	}
	
	public String getRequestInquiryOpSuccessfull_css()
	{
		return "span.iceMsgsInfo.confirmMsg";
	}
	
	public String getSingleSearchPortal_link()
	{
		return "Advanced Search";
	}
	
	public String getSingleSearchBar_css()
	{
		return "#searchInputText";
	}
	
	public String getSingleSearchButton_xpath()
	{
		return "//button";
	}
	
	public String getSingleSearchCLEInfo_xpath()
	{
		return "//p/a/span";
	}
	
	public String getCustomerHierarchyDropDown_css(){
		return "a[href*='/gch/cle/']";
	}
	
	public String getCustomerSearchOption_xpath()
	{
		return "//a[contains(text(),'Customer Search')]";
	}
	
	public String getTaxAtrUpdateIcon_xpath()
	{
		return "//span[3]/div/div/div[3]/a/img";
	}
	
	public String getTaxAtrDropDown_xpath()
	{
		return "//td[3]/select";
	}
	public String getTaxAtrTextbox_xpath()
	{
		return "//td[3]/input ";
	}
	
	public String getTaxAtrSaveChangesButton_xpath()
	{
		return "//a[contains(text(),'Save')]";
	}
	
	public String getTaxAtrModified_xpath()
	{
		return "//*[contains(text(),'"+HealthcheckView.TAX_ID+"')]";
	}
	
	//////////////////////////////////////VICTOR MERAN'S PART/////////////////////////////////////////////////
	public String getLENameInputField_xpath() {
		
		return "//td[3]/input";
	}
	
	public String getRequestLegalNameChange1LENameInputField_xpath() {
		
		return "html/body/form[2]/div[2]/table/tbody/tr/td/div/div[1]/div[5]/table/tbody/tr/td/table/tbody/tr[3]/td/div/span/span/table/tbody/tr/td/table/tbody/tr[1]/td[3]/input";
	}
	
	public String getRequestLegalNameChange1OKButton_xpath() {
		
		return "html/body/form[2]/div[2]/table/tbody/tr/td/div/div[1]/div[5]/table/tbody/tr/td/table/tbody/tr[3]/td/div/div/center/div/a";
	}
	
	public String getChangeRequestForName_xpath() {
		
		return "html/body/form[2]/div[2]/table/tbody/tr/td/div/div[6]/table/tbody/tr/td/table/tbody/tr[3]/td/div/table/tbody/tr/td[2]/select/option[3]";
	}
	
	public String getRequestLegalNameChange2LENameInputField_xpath() {
		
		return "html/body/form[2]/div[2]/table/tbody/tr/td/div/div[6]/table/tbody/tr/td/table/tbody/tr[3]/td/div/span/span/table/tbody/tr/td/table/tbody/tr[1]/td[3]/input";
	}
	
	public String getRequestLegalNameChange2OKButton_xpath() {
		
		return "html/body/form[2]/div[2]/table/tbody/tr/td/div/div[6]/table/tbody/tr/td/table/tbody/tr[3]/td/div/div/center/div/a";
	}	
	
	public String getRequestLegalAddressChangeAddressLine1InputField_1_xpath() {
		
		return "//td[3]/input";
	}
	
	public String getRequestLegalAddressChangeYesButton_1_xpath() {
		
		return "//a[contains(text(),'Yes')]";
	}
	
	public String getRequestLegalAddressChangeOKButton_1_xpath() {
		
		return "//a[contains(text(),'Ok')]";
	}
	
	public String getRequestLegalAddressChangeAddressLine1InputField_2_xpath() {
		
		return "//td[3]/input";
	}
	
	public String getRequestLegalAddressChangeYesButton_2_xpath() {
		
		return "html/body/form[2]/div[2]/table/tbody/tr/td/div/div[6]/table/tbody/tr/td/table/tbody/tr[3]/td/div/table[2]/tbody/tr[2]/td/center/table/tbody/tr/td[1]/div/a";
	}
	
	public String getRequestLegalAddressChangeOKButton_2_xpath() {
		
		return "html/body/form[2]/div[2]/table/tbody/tr/td/div/div[6]/table/tbody/tr/td/table/tbody/tr[3]/td/div/div/center/div/a";
	}
	
	public String getArrowDropdownMenu_xpath() {
		
		return "html/body/form[2]/div[2]/table/tbody/tr/td/div/div[1]/table/tbody/tr/td[2]/div/table/tbody/tr[1]/td[2]/table/tbody/tr[1]/td[2]/div/div[1]/a";
	}
	
	public String getSearchButton_xpath() {
		
		return "html/body/form[2]/div[2]/table/tbody/tr/td/div/center/table/tbody/tr[2]/td[2]/div/a";
	}
	
	public String getEntityInformationTab_xpath() {
		
		return "html/body/form[2]/div[2]/table/tbody/tr/td/div/div[4]/table/tbody/tr[1]/td/table/tbody/tr/td[1]/table/tbody/tr[2]/td[2]/a";
	}
	
	public String getAddressNameChangeRequest_xpath() {
		
		return "html/body/form[2]/div[2]/table/tbody/tr/td/div/div[4]/table/tbody/tr[2]/td/div/div/span[1]/span[1]/div/div/div[4]/a/img";
	}
	
	public String getChangeRequestForAddress_xpath() {
		
		return "html/body/form[2]/div[2]/table/tbody/tr/td/div/div[6]/table/tbody/tr/td/table/tbody/tr[3]/td/div/table/tbody/tr/td[2]/select/option[2]";
	}
	
	public String getLEOKButton_xpath() {
		
		return "html/body/form[2]/div[2]/table/tbody/tr/td/div/div[2]/table/tbody/tr/td/table/tbody/tr/td/div/center/div/a";
	}
	
	public String getLEYesButton_xpath() {
		
		return "html/body/form[2]/div[2]/table/tbody/tr/td/div/div[2]/table/tbody/tr/td/table/tbody/tr/td/div/table[3]/tbody/tr[2]/td/center/table/tbody/tr/td[1]/div/a";
	}
	
	public String getRequestLegalAddressChangeSubmitButton_1_xpath() {
		
		return "html/body/form[2]/div[2]/table/tbody/tr/td/div/div[1]/div[5]/table/tbody/tr/td/table/tbody/tr[3]/td/div/div[3]/div[2]/a";
	}
	
	
	
}
