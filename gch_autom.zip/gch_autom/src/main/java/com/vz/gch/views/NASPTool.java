
package com.vz.gch.views;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.vz.gch.containers.ContainerEnvironment;
import com.vz.gch.containers.NASPToolContainer;

public class NASPTool {
	
	private WebDriver driver = null;
	
	
	private final String URLAuthRest = ".ebiz.verizon.com/gch/cle/main.xhtml";
	private final long globalTimeout = 35;
	private boolean Authd = false;
	public boolean CreateAndApprove = false;
	public String GottenId = "";
	private NASPToolContainer container; 
	private CommonFunctions common;
	private WebElement NASPToolRequestButton;
	private String URLFirstPart;
	
	
	public void UserLastId(){
		
	}
	
	public String getUrlSubstring(String URL)
	{
		return URL.substring(0, 14);
	}
	
	private String GetApproveFirst(String Id) throws Exception{
		return ""+URLFirstPart+".ebiz.verizon.com/gch/cle/gchsearch?caller_page=sfdc_nasp_approval&inquiry_id="+Id+"&task=Nasp%20Field%20POC%20Approval";
	}
	
	private String GetApproveSecond(String Id) throws Exception{
		return ""+URLFirstPart+".ebiz.verizon.com/gch/cle/gchsearch?caller_page=sfdc_nasp_approval&inquiry_id="+Id+"&task=Nasp%20Admin%20Approval";
	}
	
	public void Approve(String Id, boolean First) throws Exception{
		LoggedException();
       driver.get(First ? GetApproveFirst(Id) : GetApproveSecond(Id));
       driver.manage().timeouts().implicitlyWait(globalTimeout, TimeUnit.SECONDS);
       (new WebDriverWait(driver, globalTimeout)).until(ExpectedConditions.elementToBeClickable(By.cssSelector("div[class='x-component x-border-box x-mask x-component-default']")));
       (new WebDriverWait(driver, globalTimeout)).until(ExpectedConditions.not(ExpectedConditions.elementToBeClickable(By.cssSelector("div[class='x-component x-border-box x-mask x-component-default']"))));		
	}
	
	
	public void CheckGottenId() throws Exception{
		if(!CreateAndApprove) throw new Exception("NaspId was not specified");
	}
	
	public void Approve(boolean First) throws Exception {
		
		Approve(GottenId, CreateAndApprove);
	}
	
	public void ApproveIt() throws Exception{
		LoggedException();
		driver.findElement(By.id("approveWithChangesButton-btnInnerEl")).click();
	}
	
	public void ApproveWait() throws Exception{
		LoggedException();
		(new WebDriverWait(driver, globalTimeout)).until(ExpectedConditions.elementToBeClickable(By.cssSelector("div[class='x-window x-message-box x-layer x-window-modal-layer x-closable x-window-closable x-window-modal-layer-closable x-border-box messageBoxAppUpdate']")));
		WebElement WEMessage = driver.findElement(By.cssSelector("div[class='x-component x-window-text x-box-item x-component-default']"));
		String Message = WEMessage.getText();
		if(Message.indexOf("has been approved") == -1){
			throw new Exception("Exception: '"+Message+"'");
		}
	}
	
	public void Wait(String Seconds) throws NumberFormatException, InterruptedException{
		Thread.sleep(Long.valueOf(Seconds) * 1000L);
	}
	
	public void SetNaspIdApproval(String NaspId) throws Exception{
		LoggedException();
		driver.findElement(By.name("NASPID")).sendKeys(NaspId);
		Thread.sleep(2000);
	}
	
	public NASPTool(WebDriver driver){
		//super(driver, manageRevLocPageTitle);
		mappingWindow = new SegmentMappingWindow(driver);
		this.driver = driver;
		container = new NASPToolContainer(driver);
		ContainerEnvironment.getEnvironment();
		
	}
	

	
	public void LogIn(String Username, String Password){
		if(Authd) return;
		driver.manage().timeouts().implicitlyWait(globalTimeout, TimeUnit.SECONDS);
		URLFirstPart=getUrlSubstring(ContainerEnvironment.URL);
		driver.get(URLFirstPart+URLAuthRest);
		driver.manage().timeouts().implicitlyWait(globalTimeout, TimeUnit.SECONDS);
		Alert NativeLoginPopup = (new WebDriverWait(driver, globalTimeout)).until(ExpectedConditions.alertIsPresent());  
		NativeLoginPopup.dismiss();
		driver.manage().timeouts().implicitlyWait(globalTimeout, TimeUnit.SECONDS);
		driver.findElement(By.id("USERID")).sendKeys(Username);
		driver.findElement(By.id("PASSWORD")).sendKeys(Password);
		driver.findElement(By.xpath("//a/span")).click();
		Alert alert = driver.switchTo().alert();
		alert.accept();
       driver.manage().timeouts().implicitlyWait(globalTimeout, TimeUnit.SECONDS);		
	}
	
	public void Authenticated(){
		(new WebDriverWait(driver, globalTimeout)).until(ExpectedConditions.elementToBeClickable(By.id("signOutLink")));
		Authd = true;
	}
	
	public void LoggedException() throws Exception{
		if(Authd) return;
		throw new Exception("Not Logged in.");
	}
	
	public void  GetToIdRequest(String NaspId) throws Exception{
		LoggedException();
		//10BUAG
		
       driver.get(ContainerEnvironment.URL);
       driver.manage().timeouts().implicitlyWait(globalTimeout, TimeUnit.SECONDS);
       driver.findElement(By.id("genericNASPID-inputEl")).sendKeys(NaspId);		
       driver.findElement(By.cssSelector("a[class='x-btn x-unselectable x-box-item x-toolbar-item x-btn-green-search-naspTool-button-small']")).click();
	}
	
	public void WaitForUI() throws Exception{
		LoggedException();
       (new WebDriverWait(driver, globalTimeout)).until(ExpectedConditions.elementToBeClickable(By.cssSelector("div[class='x-component x-border-box x-mask x-component-default']")));
       (new WebDriverWait(driver, globalTimeout)).until(ExpectedConditions.not(ExpectedConditions.elementToBeClickable(By.cssSelector("div[class='x-component x-border-box x-mask x-component-default']"))));		
	}
	
	
	public void SetNaspType(String Type) throws Exception{
		LoggedException();
		//AA TEST
       driver.findElement(By.id("naspType-inputEl")).click();
       driver.findElement(By.xpath("//*[text()='"+Type+"']")).click();		
	}
	
	public void SetRevLoc(String RevLoc) throws Exception{
		LoggedException();
		//CGT
       driver.findElement(By.id("revLoc-inputEl")).click();
       driver.findElement(By.xpath("//*[text()='"+RevLoc+"']")).click();		
	}
	
	
	public void SetGCHId(String Filter) throws Exception{
		LoggedException();
		//sit*
	    driver.findElement(By.id("gchId-trigger-search")).click();
       String winHandleBefore = driver.getWindowHandle();
		for(String winHandle : driver.getWindowHandles()){
			driver.switchTo().window(winHandle);
		}
		driver.manage().timeouts().implicitlyWait(globalTimeout, TimeUnit.SECONDS);
		driver.findElement(By.id("generalForm:searchInputText")).sendKeys(Filter);
		driver.findElement(By.id("generalForm:searchButton")).click();
		(new WebDriverWait(driver, globalTimeout)).until(ExpectedConditions.elementToBeClickable(By.cssSelector("th[class='iceDatTblColHdr2']")));
		WebElement First = driver.findElement(By.id("generalForm:cleSearchTblID:tbody"));
		WebElement Second = First.findElement(By.cssSelector("tr[class='iceDatTblRow gchRowEven']"));
		Second.findElement(By.cssSelector("div[class='iceMnuBarItem dropmenuLinkItem']")).click();
		(new WebDriverWait(driver, globalTimeout)).until(ExpectedConditions.elementToBeClickable(Second.findElement(By.cssSelector("div[class='iceMnuBarSubMenu']"))));
		Second.findElement(By.cssSelector("div[class='iceMnuBarSubMenu']")).findElements(By.cssSelector("div[class='iceMnuItm']")).get(2).click();
		driver.switchTo().window(winHandleBefore);
		driver.findElement(By.cssSelector("a[class='x-btn x-unselectable x-box-item x-toolbar-item x-btn-red-button-small']")).click();	
	}
	
	
	private boolean WaitTimeout = false;
	private long WaitStarted = 0;
	
	private void WaitRestart(){
		WaitTimeout = true;
		WaitStarted = System.currentTimeMillis();
	}
	
	private void WaitTimeitOut(){
		if(System.currentTimeMillis() - WaitStarted > 50){
			WaitTimeout = false;
		}		
	}
	
	public void WaitGCHIdScreen() throws InterruptedException, Exception {
		LoggedException();
		WaitRestart();
		while(driver.findElement(By.id("street_address-inputEl")).getAttribute("value").equals("") && WaitTimeout){
			WaitTimeitOut();
			Thread.sleep(16);
		}
		WaitRestart();
		while(driver.findElement(By.id("country-inputEl")).getAttribute("value").equals("")  && WaitTimeout){
			WaitTimeitOut();
			Thread.sleep(16);
		}
		WaitRestart();
		while(driver.findElement(By.id("cityId-inputEl")).getAttribute("value").equals("")  && WaitTimeout){
			WaitTimeitOut();
			Thread.sleep(16);
		}
		WaitRestart();
		while(driver.findElement(By.id("postal_code-inputEl")).getAttribute("value").equals("")  && WaitTimeout){
			WaitTimeitOut();
			Thread.sleep(16);
		}
	}
	
	public void SetCountry(String Name) throws Exception{
		LoggedException();
		//Uruguay
       driver.findElement(By.id("country-inputEl")).click();
       driver.findElement(By.id("country-inputEl")).sendKeys(Name);	
	}
	
	public void SetStreet(String Name) throws Exception{
		LoggedException();
	    driver.findElement(By.id("street_address-inputEl")).click();
		driver.findElement(By.id("street_address-inputEl")).sendKeys(Name);
	}
	
	public void SetCity(String Name) throws Exception{
		LoggedException();
		driver.findElement(By.id("cityId-inputEl")).click();
		driver.findElement(By.id("cityId-inputEl")).sendKeys(Name);
	}
	
	public void SetPostalCode(String PSCode) throws Exception{
		LoggedException();
		driver.findElement(By.id("postal_code-inputEl")).click();
		driver.findElement(By.id("postal_code-inputEl")).sendKeys(PSCode);
	}
	
	public void SetFirstName(String Name) throws Exception{
		LoggedException();
		//Robert
		driver.findElement(By.id("contact_first_name-inputEl")).click();
		driver.findElement(By.id("contact_first_name-inputEl")).sendKeys(Name);
	}
	
	public void SetLastName(String Lastname) throws Exception{
		LoggedException();
		//Fisher
		driver.findElement(By.id("contact_last_name-inputEl")).click();
		driver.findElement(By.id("contact_last_name-inputEl")).sendKeys(Lastname);
	}
	
	public void SetPhoneNumber(String PhoneNumber) throws Exception{
		LoggedException();
		//1-123-1234
		driver.findElement(By.id("phone-inputEl")).click();
		driver.findElement(By.id("phone-inputEl")).sendKeys(PhoneNumber);
	}
	
	public void SetState(String State) throws Exception{
		LoggedException();
		//TN
		driver.findElement(By.id("stateNonUSCanada-inputEl")).click();
		driver.findElement(By.id("stateNonUSCanada-inputEl")).sendKeys(State);
	}
	
	public void Done() throws InterruptedException{
		Thread.sleep(5000);
		driver.close();
	}
	
	public void Submit() throws Exception {
		LoggedException();
		driver.findElement(By.cssSelector("a[class='x-btn x-unselectable x-box-item x-toolbar-item x-btn-green-search-button-small']")).click();
		
		(new WebDriverWait(driver, globalTimeout)).until(ExpectedConditions.elementToBeClickable(By.cssSelector("div[class='x-title-text x-title-text-modal-layer x-title-item']")));
		
		WebElement Message = driver.findElement(By.cssSelector("div[class='x-title-text x-title-text-modal-layer x-title-item']"));
		
		if(Message.getText().equals("Validation Error")){
			Thread.sleep(5000);
			if(driver.findElement(By.id("contact_first_name-inputEl")).getAttribute("value").equals("")){
				throw new Exception("First Name was not entered.");
			}else
			if(driver.findElement(By.id("contact_last_name-inputEl")).getAttribute("value").equals("")){
				throw new Exception("Last Name was not entered.");
			}else
			if(driver.findElement(By.id("phone-inputEl")).getAttribute("value").equals("")){
				throw new Exception("Phone was not entered.");
			}else
			if(driver.findElement(By.id("country-inputEl")).getAttribute("value").equals("")){
				throw new Exception("Country was not entered.");
			}else
			if(driver.findElement(By.id("street_address-inputEl")).getAttribute("value").equals("")){
				throw new Exception("Street Address was not entered.");
			}else
			if(driver.findElement(By.id("cityId-inputEl")).getAttribute("value").equals("")){
				throw new Exception("City was not entered.");
			}else
			if(driver.findElement(By.id("postal_code-inputEl")).getAttribute("value").equals("")){
				throw new Exception("Postal Code was not entered.");
			}else
			if(driver.findElement(By.id("naspType-inputEl")).getAttribute("value").equals("")){
				throw new Exception("NaspType was not entered.");
			}else
			if(driver.findElement(By.id("revLoc-inputEl")).getAttribute("value").equals("")){
				throw new Exception("RevLoc was not entered.");
			}else
			if(driver.findElement(By.id("sfdc_acc_name-inputEl")).getAttribute("value").equals("")){
				throw new Exception("Nasp Name(Company Name) was not entered.");
			}else
			if(driver.findElement(By.id("gchId-inputEl")).getAttribute("value").equals("")){
				throw new Exception("GCH Id was not entered.");
			}else{
				throw new Exception("Validation Error");
			}
		}
		//Your request has been submitted. Your Inquiry ID is 1294
		Message = driver.findElement(By.cssSelector("div[class='x-component x-window-text x-box-item x-component-default']"));
		String Str = Message.getText();
		CreateAndApprove = true;
		GottenId =  Str.substring(Str.lastIndexOf(" ")+1, Str.length());	
		System.out.println("Requested ID Is "+GottenId);
		
	}	
	
	////////////////////////////////////MANAGE REVLOC MAPPING NASP TOOL/////////////////////////////////
	

	/**
	 * inner class SegmentMappingWindow ****/
	private class SegmentMappingWindow  
	{	
		private WebDriver driver;
		private JavascriptExecutor executor;
		private String executorInstruction = "Ext.ComponentQuery.query('combobox.combo[name=segmentCode]')[0].setValue(arguments[0])";
		
	//	@FindBy( xpath="//a/span/span/span[text()='Confirm']" )
		private WebElement confirmButton;
		
	//	@FindBy( xpath="//input[@role='textbox'][@name='revloc']" )
		private WebElement inputRevLocField;
		
	//	@FindBy( xpath="//input[@role='combobox'][@name='segmentCode']" )
		private WebElement segmentSelector;
		
	//	@FindBy( xpath="//a/span/span/span[text()='Save']" )
		private WebElement saveButton;
		
		/**
		 * AddRevLocMappingWindow constructor
		 * @param driver
		 */
		SegmentMappingWindow(WebDriver driver)
		{
			
			this.driver = driver;
			executor = (JavascriptExecutor) this.driver;
			PageFactory.initElements(driver, this);
			
		}
		
		
		/**
		 * fill in the fields of the segment mapping window
		 * @param revLocCode
		 * @param segmentCode
		 */
		public void fillSegmentMappingWindow(String revLocCode, String segmentCode)
		{
			String segmentCodeLetter = segmentCode.substring(segmentCode.length()-2 , segmentCode.length()-1);
			inputRevLocField =  driver.findElement(By.xpath("//input[@role='textbox'][@name='revloc']"));
			
			inputRevLocField.sendKeys(revLocCode);
			
			executor.executeScript(executorInstruction, segmentCodeLetter);
			
			confirmButton =  driver.findElement(By.xpath("//a/span/span/span[text()='Confirm']"));
			
			confirmButton.click();
		}
		
		/**
		 * Changes the selected segment mapping
		 * @param segmentCode
		 */
		public void changeSegmentMapping(String segmentCode)
		{
			String segmentCodeLetter = segmentCode.substring(segmentCode.length()-2 , segmentCode.length()-1);
			
			executor.executeScript(executorInstruction, segmentCodeLetter);
			
			saveButton = driver.findElement(By.xpath("//a/span/span/span[text()='Save']"));
			saveButton.click();
		}
		
		/**
		 * Deletes the selected segment mapping
		 */
		public void deleteSegmentMapping()
		{
			confirmButton =  driver.findElement(By.xpath("//a/span/span/span[text()='Confirm']"));
			confirmButton.click();
		}
		
	} /*******End of the inner class SegmentMappingWindow********/
	
		private SegmentMappingWindow mappingWindow;
		
	//@FindBy( xpath="//a[@class='x-btn x-unselectable x-box-item x-btn-red-button-small']//span[text()='Add']" )
	private WebElement addButton;
	
	//@FindBy( xpath="//a[@data-qtip='Next Page']" )
	private WebElement nextPageButton;
	
	//@FindBy( xpath="//a[@data-qtip='Refresh']" )
	private WebElement refreshButton;
	
	//@FindBy( xpath="//a[@data-qtip='First Page']" )
	private WebElement firstPageButton;
	
	//@FindBy( xpath="//div[ contains(@id,'pagingtoolbar')]/div[ contains(@id, 'tbtext') ][2]" )
	private WebElement pageCount;
	
	//************************************ NOTE: These locators have some kind of pattern, these could be managed as a separate class
	//These locators need to be formated with the static method: 
	//String.format( baseString, revLocDescriptionString , segmentCodeString)
	private String mappingLocator = "//table/tbody/tr/td/div[text()='%s']/../following-sibling::td/div[text()='%s']";
	private String editButtonLocator = mappingLocator+"/../following-sibling::td//a[1]";
	private String deleteButtonLocator = mappingLocator+"/../following-sibling::td//a[2]";
	//************************************
	

	
	/**
	 * Handles the pager to go to the first page
	 * @throws IOException 
	 */
	public void goToFirstPage() throws IOException
	{
		container.waitForElement(10, "//a[@data-qtip='First Page']", "xpath");
		firstPageButton = driver.findElement(By.xpath("//a[@data-qtip='First Page']"));
		firstPageButton.click();
	}
	
	/**
	 * Adds a new segment mapping
	 * @param revLocCode
	 * @param segmentCode
	 */	public void addSegmentMapping(String revLocCode, String segmentCode)
	{
		addButton =  driver.findElement(By.xpath("//a[@class='x-btn x-unselectable x-box-item x-btn-red-button-small']//span[text()='Add']"));
		addButton.click();
		
		mappingWindow.fillSegmentMappingWindow( revLocCode, segmentCode );
	}
	
	/**
	 * Edits a segment mapping
	 * @param revLocCode
	 * @param segmentCode
	 * @param newSegmentCode
	 * @throws InterruptedException 
	 */
	public void editSegmentMapping(String revLocCode, String segmentCode, String newSegmentCode) throws InterruptedException
	{
		String editButton = String.format(editButtonLocator, revLocCode, segmentCode);

		driver.findElement( By.xpath(editButton)).click();
		
		mappingWindow.changeSegmentMapping( newSegmentCode );
		
		explicitWait(3); //Wait for 3 seconds
	}
	
	/**
	 * Deletes an existing segment mapping
	 * @param revLocCode
	 * @param segmentCode
	 * @throws InterruptedException 
	 */
	public void deleteSegmentMapping(String revLocCode, String segmentCode) throws InterruptedException
	{
		String deleteButton = String.format(deleteButtonLocator, revLocCode, segmentCode);
		
		driver.findElement( By.xpath( deleteButton ) ).click();
		
		mappingWindow.deleteSegmentMapping();
		
		explicitWait(3); //Wait for 3 seconds
	}
	
	/**
	 * Check if a mapping exists in the page
	 * @param revLocCode
	 * @param segmentCode
	 * @return true if the revLocCode and segmentCode exists in the page
	 */ 
	public boolean checkIfMappingExist(String revLocCode, String segmentCode) throws InterruptedException
	{	

		explicitWait(3); // Wait for 3 seconds before starting to look for the mapping
		
		setImplicitWaitTime(5); // Sets the waiting time for an element to 5 seconds
		
		String formattedLocator = String.format(mappingLocator, revLocCode, segmentCode);		
		pageCount = driver.findElement(By.xpath("//div[ contains(@id,'pagingtoolbar')]/div[ contains(@id, 'tbtext') ][2]"));
		String pageCountText = pageCount.getText();
		
		By revLocMapping = By.xpath(formattedLocator);
		
		List<WebElement> elements;
		
		int numberOfPages = Character.getNumericValue( pageCountText.charAt( pageCountText.length()-1 ) );
		
		for(int i = 1; i <= numberOfPages; i++)
		{
			elements =  driver.findElements( revLocMapping);
			
			if(elements.size() > 0)
			{
				setImplicitWaitTime(30);
				return true;
			}
			else
			{
				nextPageButton =  driver.findElement(By.xpath("//a[@data-qtip='Next Page']"));
				nextPageButton.click();
			}
		}
		
		setImplicitWaitTime(30);
		return false;
	}
	
	public void NaspToolRevlocButtonClick() throws IOException{
		container.waitForElement(10, "//div[4]/div/div/div/div[2]/div/div/a/span/span/span[2]", "xpath");
		WebElement RevlocButtonClick = driver.findElement(By.xpath("//div[4]/div/div/div/div[2]/div/div/a/span/span/span[2]"));
		RevlocButtonClick.click();
		container.waitForElement(10, "//div/div/div/div/div/div/div/div/a/span/span/span[2]", "xpath");
	}
	
	/////////////////////////////////GCH NASP TOOL REQUEST SEARCH////////////////////////////////////////////////////
	
	/**
	 * this holds a reference to the label Search Request. This is used to verified that
	 * the users in on the request search page.
	 */
	//@FindBy(xpath = "html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[1]")
	private WebElement searchRequestsTitle;

	/**
	 * this is a references to Textbox where user insert the nasp Id that he will
	 * use to search.
	 */
	//@FindBy(xpath = "html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[3]/div/div/div[1]/div[1]/div[1]/div/input")
	private WebElement naspIdTxtBox;
	
	/**
	 * this is a references to Textbox where user insert the nasp name that he will
	 * use to search.
	 */
	//@FindBy(xpath = "html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[2]/div/div/div[1]/div/div[1]/div/input")
	private WebElement naspNameTxtBox ;
	
	/**
	 * this is a references to Textbox where user insert the nasp created date from that he will
	 * use to search.
	 */
	//@FindBy(xpath = "html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[2]/div/div/div[3]/div/div[1]/div[1]/input")
	private WebElement naspCreatedDateFromTxtBox;
	
	/**
	 * this is a references to Textbox where user insert the created date to that he will
	 * use to search.
	 */
	//@FindBy(xpath = "html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[2]/div/div/div[4]/div/div[1]/div[1]/input")
	private WebElement naspCreatedDateToTxtBox;
	
	/**
	 * This holds a reference to the button that will activate the search.
	 */
	//@FindBy(xpath = "html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[4]/div/div/a[1]")
	private WebElement searchButtonNASPSearch;
	
	/**
	 * This holds all the records from the search query
	 */
	//@FindBy(xpath = "html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[6]/div[2]/div[1]")
	private WebElement tableView;
	
	/**
	 * This hold a reference to the "Request Id" text box.
	 */
	//@FindBy(xpath = "html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[3]/div/div/div[2]/div[1]/div[1]/div[1]/input")
	private WebElement naspRequestIdTxtBox;
	
	/**
	 * This is a reference to the hyper link that navigates to the nasp approval page 
	 */
	//@FindBy(id =  "button-1129")
	private WebElement requestIdLink;
	
	/**
	 * This is a reference to the clear button
	 */
	//@FindBy(xpath = "html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[4]/div/div/a[2]")
	private WebElement clearButton;
	
	/**
	 * This is a reference to the status field
	 */
	//@FindBy(xpath =  "html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[2]/div/div/div[2]/div/div[1]//div[1]/input")
	private WebElement naspREquestStatusField;
	
	/**
	 * This is a reference to the region field
	 */
	//@FindBy(xpath =  "html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[3]/div/div/div[3]/div/div[1]/div[1]/input")
	private WebElement naspRequestRegionField;
	
	@FindBy(xpath = "html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[6]/div[2]/div[1]/div/table/tbody/tr/td[11]/div")
	private WebElement naspIdRecordValue;
	
	/**
	 * the class constructor and it also builds the base class constructors
	 * 
	 * @param driver
	 */


	/**
	 * This validate that the user is on the search request page
	 * @return true if the page loaded the label correctly
	 */
	public boolean isUserOnSearchRequestPage() {
	  searchRequestsTitle = driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[1]"));
		return (searchRequestsTitle != null);
	}

	/**
	 * this provides the NASP id to the input textbox
	 * @param naspId
	 */
	public void provideNaspId(String naspId){
		naspIdTxtBox = driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[3]/div/div/div[1]/div[1]/div[1]/div/input"));
		naspIdTxtBox.sendKeys(naspId);
	}
	
	/**
	 * this clicks on the search button to get the search result
	 */
	public void clickOnSearchButton(){
		searchButtonNASPSearch = driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[4]/div/div/a[1]"));
		searchButtonNASPSearch.click();
	}

	/**
	 * This method validate that the reference to the table contains a
	 * items by search for all the items inside of items and if the amount of
	 * items is greater than zero.
	 * @return
	 */
	public boolean tableContainsAtLeastOneItem() {
		//TODO: Verify that the tableView holds an instance of the actual records and
		// also check if refresh every time the content is updated.
		tableView = driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[6]/div[2]/div[1]"));
		List<WebElement> tables = tableView.findElements(By.tagName("table"));
		return tables.size() > 0;
	}

	public boolean userCanViewStatusRequest() {
		WebDriverWait wait = new WebDriverWait(driver, 5);
		wait.until(ExpectedConditions.visibilityOf(tableView));
		return tableView != null;	
	}
	
	/**
	 * this provides the NASP name to the input textbox
	 * @param naspId
	 */
	public void provideNaspName(String arg) {
		naspNameTxtBox = driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[2]/div/div/div[1]/div/div[1]/div/input"));
		naspNameTxtBox.sendKeys(arg);
	}

	public void provideRequestId(String arg) {
		naspRequestIdTxtBox = driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[3]/div/div/div[2]/div[1]/div[1]/div[1]/input"));
		naspRequestIdTxtBox.sendKeys(arg);
	}
	
	/**
	 * this provides the NASP Create Date From to the input textbox
	 * @param naspId
	 */
	public void provideCreatedDateFrom(String arg) {
		//naspCreatedDateFromTxtBox = driver.findElement(By.xpath("//*[@id='datefield-1096-inputEl']"));
		naspCreatedDateFromTxtBox = driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[2]/div/div/div[3]/div/div[1]/div[1]/input"));
		naspCreatedDateFromTxtBox.sendKeys(arg);
	}

	/**
	 * this provides the NASP "Create Date to" to the input textbox
	 * @param naspId
	 */
	public void provideCreatedDateTo(String arg) {
		naspCreatedDateToTxtBox = driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[2]/div/div/div[4]/div/div[1]/div[1]/input"));
		naspCreatedDateToTxtBox.sendKeys(arg);
	}
	
	/**
	 * this provides the NASP region to the input textbox.
	 * @param naspId
	 */
	public void provideRegion(String arg) {
		naspCreatedDateToTxtBox = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[3]/div/div/div[3]/div/div[1]/div[1]/div/ul/li/input"));
		naspCreatedDateToTxtBox.sendKeys(arg);	
	}
	
	public void clickOnRequestIdLink(String arg){
		requestIdLink = driver.findElement(By.id("button-1129"));
		String jsStr = 
				"document.getElementById('" + arg + "').click();";
		
		if (driver instanceof JavascriptExecutor) {
			((JavascriptExecutor) driver)
				.executeScript(jsStr);
		}
	}

	public void clickOnClearButton() {
		clearButton = driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[4]/div/div/a[2]"));
		clearButton.click();
	}

	public boolean areAllSearchParametersEmpty() {
			naspNameTxtBox = driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[2]/div/div/div[1]/div/div[1]/div/input"));
			naspRequestIdTxtBox = driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[3]/div/div/div[2]/div[1]/div[1]/div[1]/input"));
			naspIdTxtBox = driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[3]/div/div/div[1]/div[1]/div[1]/div/input"));
			naspCreatedDateFromTxtBox = driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[2]/div/div/div[3]/div/div[1]/div[1]/input"));
			naspCreatedDateToTxtBox = driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[2]/div/div/div[4]/div/div[1]/div[1]/input"));
			naspREquestStatusField  = driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[2]/div/div/div[2]/div/div[1]//div[1]/input"));
			naspRequestRegionField = driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[3]/div/div/div[2]/div[1]/div[1]/div[1]/input"));
					
		if(!naspNameTxtBox.getAttribute("value").isEmpty())
			return false;
		
		if(!naspIdTxtBox.getAttribute("value").isEmpty())
			return false;
		
		if(!naspRequestIdTxtBox.getAttribute("value").isEmpty())
			return false;
		if(!naspCreatedDateFromTxtBox.getAttribute("value").isEmpty())
			return false;
		if(!naspCreatedDateToTxtBox.getAttribute("value").isEmpty())
			return false;
		if(!naspREquestStatusField.getAttribute("value").isEmpty())
			return false;
		if(!naspRequestRegionField.getAttribute("value").isEmpty())
			return false;
		return true;
	}

	public void provideNaspStatus(String arg) {
		String cmd = "var cb = Ext.ComponentQuery.query('combobox.combo[fieldLabel=\"Status\"]')[0];cb.select(cb.getStore().getAt(4));";
		
		if (driver instanceof JavascriptExecutor) {
			((JavascriptExecutor) driver).executeScript(cmd);
		}
	}
	
	public boolean isNaspIdFilterCorrectly(){
		naspIdRecordValue = driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[6]/div[2]/div[1]/div/table/tbody/tr/td[11]/div"));
		return naspIdRecordValue.getText().equals(naspIdTxtBox.getAttribute("value").toString());
	}

	public boolean isfirstRecordRelatedToNaspId(String arg) {
		String firstRowNaspId = driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[6]/div[2]/div[1]/div/table[1]/tbody/tr/td[11]/div")).getText().trim();
		return firstRowNaspId.equals(arg.trim());
	}

	public boolean isfirstRecordRelatedToName(String arg) {
		String text = driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[6]/div[2]/div[1]/div/table[1]/tbody/tr/td[3]/div")).getText().trim();
		return text.equals(arg.trim());
	}
	

	public boolean isFirstRecordBetweenDates(String arg1, String arg2) throws ParseException {
		String dateFrom = arg1.trim();
		String dateTo = arg2.trim();
		String firstRecordDate = driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[6]/div[2]/div[1]/div/table[1]/tbody/tr/td[4]/div")).getText().trim();
		
		DateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");		
		Date date1 = formatter.parse(dateFrom);
		Date date2 = formatter.parse(dateTo);
		Date date = formatter.parse(firstRecordDate);
		
		return common.isWithinRange(date, date1, date2);
	}

	public boolean isFirstRecordRelatedToRecordId(String arg) {
		String text = driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[6]/div[2]/div[1]/div/table[1]/tbody/tr/td[1]/div/div/div/div/div/a/span/span/span[2]")).getText().trim();
		return text.equals(arg.trim());
	}

	public boolean isFirstRecordRelatedToRegion(String arg) {
		String text = driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[6]/div[2]/div[1]/div/table[1]/tbody/tr/td[9]/div")).getText().trim();
		return text.equals(arg.trim());
	}

	public boolean isFirstRecordRelatedToStatus(String arg) {
		String text = driver.findElement(By.xpath("//html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[6]/div[2]/div[1]/div/table[1]/tbody/tr/td[2]/div")).getText().trim();
		return text.equals(arg.trim());
	}
	
	public void clickOnNASPToolSearchRequestButton() throws IOException{
		container.waitForElement(15, container.NASPToolSearchRequestButton_xpath(), "xpath");
		NASPToolRequestButton = container.NASPToolSearchRequestButton();
		NASPToolRequestButton.click();
	}
	public void setImplicitWaitTime(int waitTime)
	{
		driver.manage().timeouts().implicitlyWait(waitTime, TimeUnit.SECONDS);
	}
	
	/**
	 * Wait for an arbitrary amount of time
	 * @param millis
	 * @throws InterruptedException
	 */
	public void explicitWait(int millis) throws InterruptedException
	{
		Thread.sleep(millis*1000);
	}

	public void SelectBranch(String branch) throws Exception {
		//container.waitForElement(10, container.NASPToolBranchDropDown_xpath(), "xpath");
		LoggedException();
		
       driver.findElement(By.id("branch-inputEl")).click();
       driver.findElement(By.xpath("//*[text()='"+branch+"']")).click();	;
		
	}
}
