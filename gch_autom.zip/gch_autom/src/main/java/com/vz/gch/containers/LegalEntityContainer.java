

package com.vz.gch.containers;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.lang.model.element.ElementKind;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.gargoylesoftware.htmlunit.javascript.host.Element;
import com.thoughtworks.selenium.webdriven.commands.IsElementPresent;
import com.vz.gch.views.CommonFunctions;



public class LegalEntityContainer {
	private String URL = "https://gchqa2.ebiz.verizon.com/gch/cle/main.xhtml";
	
	public WebDriver driver;
	
	private String UserName = "USERID";
	private String PassWord = "PASSWORD";
	public Actions action;
	
	
	public void getUrl()
	{
		ContainerEnvironment.getEnvironment();
		driver.get(ContainerEnvironment.URL);
	}
	
	public void waitForElement(Integer timeout, String ElementString, String Type) throws IOException{
		CommonFunctions.isElementPresent(driver, timeout, ElementString, Type);
	}

	public String getWindowHandle()
	{
		return driver.getWindowHandle();
	}
	
	public LegalEntityContainer(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getUserName(){
		return driver.findElement(By.id(UserName));
	}
	
	public WebElement getPassWord(){
		return driver.findElement(By.id(PassWord));
	}
	
	public WebElement getSign_OnButton(){
		return driver.findElement(By.xpath("//a/span"));
	}
	
	public WebElement getCreateCLElink(){
		return driver.findElement(By.xpath("//center/div/a"));
	}
	
	public WebElement getCLENameTextBox(){
		return driver.findElement(By.xpath("//td[3]/input"));
	}
	
	public WebElement getMBACLENameTextBox(){
		return driver.findElement(By.xpath("//td/input"));
	}
	
	public WebElement getCLEA1TextBox(){
		return driver.findElement(By.xpath("//tr[2]/td[3]/input"));
	}
	
	public WebElement getCLEA2TextBox(){
		return driver.findElement(By.xpath("//tr[3]/td[3]/input"));
	}
	
	public WebElement getCLEA3TextBox(){
		return driver.findElement(By.xpath("//tr[4]/td[3]/input"));
	}
	
	public WebElement getCLECityTextBox(){
		return driver.findElement(By.xpath("//tr[5]/td[3]/input"));
	}
	
	public WebElement getCLECountryDropDown(){
		return driver.findElement(By.xpath("//td[3]/select"));
	}
	
	public WebElement getCLEStateDropDown(){
		return driver.findElement(By.xpath("//tr[7]/td[3]/select"));
	}
	
	public WebElement getCLEZipCodeTextBox(){
		return driver.findElement(By.xpath("//tr[8]/td[3]/input"));
	}
	
	public WebElement getCLEPhoneTextBox(){
		return driver.findElement(By.xpath("//td[2]/table/tbody/tr/td[3]/input"));
	}
	
	public WebElement getCLECreateButton(){
		return driver.findElement(By.xpath("//div[3]/div[2]/a"));
	}
	
	public WebElement getCLECancelCreateButton(){
		return driver.findElement(By.xpath("//div[3]/div/a"));
	}
	
	public WebElement getCLEConfirmAddressButton(){
		return driver.findElement(By.xpath("//td/center/table/tbody/tr/td/div/a"));
	}
	
	public WebElement getCLEisCreatedButton(){
		return driver.findElement(By.xpath("//td/table/tbody/tr/td/div/center/div/a"));
	}
	
	public WebElement getCustomerHierarchyDropDown(){
		action=new Actions(driver);
		return driver.findElement(By.cssSelector("a[href*='/gch/cle/']"));
	}
	
	public WebElement getManageBillingAccountOption(){
		return driver.findElement(By.cssSelector("a[href*='cgi']"));
	}
	
	public WebElement getMBASearchBox(){
		return driver.findElement(By.xpath("//td/input"));
	}
	
	public WebElement getMBASearchButton(){
		return driver.findElement(By.xpath("//td[6]/div/a"));
	}
	
	public WebElement getMBACLESearchLink(){
		return driver.findElement(By.xpath("//td[2]/table/tbody/tr/td[2]/div/a"));
	}
	
	public List<WebElement> getMBACGIRenameLinkList(String CGINameToRename){
		return driver.findElements(By.id("generalForm:pnlCustomerSummaryTab:0:manageCGIBANTab:0:customerGroupsId:"+CGINameToRename+":j_id3283"));
	}
	
	public WebElement getRenameTextBox(String CGINameToRename){
		return driver.findElement(By.id("generalForm:pnlCustomerSummaryTab:0:manageCGIBANTab:0:customerGroupsId:"+CGINameToRename+":j_id3283"));
	}
	
	public WebElement getMBACLESearchButton(){
		return driver.findElement(By.xpath("//td[6]/div/a"));
	}
	//PLEASE CHECK , THIS IS USING ID AS ELEMENT FIND
	public Boolean getMBACGIRenameExistance(String oldCLEName){
		Integer oldCLENameInt=Integer.parseInt(oldCLEName);
		oldCLENameInt+=1;
		return (driver.findElements(By.xpath("//tr["+oldCLENameInt.toString()+"]/td[3]/table/tbody/tr/td/a/span")).size() > 0);
	}
	//PLEASE CHECK , THIS IS USING ID AS ELEMENT FIND
	public WebElement getMBACGIRename(String oldCLEName){
		Integer oldCLENameInt=Integer.parseInt(oldCLEName);
		oldCLENameInt+=1;
		WebElement MBACGIRename=driver.findElement(By.xpath("//tr["+oldCLENameInt.toString()+"]/td[3]/table/tbody/tr/td/a/span"));
		return MBACGIRename;
	}
	//PLEASE CHECK , THIS IS USING ID AS ELEMENT FIND
	public WebElement getMBACGIRenameTextBox(String oldCLEName){
		
		return driver.findElement(By.xpath("//td[2]/table/tbody/tr/td/table/tbody/tr/td/input"));
	}
	
	public WebElement getMBACGIConfirmationMessage(){
		return driver.findElement(By.xpath("span.iceMsgsInfo.confirmMsg"));
	}
	
	//PLEASE CHECK , THIS IS USING ID AS ELEMENT FIND
	public WebElement getMBACGIRenameSubmitbutton(String CGINameToRename){
		return driver.findElement(By.xpath("//a[contains(text(),'Submit')]"));
	}
	
	//PLEASE CHECK , THIS IS USING ID AS ELEMENT FIND
	public Boolean getMBACGIDeleteExistance(String deleteCGI){
		Integer dltCGI= Integer.parseInt(deleteCGI);
		dltCGI++;
		return (driver.findElements(By.xpath("//tr["+dltCGI+"]/td[3]/table/tbody/tr/td[2]/div/a")).size() > 0);
	}
	
	//PLEASE CHECK , THIS IS USING ID AS ELEMENT FIND
	public WebElement getMBACGIDelete(String deleteCGI){
		Integer dltCGI= Integer.parseInt(deleteCGI);
		dltCGI++;
		WebElement MBACGIDelete=driver.findElement(By.xpath("//tr["+dltCGI+"]/td[3]/table/tbody/tr/td[2]/div/a"));
		return MBACGIDelete;
		}
	
	//PLEASE CHECK , THIS IS USING ID AS ELEMENT FIND
	public WebElement getMBACGIDeleteSubmitButton(){
		return  driver.findElement(By.xpath("//td/div/div/div[2]/a"));
	}
	
	public WebElement getMBACreateCGIButton(){
		return driver.findElement(By.xpath("//span/a"));
	}
	
	public WebElement getMBACreateCGITextBox(){
		return driver.findElement(By.xpath("//table[2]/tbody/tr/td[2]/input"));
	}
	
	public WebElement getMBACreateCGISubmitButton(){
		return driver.findElement(By.xpath("//td[3]/div/a"));
	}
	
	public WebElement getManageAccountNumbersTab(){
		return driver.findElement(By.xpath("//td[2]/table/tbody/tr[2]/td[2]/a/div/table/tbody/tr/td"));
	}
	
	public WebElement getAccountSearchGoButton(){
		return driver.findElement(By.xpath("//td/div/center/table/tbody/tr/td/table/tbody/tr/td[6]/div/a"));
	}
	
	public WebElement getAccountObjectDropDown(){		
		return driver.findElement(By.xpath("//td[2]/select"));
	}
	
	public WebElement getAccountDescriptionTextBox(){
		return driver.findElement(By.xpath("//td/div/center/table/tbody/tr/td/table/tbody/tr/td[3]/input"));
	}
	
	public WebElement getAccountStatusDropDown(){
		return driver.findElement(By.xpath("//td[5]/select"));
	}
	
	public WebElement getCGISearchTypeDropDown(){
		return driver.findElement(By.xpath("//center/table/tbody/tr/td[2]/select"));
	}
	
	public WebElement getCGISearchTextBox(){
		return driver.findElement(By.xpath("//center/table/tbody/tr/td[3]/input"));
	}
	
	public WebElement getCGISearchGoButton(){
		return driver.findElement(By.xpath("//center/table/tbody/tr/td[4]/div/a"));
	}
	
	public WebElement getCGIActionButton(){
		return driver.findElement(By.xpath("//td[2]/table/tbody/tr/td/div/a"));
	}
	
	public WebElement getCGIchangeCGIOption(){
		return driver.findElement(By.xpath("//tr[6]/td/a"));
	}
	
	public WebElement getCGIRadioButton(){
		return driver.findElement(By.xpath("//table[2]/tbody/tr/td/table/tbody/tr/td/input"));  
	}
	
	//PLEASE CHECK , THIS IS USING CSS AS ELEMENT FIND
	public WebElement getCGIChangeCGIConfirmationTextLabel(){
		return driver.findElement(By.cssSelector("span.iceMsgsInfo.confirmMsg"));
	}
	
	public WebElement getCGISearchResultLabel(){
		return driver.findElement(By.xpath("//td[2]/div/div/table/tbody/tr/td[2]/div/span"));
	}
	
	public WebElement getCGIUpdateCustomerLegalNameOption(){
		return driver.findElement(By.xpath("//tr[11]/td/a"));
	}
	
	public WebElement getCGIUpdateCustomerLegalEntityNameTextBox(){
		return driver.findElement(By.xpath("//span/table/tbody/tr/td/table/tbody/tr/td[3]/input"));
	}
	
	public WebElement getCGIUpdateCustomerLegalEntityNameCPEOption(){
		return driver.findElement(By.xpath("//td[3]/select"));
	}
	
	public WebElement getCGIUpdateCustomerLegalEntityNameSubmitButton(){
		return driver.findElement(By.xpath("//td/div/div[5]/div[2]/a"));
	}
	
	public WebElement getCLEUpdateCustomerLegalEntityNameSubmitButton(){
		return driver.findElement(By.xpath("//div[4]/div[2]/a"));
	}
	
	public WebElement getCGIUpdateCustomerLegalNameConfirmationButton(){
		return driver.findElement(By.xpath("//div/div/center/div/a"));
	}
	
	public WebElement getCGIUpdateCustomerLegalAddressOption(){
		return driver.findElement(By.xpath("//tr[9]/td/a"));
	}
	
	public WebElement getCLEUpdateCustomerLegalAddressOption(){
		return driver.findElement(By.xpath("//div[4]/a/span"));
	}
	
	public WebElement getCGIUpdateCustomerLegalAddressLine1(){
		return driver.findElement(By.xpath("//span/table/tbody/tr/td/table/tbody/tr/td[3]/input"));
	}
	
	public WebElement getCGIUpdateCustomerLegalAddressLine2(){
		return driver.findElement(By.xpath("//tr[2]/td[3]/input"));
	}
	
	public WebElement getCGIUpdateCustomerLegalAddressLine3(){
		return driver.findElement(By.xpath("//tr[3]/td[3]/input"));
	}
	
	public WebElement getCGIUpdateCustomerLegalAddressCity(){
		return driver.findElement(By.xpath("//tr[4]/td[3]/input"));
	}
	
	public WebElement getCGIUpdateCustomerLegalAddressState(){
		return driver.findElement(By.xpath("//div/select"));
	}
	
	public WebElement getCGIUpdateCustomerLegalAddressZipCode(){
		return driver.findElement(By.xpath("//tr[7]/td[3]/input"));
	}
	
	public WebElement getCGIUpdateCustomerLegalAddressSubmitButton(){
		return driver.findElement(By.xpath("//div[4]/div[2]/a"));
	}
	
	public WebElement getCLEUpdateCustomerLegalAddressSubmitButton(){
		return driver.findElement(By.xpath("//div[3]/div[2]/a"));
	}
	
	public WebElement getCGIUpdateCustomerLegalAddressConfirmAddressButton(){
		return driver.findElement(By.xpath("//td/center/table/tbody/tr/td/div/a"));
	}
	
	public WebElement getCGIUpdateCustomerLegalAddressIDAddressRequest(){
		return driver.findElement(By.xpath("//center/div/a"));
	}
	
	public WebElement getManageService_LocationsTab(){
		return driver.findElement(By.xpath("//td[3]/table/tbody/tr[2]/td[2]/a/div/table/tbody/tr/td"));
	}
	
	public WebElement getManageServicesLocationsActionButton(){
		return driver.findElement(By.xpath("//td[2]/table/tbody/tr/td/div/a"));
	}
	
	public WebElement getAddUpdatePurchaseOrderOption(){
		return driver.findElement(By.xpath("//div/table/tbody/tr/td/a"));
	}
	
	public WebElement getCloseAddUpdatePurchaseOrdenButton(){
		return driver.findElement(By.xpath("//td[2]/div/input"));
	}
	
	public WebElement getCreateCGIResultLabelFailed(){
		return driver.findElement(By.cssSelector("span.iceMsgsError.errorMsg"));
	}
	
	public WebElement getCreateCGIResultLabelPassed(){
		return driver.findElement(By.cssSelector("span.iceMsgsInfo.confirmMsg"));
	}
	
	public WebElement getUpdateNamePendingLabel(){
		return driver.findElement(By.xpath("//td/table/tbody/tr[3]/td/div/span"));
	}
	
	public WebElement getUpdateNameNoChangesFound(){
		return driver.findElement(By.xpath("//tr[2]/td/div/table/tbody/tr/td/span"));
	}
	
	public WebElement getUpdateAddressPendingLabel(){
		return driver.findElement(By.xpath("//tr[3]/td/div/span"));
	}
	
	//PLEASE CHECK , THIS IS USING CSS AS ELEMENT FIND
	public WebElement getUpdateAddressValidationBeforeSubmit(){
		return driver.findElement(By.cssSelector("span.iceMsgsError.errorMsg"));
	}
	
	//PLEASE CHECK , THIS IS USING CSS AS ELEMENT FIND
	public WebElement getCGIChangeCGIConfirmationTextLabelPassed(){
		return driver.findElement(By.cssSelector("span.iceMsgsInfo.confirmMsg"));
	}
	
	//PLEASE CHECK , THIS IS USING CSS AS ELEMENT FIND
	public WebElement getCGIChangeCGIConfirmationTextLabelFailed(){
		return driver.findElement(By.cssSelector("span.iceMsgsError.errorMsg"));
	}
	///////////////////////////////////////////////////////////////////CONTINUE HERE PLS///////////////////////////////
	public WebElement getCLESearchBar(){
		return driver.findElement(By.xpath("//td/input"));
	}
	
	public WebElement getCLESearchBarButton(){
		return driver.findElement(By.xpath("//td[2]/div/a"));
	}
	
	public WebElement getCLEDropDownLittleArrow(){
		return driver.findElement(By.xpath("//td[2]/div/div/a"));
	}
	
	public WebElement getCLEViewProfileOption(){
		return driver.findElement(By.xpath("//td[2]/div/div[2]/div/a/span"));
	}
	
	public WebElement getCustomerContactTab(){
		return driver.findElement(By.xpath("//td[3]/table/tbody/tr[2]/td[2]/a/div/table/tbody/tr/td"));
	}
	
	public WebElement getCreateCPNIButton(){
		return driver.findElement(By.xpath("//a[contains(text(),'Create')]"));
	}
	
	public WebElement getCreateCPNIFirstNameTextBox(){
		return driver.findElement(By.xpath("//td[3]/input"));
	}
	
	public WebElement getCreateCPNILastNameTextBox(){
		return driver.findElement(By.xpath("//tr[3]/td[3]/input"));
	}
	
	public WebElement getCreateCPNIRoleDropDown(){
		return driver.findElement(By.xpath("//td[3]/select"));
	}
	
	public WebElement getCreateCPNITitleTexBox(){
		return driver.findElement(By.xpath("//tr[5]/td[3]/input"));
	}
	
	public WebElement getCreateCPNIEmailTexBox(){
		return driver.findElement(By.xpath("//tr[6]/td[3]/input"));
	}
	
	public WebElement getCreateCPNIWorkPhoneTexBox(){
		return driver.findElement(By.xpath("//td[4]/input"));
	}
	
	public WebElement getCreateCPNIAddressL1TexBox(){
		return driver.findElement(By.xpath("//td[2]/table/tbody/tr/td[3]/input"));
	}
	
	public WebElement getCreateCPNIAddressL2TexBox(){
		return driver.findElement(By.xpath("//td[2]/table/tbody/tr[2]/td[3]/input"));
	}
	
	public WebElement getCreateCPNIAddressL3TexBox(){
		return driver.findElement(By.xpath("//td[2]/table/tbody/tr[3]/td[3]/input"));
	}
	
	public WebElement getCreateCPNICityTexBox(){
		return driver.findElement(By.xpath("//tr[4]/td[3]/input"));
	}
	
	public WebElement getCreateCPNICountryDropDown(){
		return driver.findElement(By.xpath("//tr[5]/td[3]/select"));
	}
	
	public WebElement getCreateCPNIStateDropDown(){
		return driver.findElement(By.xpath("//div/select"));
	}
	
	public WebElement getCreateCPNIZipTextBox(){
		return driver.findElement(By.xpath("//tr[7]/td[3]/input"));
	}
	
	public WebElement getCreateCPNIWorkPhone(){
		return driver.findElement(By.xpath("//td[4]/input"));
	}
	
	public WebElement getCreateCPNISubmitCreateButton(){
		return driver.findElement(By.xpath("//div[3]/div[2]/a"));
	}
	
	public WebElement getCreateCPNIAddressConfirmButton(){
		return driver.findElement(By.xpath("//div[2]/div/a"));
	}
	
	public WebElement getCreateCPNISaveChangesButton(){
		return driver.findElement(By.xpath("//div[3]/a"));
	}
	
	public WebElement getCreateCPNIProcessSucessfullLabel(){
		return driver.findElement(By.xpath("//div[2]/table/tbody/tr/td/span"));
	}
	
	//PLEASE CHECK , THIS IS USING CSS AS ELEMENT FIND
	public WebElement getCreateCPNIErrorMessage(){
		return driver.findElement(By.cssSelector("span.iceMsgsError.errorMsg"));
	}

	public WebElement getCLESearchNotFoundLabel(){
		return driver.findElement(By.xpath("//td/div/div/span"));
	}
	
	public WebElement getCLERequestLegalNameChangeOption(){
		return driver.findElement(By.xpath("//td[2]/div/div[2]/div[3]/a/span"));
	}
	
	public WebElement getCLERequestInquiryOption(){
		return driver.findElement(By.xpath("//div[5]/a"));
	}
	
	public WebElement getCLERequestInquiryCommentsTextBox(){
		return driver.findElement(By.xpath("//textarea"));
	}
	
	public WebElement getCLERequestInquirySendButton(){
		return driver.findElement(By.xpath("//td/div/div[2]/a"));
	}
	
	//PLEASE CHECK , THIS IS USING CSS AS ELEMENT FIND
	public WebElement getCLERequestInquiryConfirmationMessage(){
		return driver.findElement(By.cssSelector("span.iceMsgsInfo.confirmMsg"));
	}
	
	public WebElement getCLEEntityInformationTab(){
		return driver.findElement(By.xpath("//a/div/table/tbody/tr/td"));
	}
	
	public WebElement getCLEUpdateCLEInfoButton(){
		return driver.findElement(By.xpath("//div[4]/a/img"));
	}
	
	public WebElement getLegalEntityStatusDropDown(){
		return driver.findElement(By.xpath("//td[3]/select"));
	}
	
	public WebElement getMainPhoneNumberTextBox(){
		return driver.findElement(By.xpath("//td/input"));
	}
	
	public WebElement getUpdateCLEBasicInfoSubmitButton(){
		return driver.findElement(By.xpath("//div[3]/div[2]/a"));
	}
	
	public WebElement getUpdateCLEBasicInfoOperationSucessfullButton(){
		return driver.findElement(By.xpath("//center/div/a"));
	}
	
	//PLEASE CHECK , THIS IS USING CSS AS ELEMENT FIND
	public WebElement getUpdateCLEBasicInfoErrorLabel(){
		return driver.findElement(By.cssSelector("span.iceMsgsError.errorMsg"));
	}
	
	public WebElement getUpdateDUNSIcon(){
		return driver.findElement(By.xpath("//span[2]/div/div/div[3]/a/img"));
	}
	
	public WebElement getUpdateDUNSLookupTextBox(){
		return driver.findElement(By.xpath("//div[2]/table/tbody/tr/td/input"));
	}
	
	public WebElement getUpdateDUNSContinueButton(){
		return driver.findElement(By.xpath("//tr[5]/td/div/div[2]/a"));
	}
	
	public WebElement getUpdateDUNSSaveChangesButton(){
		return driver.findElement(By.xpath("//td/div/div[3]/a"));
	}
	
	public WebElement getUpdateDUNSErrorLabel(){
		return driver.findElement(By.cssSelector("span.iceMsgsError.errorMsg"));
	}
	
	//PLEASE CHECK , THIS IS USING CSS AS ELEMENT FIND
	public WebElement getUpdateDUNSConfirmOperation(){
		return driver.findElement(By.xpath("//center/div/a"));
	}
	
	public WebElement getCreateAliasLabelButton(){
		return driver.findElement(By.xpath("//span/a"));
	}
	
	public WebElement getCreateAliasNameTextBox(){
		return driver.findElement(By.xpath("//td[4]/input"));
	}
	
	public WebElement getCreateAliasTypeDropDown(){
		return driver.findElement(By.xpath("//td[4]/select"));
	}
	
	public WebElement getCreateAliasSaveChangesButton(){
		return driver.findElement(By.xpath("//tr[8]/td/div/div[2]/a"));
	}
	
	//PLEASE CHECK , THIS IS USING CSS AS ELEMENT FIND
	public WebElement getCreateAliasErrorLabel(){
		return driver.findElement(By.cssSelector("span.iceMsgsError.errorMsg"));
	}
	
	//PLEASE CHECK , THIS IS USING CSS AS ELEMENT FIND
	public WebElement getCreateAliasOperationSuccessfull(){
		return driver.findElement(By.cssSelector("span.iceMsgsInfo.confirmMsg"));	
	}

	
	
	
					////////////////////////////////////////////////XPATH/////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


	public String getUserName_ID(){
		return "USERID";
	}
	public String getSign_OnButton_xpath(){
		return "//a/span";
	}
	
	public String getCreateCLElink_xpath(){
		return "//center/div/a";
	}
	
	public String getCLENameTextBox_xpath(){
		return "//td[3]/input";
	}
	
	public String getCLEA1TextBox_xpath(){
		return "//tr[2]/td[3]/input";
	}
	
	public String getCLEA2TextBox_xpath(){
		return "//tr[3]/td[3]/input";
	}
	
	public String getCLEA3TextBox_xpath(){
		return "//tr[4]/td[3]/input";
	}
	
	public String getCLECityTextBox_xpath(){
		return "//tr[5]/td[3]/input";
	}
	
	public String getCLECountryDropDown_xpath(){
		return "//td[3]/select";
	}
	
	public String getCLEStateDropDown_xpath(){
		return "//tr[7]/td[3]/select";
	}
	
	public String getCLEZipCodeTextBox_xpath(){
		return "//tr[8]/td[3]/input";
	}
	
	public String getCLEPhoneTextBox_xpath(){
		return "//td[2]/table/tbody/tr/td[3]/input";
	}
	
	public String getCLECreateButton_xpath(){
		return "//div[3]/div[2]/a";
	}
	
	public String getCLECancelCreateButton_xpath(){
		return "//div[3]/div/a";
	}
	
	public String getCLEConfirmAddressButton_xpath(){
		return "//td/center/table/tbody/tr/td/div/a";
	}
	
	public String getCLEisCreatedButton_xpath(){
		return "//td/table/tbody/tr/td/div/center/div/a";
	}
	
	public String getCustomerHierarchyDropDown_xpath(){
		return "a[href*='/gch/cle/']";
	}
	
	public String getManageBillingAccountOption_xpath(){
		return "a[href*='cgi']";
	}
	
	public String getMBASearchBox_xpath(){
		return "//td/input";
	}
	
	public String getMBASearchButton_xpath(){
		return "//td[6]/div/a";
	}
	
	public String getMBACLESearchLink_xpath(){
		return "//td[2]/table/tbody/tr/td[2]/div/a";
	}
	
	public String getMBACGIRenameTextBox_xpath(String oldCLEName){
		return "//td[2]/table/tbody/tr/td/table/tbody/tr/td/input";
	}

	public String getMBACGIConfirmationMessage_css(){
		return "span.iceMsgsInfo.confirmMsg";
	}
	//PLEASE CHECK , THIS IS USING ID AS ELEMENT FIND
	public String getMBACGIDelete_xpath(String deleteCGI){
		return "generalForm:manageCGIBANTab:0:customerGroupsId:"+deleteCGI+":j_id326";	
	}
	
	//PLEASE CHECK , THIS IS USING ID AS ELEMENT FIND
	public String getMBACGIDeleteSubmitButton_xpath(){
		return "//td/div/div/div[2]/a";
	}
	
	public String getMBACreateCGIButton_xpath(){
		return "//span/a";
	}
	
	public String getMBACreateCGITextBox_xpath(){
		return "//table[2]/tbody/tr/td[2]/input";
	}
	
	public String getMBACreateCGISubmitButton_xpath(){
		return "//td[3]/div/a";
	}
	
	public String getManageAccountNumbersTab_xpath(){
		return "//td[2]/table/tbody/tr[2]/td[2]/a/div/table/tbody/tr/td";
	}
	
	public String getAccountSearchGoButton_xpath(){
		return "//td/div/center/table/tbody/tr/td/table/tbody/tr/td[6]/div/a";
	}
	
	public String getAccountObjectDropDown_xpath(){		
		return "//td[2]/select";
	}

	public String getAccountDescriptionTextBox_xpath(){
		return "//td/div/center/table/tbody/tr/td/table/tbody/tr/td[3]/input";
	}
	
	public String getAccountStatusDropDown_xpath(){
		return "//td[5]/select";
	}
	
	public String getCGISearchTypeDropDown_xpath(){
		return "//center/table/tbody/tr/td[2]/select";
	}
	
	public String getCGISearchTextBox_xpath(){
		return "//center/table/tbody/tr/td[3]/input";
	}
	
	public String getCGISearchGoButton_xpath(){
		return "//center/table/tbody/tr/td[4]/div/a"; 
	}
	
	public String getCGIActionButton_xpath(){
		return "//td[2]/table/tbody/tr/td/div/a";
	}
	
	public String getCGIchangeCGIOption_xpath(){
		return "//tr[6]/td/a";
	}
	
	public String getCGIRadioButton_xpath(){
		return "//table[2]/tbody/tr/td/table/tbody/tr/td/input";
	}
	
	public String getCGIChangeCGIConfirmationTextLabel_xpath(){
		return "span.iceMsgsInfo.confirmMsg";
	}
	
	public String getCGIUpdateCustomerLegalEntityNameTextBox_xpath(){
		return "//span/table/tbody/tr/td/table/tbody/tr/td[3]/input";
	}
		
	public String getCGIUpdateCustomerLegalEntityNameCPEOption_xpath(){
		return "//td[3]/select";
	}
	
	public String getCGIUpdateCustomerLegalEntityNameSubmitButton_xpath(){
		return "//td/div/div[5]/div[2]/a";
	}
	
	public String getCGIUpdateCustomerLegalNameConfirmationButton_xpath(){
		return "//div/div/center/div/a";
	}
	
	public String getCGIUpdateCustomerLegalAddressOption_xpath(){
		return "//tr[9]/td/a";
	}
	
	public String getCGIUpdateCustomerLegalAddressLine1_xpath(){
		return "//span/table/tbody/tr/td/table/tbody/tr/td[3]/input";
	}
	
	public String getCGIUpdateCustomerLegalAddressConfirmAddressButton_xpath(){
		return "//td/center/table/tbody/tr/td/div/a";
	}
	
	public String getCGIUpdateCustomerLegalAddressIDAddressRequest_xpath(){
		return "//center/div/a";
	}
	
	public String getManageService_LocationsTab_xpath(){
		return "//td[3]/table/tbody/tr[2]/td[2]/a/div/table/tbody/tr/td";
	}
	
	public String getManageServicesLocationsActionButton_xpath(){
		return "//td[2]/table/tbody/tr/td/div/a";
	}
	
	public String getAddUpdatePurchaseOrderOption_xpath(){
		return "//div/table/tbody/tr/td/a";
	}
	
	public String getCloseAddUpdatePurchaseOrdenButton_xpath(){
		return "//td[2]/div/input";
	}
	
	//PLEASE CHECK , THIS IS USING CSS AS ELEMENT FIND
	public String getCreateCGIResultLabelFailed_css(){
		return "span.iceMsgsError.errorMsg";
	}
	
	//PLEASE CHECK , THIS IS USING CSS AS ELEMENT FIND
		public String getCreateCGIResultLabelPassed_css(){
		return "span.iceMsgsInfo.confirmMsg";
	}
		
	public String getUpdateNamePendingLabel_xpath(){
		return "//td/table/tbody/tr[3]/td/div/span";
	}
	
	public String getUpdateNameNoChangesFound_xpath(){
		return "//tr[2]/td/div/table/tbody/tr/td/span";
	}
	
	public String getUpdateAddressPendingLabel_xpath(){
		return "//tr[3]/td/div/span";
	}
	
	public String getUpdateAddressValidationBeforeSubmit_xpath(){
		return "span.iceMsgsError.errorMsg";
	}
	
	//PLEASE CHECK , THIS IS USING CSS AS ELEMENT FIND
	public String getCGIChangeCGIConfirmationTextLabelPassed_css(){
		return "span.iceMsgsInfo.confirmMsg";
	}
		
	//PLEASE CHECK , THIS IS USING CSS AS ELEMENT FIND
	public String getCGIChangeCGIConfirmationTextLabelFailed_css(){
		return "span.iceMsgsError.errorMsg";
	}
	
	//PLEASE CHECK , THIS IS USING ID AS ELEMENT FIND
	public String getMBACGIRenameSubmitbutton_xpath(String CGINameToRename){
		return "//a[contains(text(),'Submit')]";
	}
	
	public String getCLESearchBar_xpath(){
		return "//td/input";
	}
	
	public String getCLESearchBarButton_xpath(){
		return "//td[2]/div/a";
	}
	
	public String getCLEDropDownLittleArrow_xpath(){
		return "//td[2]/div/div/a";
	}
	
	public String getCLEViewProfileOption_xpath(){
		return "//td[2]/div/div[2]/div/a/span";
	}
	
	public String getCustomerContactTab_xpath(){
		return "//td[3]/table/tbody/tr[2]/td[2]/a/div/table/tbody/tr/td";
	}
	
	public String getCreateCPNIButton_xpath(){
		return "//a[contains(text(),'Create')]";
	}
	
	public String getCreateCPNIFirstNameTextBox_xpath(){
		return "//td[3]/input";
	}
	
	public String getCreateCPNILastNameTextBox_xpath(){
		return "//tr[3]/td[3]/input";
	}
	
	public String getCreateCPNIRoleDropDown_xpath(){
		return "//td[3]/select";
	}
	
	public String getCreateCPNITitleTexBox_xpath(){
		return "//tr[5]/td[3]/input";
	}
	
	public String getCreateCPNIEmailTexBox_xpath(){
		return "//tr[6]/td[3]/input";
	}
	
	public String getCreateCPNIWorkPhoneTexBox_xpath(){
		return "//td[4]/input";
	}
	
	public String getCreateCPNIAddressL1TexBox_xpath(){
		return "//td[2]/table/tbody/tr/td[3]/input";
	}
	
	public String getCreateCPNIAddressL2TexBox_xpath(){
		return "//td[2]/table/tbody/tr[2]/td[3]/input";
	}
	
	public String getCreateCPNIAddressL3TexBox_xpath(){
		return "//td[2]/table/tbody/tr[3]/td[3]/input";
	}
	
	public String getCreateCPNICityTexBox_xpath(){
		return "//tr[4]/td[3]/input";
	}
	
	public String getCreateCPNICountryDropDown_xpath(){
		return "//tr[5]/td[3]/select";
	}
	
	public String getCreateCPNIStateDropDown_xpath(){
		return "//div/select";
	}
	
	public String getCreateCPNIZipTextBox_xpath(){
		return "//tr[7]/td[3]/input";
	}
	
	public String getCreateCPNIWorkPhone_xpath(){
		return "//td[4]/input";
	}
	
	public String getCreateCPNISubmitCreateButton_xpath(){
		return "//td[4]/input";
	}
	
	public String getCreateCPNIAddressConfirmButton_xpath(){
		return "//div[2]/div/a";
	}
	
	public String getCreateCPNISaveChangesButton_xpath(){
		return "//div[3]/div[3]/a";
	}
	
	public String getCreateCPNIProcessSucessfullLabel_css(){
		return "span.iceMsgsInfo.confirmMsg";
	}
	//PLEASE CHECK , THIS IS USING CSS AS ELEMENT FIND
	public String getCreateCPNIErrorMessage_css(){
		return "//td/div/table/tbody/tr/td/span";
	}
	
	public String getCLESearchNotFoundLabel_xpath(){
		return"//td/div/div/span";
	}
	
	public String getCLERequestLegalNameChangeOption_xpath(){
		return "//td[2]/div/div[2]/div[3]/a/span";
	}
	
	public String getCLEUpdateCustomerLegalAddressOption_xpath(){
		return "//div[4]/a/span";
	}
	
	public String getCLERequestInquiryOption_xpath(){
		return "//div[5]/a";
	}
	
	public String getCLERequestInquiryCommentsTextBox_xpath(){
		return "//textarea";
	}
	
	public String getCLERequestInquirySendButton_xpath(){
		return "//td/div/div[2]/a";
	}
	
	//PLEASE CHECK , THIS IS USING CSS AS ELEMENT FIND
	public String getCLERequestInquiryConfirmationMessage_css(){
		return "span.iceMsgsInfo.confirmMsg";
	}
	
	public String getCLEEntityInformationTab_xpath(){
		return "//a/div/table/tbody/tr/td";
	}
	
	public String getCLEUpdateCLEInfoButton_xpath(){
		return "//div[4]/a/img";
	}
	
	public String getLegalEntityStatusDropDown_xpath(){
		return "//td[3]/select";
	}
	
	public String getMainPhoneNumberTextBox_xpath(){
		return "//td/input";
	}
	
	public String getUpdateCLEBasicInfoSubmitButton_xpath(){
		return "//div[3]/div[2]/a";
	}
	
	public String getUpdateCLEBasicInfoOperationSucessfullButton_xpath(){
		return "//center/div/a";
	}
	
	//PLEASE CHECK , THIS IS USING CSS AS ELEMENT FIND
	public String getUpdateCLEBasicInfoErrorLabel_css(){
		return "span.iceMsgsError.errorMsg";		
	}
	
	public String getUpdateDUNSIcon_xpath(){
		return "//span[2]/div/div/div[3]/a/img";
	}
	
	public String getUpdateDUNSLookupTextBox_xpath(){
		return "//div[2]/table/tbody/tr/td/input";
	}
	
	public String getUpdateDUNSContinueButton_xpath(){
		return "//tr[5]/td/div/div[2]/a";
	}
	
	public String getUpdateDUNSSaveChangesButton_xpath(){
		return "//td/div/div[3]/a";
	}
	
	//PLEASE CHECK , THIS IS USING CSS AS ELEMENT FIND
	public String getUpdateDUNSErrorLabel_css(){
		return "span.iceMsgsError.errorMsg";
	}
	
	public String getUpdateDUNSConfirmOperation_xpath(){
		return "//center/div/a";
	}
	
	public String getCreateAliasLabelButton_xpath(){
		return "//span/a";
	}
	
	public String getCreateAliasNameTextBox_xpath(){
		return "//td[4]/input";
	}
	
	public String getCreateAliasTypeDropDown_xpath(){
		return "//td[4]/select";
	}
	
	public String getCreateAliasSaveChangesButton_xpath(){
		return "//tr[8]/td/div/div[2]/a";
	}
	
	//PLEASE CHECK , THIS IS USING CSS AS ELEMENT FIND
	public String getCreateAliasErrorLabel_css(){
		return "span.iceMsgsError.errorMsg";
	}
	
	//PLEASE CHECK , THIS IS USING CSS AS ELEMENT FIND
	public String getCreateAliasOperationSuccessfull_css(){
		return "span.iceMsgsInfo.confirmMsg";	
	}
	
	public String getMBACLENameTextBox_xpath(){
		return "//td/input";
	}
	
	public String getMBACGIDeleteConfirmation_css(){
		return "span.iceMsgsInfo.confirmMsg";
	}
	

}
