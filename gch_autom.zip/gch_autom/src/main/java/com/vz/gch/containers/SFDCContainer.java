package com.vz.gch.containers;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.util.concurrent.TimeUnit;

public class SFDCContainer
{
   private static final String SFDC_URL = "https://vz1--sit01.cs20.my.salesforce.com";
private static final Object Webelement = null;
   private WebDriver driver;
   
   
   public SFDCContainer(WebDriver driver)
   {
      this.driver = driver;
   }
   
   public void goToSFDCPage()
   {
      driver.get(SFDC_URL);
   }
   
   public WebElement getUsernameInputField()
   {
      //return driver.findElement(By.xpath("html/body/div[1]/div[1]/div/div/div[3]/div[3]/form/div[1]/div/input[1]"));
      return driver.findElement(By.xpath("html/body/div[3]/div/div/section[2]/div[1]/div[2]/article/form/div[1]/input"));
   }
   
   public WebElement getPasswordInputField()
   {
      //return driver.findElement(By.xpath("html/body/div[1]/div[1]/div/div/div[3]/div[3]/form/input[1]"));
      return driver.findElement(By.xpath("html/body/div[3]/div/div/section[2]/div[1]/div[2]/article/form/div[3]/input"));
   }
   
   public WebElement getLogInButton()
   {
      //return driver.findElement(By.xpath("html/body/div[1]/div[1]/div/div/div[3]/div[3]/form/input[2]"));
      return driver.findElement(By.xpath("html/body/div[3]/div/div/section[2]/div[1]/div[2]/article/form/div[5]/a/span"));
   }
   
   public WebElement getSearchField()
   {
      ////input[@title='Search...']
      return driver.findElement(By.xpath("html/body/div[1]/div[2]/table/tbody/tr/td[2]/form/div/div/div[1]/input"));
      //return driver.findElement(By.xpath("//input[@title='Search...']"));
   }
   
   public WebElement getSearchButton()
   {
      return driver.findElement(By.xpath("html/body/div[1]/div[2]/table/tbody/tr/td[2]/form/div/div/div[2]/input"));
   }
   
   public WebElement getLinkWithText(String accountName)
   {
      return driver.findElement(By.linkText(accountName));
   }
   
   public WebElement getNewNaspIDRequestButton()
   {
      return driver.findElement(By.xpath("html/body/div[1]/div[3]/table/tbody/tr/td[2]/div[4]/div[1]/table/tbody/tr/td[2]/input[6]"));
   }
   
   public void resetImplicitTimeWait()
   {
      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
   }


	/////////////////////////////////////////////////////////////////
   
   
   public WebElement getUsernameInputField2()
   {
      //return driver.findElement(By.xpath("html/body/div[1]/div[1]/div/div/div[3]/div[3]/form/div[1]/div/input[1]"));
      return driver.findElement(By.xpath("//form[@id='domainLogin']/div/input"));
   }
   
   public WebElement getPasswordInputField2()
   {
      //return driver.findElement(By.xpath("html/body/div[1]/div[1]/div/div/div[3]/div[3]/form/input[1]"));
      return driver.findElement(By.xpath("//form[@id='domainLogin']/div[3]/input"));
   }
   
   public WebElement getLogInButton2()
   {
      //return driver.findElement(By.xpath("html/body/div[1]/div[1]/div/div/div[3]/div[3]/form/input[2]"));
      return driver.findElement(By.xpath("//form[@id='domainLogin']/div[5]/a/span"));
   }
	
   
   
	public WebElement getsfdcenternastype()
	{
		
 
		
		return  driver.findElement(By.xpath("//div[3]/div/div/div[2]")); 
		
	}
	
	public WebElement getsfdcenternastype_select()
	
	{
		return driver.findElement(By.xpath("//li[5]"));
		
		
	}
	
	
	public WebElement getsfdcenterrevloc()
	{
		return driver.findElement(By.xpath("//div[4]/div/div/div[2]"));
		
	}
	
	public WebElement getsfdcenterrevloc_select()
	{
		return driver.findElement(By.xpath("//div[7]/div/ul/li[3]"));
		
	}
	
	public WebElement getsfdccontactfirstname(){
		
		return driver.findElement(By.xpath("//div[@id='contact_first_name-inputWrap']/input"));
		
	}
	
	public WebElement getsfdccontactlastname(){
        return driver.findElement(By.xpath("//div[@id='contact_last_name-inputWrap']/input"));
	}
	
	public WebElement getsfdcsubmit_nasprequestid(){
		return driver.findElement(By.xpath("//span[@id='submitButton-btnEl']/span[2]"));
	}
	
	public WebElement getsfdcconfirmationok(){
		return driver.findElement(By.xpath("//div[4]/div/div/a/span/span/span[2]"));
		
		
	}
	
	
}
