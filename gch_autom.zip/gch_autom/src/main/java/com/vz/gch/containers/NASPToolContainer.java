package com.vz.gch.containers;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.vz.gch.views.CommonFunctions;

public class NASPToolContainer {
	
	private WebDriver driver;
	public void waitForElement(Integer timeout, String ElementString, String Type) throws IOException{
		CommonFunctions.isElementPresent(driver, timeout, ElementString, Type);
	}
	public String getWindowTitle()
	{
		return driver.switchTo().window(driver.getWindowHandle()).getTitle();
	}
	
	public NASPToolContainer(WebDriver driver)
	{
		this.driver = driver;
	}
	
	public WebElement NASPToolSearchRequestButton()
	{
		//return driver.findElement(By.xpath("//div[2]/div[2]/div/div/a/span/span/span[2]"));
		return driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div[3]/div/div/div[2]/div[2]/div/div/a/span/span/span[2]"));
	}
	
	/////////////////////////////STRINGS/////////////////////////////////////////
	
	public String NASPToolSearchRequestButton_xpath()
	{
		//return "//div[2]/div[2]/div/div/a/span/span/span[2]";
		return "html/body/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div/div/div[3]/div/div/div[2]/div[2]/div/div/a/span/span/span[2]";
	}
}
