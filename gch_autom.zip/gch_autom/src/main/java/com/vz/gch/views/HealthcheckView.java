package com.vz.gch.views;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.vz.gch.containers.HealthcheckContainer;

public class HealthcheckView {

	private HealthcheckContainer container;
	
	private CommonFunctions common;
	public static String TAX_ID=null; 
	private String searchedCLE = null;
	private String groupName = null;
	
	public HealthcheckView(WebDriver driver)
	{
		container = new HealthcheckContainer(driver);
		common    = new CommonFunctions(driver);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}
	
	public void clickViewProfOption() throws IOException
	{
		container.waitForElement(30, container.getLittleArrowCLE_xpath(), "xpath");
		WebElement littleArrow = container.getLittleArrowCLE();
		littleArrow.click();
		
		container.waitForElement(30, container.getViewProfileOption_xpath(), "xpath");
		WebElement viewProfile = container.getViewProfileOption();
		viewProfile.click();
	}
	
	public void clickCustomerContactTab() throws IOException
	{
		container.waitForElement(30, container.getCustomerContactTab_xpath(), "xpath");
		WebElement customerContact = container.getCustomerContactTab();
		customerContact.click();
	}
	
	public void clickCreateCPNIButton() throws IOException
	{
		container.waitForElement(30, container.getCreateCPNIButton_xpath(), "xpath");
		WebElement createButton = container.getCreateCPNIButton();
		createButton.click();
	}
	
	public void fillRequiredFieldsCPNI(List <String> CPNIInfo) throws IOException, InterruptedException
	{
		CommonFunctions.switchToPopUp();
		container.waitForElement(30, container.getCreateCPNIFirstNameTextBox_xpath(), "xpath");
		WebElement CPNIFirstName=container.getCreateCPNIFirstNameTextBox();
		CPNIFirstName.sendKeys(CPNIInfo.get(0));
		
		WebElement CPNILastName=container.getCreateCPNILastNameTextBox();
		CPNILastName.sendKeys(CPNIInfo.get(1));
		
		WebElement CPNIRole=container.getCreateCPNIRoleDropDown();
		CPNIRole.sendKeys(CPNIInfo.get(2));
		
		WebElement CPNITitle=container.getCreateCPNITitleTexBox();
		CPNITitle.sendKeys(CPNIInfo.get(3));
		
		WebElement CPNIEmail=container.getCreateCPNIEmailTexBox();
		CPNIEmail.sendKeys(CPNIInfo.get(4));
		
		WebElement CPNIAddress1=container.getCreateCPNIAddressL1TexBox();
		CPNIAddress1.sendKeys(CPNIInfo.get(5));
		
		WebElement CPNIAddress2=container.getCreateCPNIAddressL2TexBox();
		CPNIAddress2.sendKeys(CPNIInfo.get(6));
		
		WebElement CPNIAddress3=container.getCreateCPNIAddressL3TexBox();
		CPNIAddress3.sendKeys(CPNIInfo.get(7));
		
		WebElement CPNICity=container.getCreateCPNICityTexBox();
		CPNICity.sendKeys(CPNIInfo.get(8));
		
		WebElement CPNICountry=container.getCreateCPNICountryDropDown();
		new Select(CPNICountry).selectByVisibleText(CPNIInfo.get(9));
		
		Thread.sleep(3000);
	
		container.waitForElement(30, container.getCreateCPNIStateDropDown_xpath(),"xpath");
		WebElement CPNIState=container.getCreateCPNIStateDropDown();
		new Select(CPNIState).selectByVisibleText(CPNIInfo.get(10));
		
		WebElement CPNIZipCode=container.getCreateCPNIZipTextBox();
		CPNIZipCode.sendKeys(CPNIInfo.get(11));
		
		WebElement CPNIWorkPhone=container.getCreateCPNIWorkPhone();
		CPNIWorkPhone.sendKeys(CPNIInfo.get(12));

	}
	
	public void clickCreateFinalCPNIButton() throws IOException
	{
		container.waitForElement(30, container.getCreateCPNISubmitCreateButton_xpath(), "xpath");
		WebElement createFinal = container.getCreateCPNISubmitCreateButton();
		createFinal.click();
	}
	
	public void addressValidationCPNI() throws IOException
	{
		container.waitForElement(30, container.getCreateCPNIAddressConfirmButton_xpath(), "xpath");
		WebElement addressValidation = container.getCreateCPNIAddressConfirmButton();
		addressValidation.click();
	}
	
	public void clickSaveChangesCPNIButton() throws IOException
	{
		container.waitForElement(30, container.getCreateCPNISaveChangesButton_xpath(), "xpath");
		WebElement saveChangesButton = container.getCreateCPNISaveChangesButton();
		saveChangesButton.click();
	}
	
	public void userCreatedSuccessfully() throws IOException
	{
		container.waitForElement(30, container.getCreateCPNIProcessSucessfullLabel_xpath(), "xpath");
		WebElement userCreated = container.getCreateCPNIProcessSucessfullLabel();
		userCreated.click();
	}
	
	//REQUEST INQUIRY
	
	public void requestInquiryOption() throws IOException
	{
		container.waitForElement(30, container.getLittleArrowCLE_xpath(), "xpath");
		WebElement littleArrow = container.getLittleArrowCLE();
		littleArrow.click();
		 
		container.waitForElement(30, container.getRequestInquiryOption_link(), "linkText");
		WebElement RIOption = container.getRequestInquiryOption();
		RIOption.click();
	}
	
	public void requestInquiryDescription(String desc) throws IOException
	{
		CommonFunctions.switchToPopUp();
		container.waitForElement(30, container.getRequestInquiryDescriptionBox_xpath(), "xpath");
		
		WebElement RIDesc = container.getRequestInquiryDescriptionBox();
		RIDesc.sendKeys(desc);
	}
	
	public void requestInquirySendButton() throws IOException
	{
		container.waitForElement(30, container.getRequestInquirySendButton_xpath(), "xpath");
		WebElement sendButton = container.getRequestInquirySendButton();
		sendButton.click();
	}
	
	public void requestInquirySuccessfullMsg() throws IOException
	{
		container.waitForElement(30, container.getRequestInquiryOpSuccessfull_css(), "cssSelector");
	}
	
	//SINGLE SEARCH
	
	public void moveToCustomerSearch() throws IOException
	{
		container.waitForElement(30, container.getCustomerHierarchyDropDown_css(), "cssSelector");
		WebElement CustomerHierarchyOption=container.getCustomerHierarchyDropDown();
		WebElement CustomerSearchOption=container.getCustomerSearchOption();
		container.action.moveToElement(CustomerHierarchyOption).moveToElement(CustomerSearchOption).click().build().perform();
		
	}
	public void seeSingleSearchPortal() throws IOException
	{
		container.waitForElement(30, container.getSingleSearchPortal_link(), "linkText");
	}
	
	public void receiveCLEtoSingleSearch(String arg1) throws IOException
	{
		container.waitForElement(30, container.getSingleSearchBar_css(), "cssSelector");
		WebElement searchBar = container.getSingleSearchBar();
		searchBar.sendKeys(arg1);
	}
	
	public void clickOnSingleSearchButton() throws IOException, InterruptedException
	{
		container.waitForElement(30, container.getSingleSearchButton_xpath(), "xpath");
		WebElement searchButton = container.getSingleSearchButton();
		searchButton.click();
	}
	
	public void getSingleSearchCLEInfo() throws IOException
	{
		container.waitForElement(60, container.getSingleSearchCLEInfo_xpath(), "xpath");
	}
	
	//TAX ATTRIBUTES
	
	public void clickOnTaxAtUpdateIcon() throws IOException
	{
		container.waitForElement(30, container.getTaxAtrUpdateIcon_xpath(), "xpath");
		WebElement taxIDUpdateIcon = container.getTaxAtrUpdateIcon();
		taxIDUpdateIcon.click();
	}
	
	public void getUpdateTaxIDPopup() throws IOException
	{
		CommonFunctions.switchToPopUp();
		container.waitForElement(30, container.getTaxAtrSaveChangesButton_xpath(), "xpath");
	}
	
	public void taxIdPassed(String taxid)
	{
		TAX_ID=taxid;
	}
	
	public void clickOnTaxIDSaveChanges() throws IOException
	{
		new Select(container.getTaxAtrDropDown()).selectByVisibleText("Employer ID No.");
		container.waitForElement(30, container.getTaxAtrTextbox_xpath(), "xpath");
		WebElement TaxIDTextbox = container.getTaxAtrTextbox();
		
		TaxIDTextbox.clear();
		TaxIDTextbox.sendKeys(TAX_ID);	
		
		container.waitForElement(30, container.getTaxAtrSaveChangesButton_xpath(), "xpath");
		WebElement savechanges = container.getTaxAtrSaveChangesButton();
		savechanges.click();
	}
	
	public void TaxIDModified() throws IOException
	{
		container.waitForElement(30, container.getTaxAtrModified_xpath(), "xpath");
	}
	
	////////////////////////////////////VICTOR MERAN'S PART///////////////////////////////////////////
	
	public void clickOnCreateLE() {
		
		container.getCreateLegalEntityButton().click();
	}
	
	public void provideLEName(String name) throws IOException {
		
		CommonFunctions.switchToPopUp();
		container.waitForElement(10, container.getLENameInputField_xpath(), "xpath");
		container.getLENameInputField().sendKeys(name);
	}
	
	public void provideLEAddress(String address) {
		
		container.getLEAddressLineInputField().sendKeys(address);
	}
	
	public void provideLECity(String city) {
		
		container.getLECityInputField().sendKeys(city);
	}
	
	public void selectLECountryDropdown() {
		
		container.getLECountryDropdown().click();
	}
	
	public void selectLEStateDropdown() throws InterruptedException {
		
		Thread.sleep(2000);
		container.getLEStateDropdown().click();
	}
	
	public void provideLEZIPPostcode(String zipcode) {
		
		container.getLEZIPPostcodeInputField().sendKeys(zipcode);
	}
	
	public void provideLEMainTelephoneNumber(String phonenumber) {
		
		container.getLEMainTelephoneNumberInputField().sendKeys(phonenumber);
	}
	
	public void clickLECreateButton() {
		
		container.getLECreateButton().click();
	}
	
	public void clickLEYesButton() throws IOException {
		
		container.waitForElement(30, container.getLEYesButton_xpath(), "xpath");
		container.getLEYesButton().click();
	}
	
	public void clickLEOKButton() throws IOException {
		
		container.waitForElement(10, container.getLEOKButton_xpath(), "xpath");
		container.getLEOKButton().click();
	}
	
	public void searchForCLE(String cle) {
		
		container.getCLESearchField().sendKeys(cle);
		container.getSearchButton().click();
		searchedCLE = cle;
	}
	
	public void clickArrowDropdown() throws IOException, InterruptedException {
		container.waitForElement(10, container.getArrowDropdownMenu_xpath(), "xpath");
		Thread.sleep(2000);
		container.getArrowDropdownMenu().click();
	}
	
	public void selectRequestLegalNameChange() {
		
		container.getRequestLegalNameChange().click();
	}
	
	public void provideLENameRequestChange_1(String name) throws IOException {
		
		CommonFunctions.switchToPopUp();
		container.waitForElement(10, container.getRequestLegalNameChange1LENameInputField_xpath(), "xpath");
		container.getRequestLegalNameChange1LENameInputField().clear();
		container.getRequestLegalNameChange1LENameInputField().sendKeys(name);
	}
	
	public void clickRequestLegalNameChange1SubmitButton() {
		
		container.getRequestLegalNameChange1SubmitButton().click();
	}
	
	public void clickRequestLegalNameChange1OKButton() throws IOException {
		
		CommonFunctions.switchToPopUp();
		container.waitForElement(10, container.getRequestLegalNameChange1OKButton_xpath(), "xpath");
		container.getRequestLegalNameChange1OKButton().click();
	}
	
	public void clickViewProfile() {
		
		container.getViewProfile().click();
	}
	
	public void clickEntityInformationTab() throws IOException {
		container.waitForElement(10, container.getEntityInformationTab_xpath(), "xpath");
		container.getEntityInformationTab().click();
	}
	
	public void clickAddressNameChangeIcon() throws IOException {
		container.waitForElement(10, container.getAddressNameChangeRequest_xpath(), "xpath");
		container.getAddressNameChangeRequest().click();
	}
	
	public void selectNameChangeOption() throws IOException {
		
		CommonFunctions.switchToPopUp();
		container.waitForElement(10, container.getChangeRequestForName_xpath(), "xpath");
		container.getChangeRequestForName().click();
	}
	
	public void clickUpdateButton() {
		
		container.getUpdateButton().click();
	}
	
	public void provideNameChangePopup(String name) throws IOException {
		
		CommonFunctions.switchToPopUp();
		container.waitForElement(10, container.getRequestLegalNameChange2LENameInputField_xpath(), "xpath");
		container.getRequestLegalNameChange2LENameInputField().clear();
		container.getRequestLegalNameChange2LENameInputField().sendKeys(name);
	}
	
	public void clickRequestLegalNameChange2SubmitButton() {
		
		container.getRequestLegalNameChange2SubmitButton().click();
	}
	
	public void clickRequestLegalNameChange2OKButton() throws IOException {
		
		CommonFunctions.switchToPopUp();
		container.waitForElement(10, container.getRequestLegalNameChange2OKButton_xpath(), "xpath");
		container.getRequestLegalNameChange2OKButton().click();
	}
	
	public void clickRequestLegalAddressChange() {
		
		container.getRequestLegalAddressChange().click();
	}
	
	public void provideAddressLine_1(String address) throws IOException, InterruptedException {
		CommonFunctions.switchToPopUp();
		container.waitForElement(10, container.getRequestLegalAddressChangeAddressLine1InputField_1_xpath(), "xpath");
		Thread.sleep(3000);
		WebElement inputField = container.getRequestLegalAddressChangeAddressLine1InputField_1();
		inputField.clear();
		inputField.sendKeys(address);
	}
	
	public void provideCity_1(String city) {
		
		container.getRequestLegalAddressChangeCityInputField_1().clear();
		container.getRequestLegalAddressChangeCityInputField_1().sendKeys(city);
	}
	
	public void selectCountry_1() {
		
		container.getRequestLegalAddressChangeCountrySelect_1().click();
		
	}
	
	public void selectState_1() throws InterruptedException {
		Thread.sleep(2000);
		container.getRequestLegalAddressChangeStateSelect_1().click();
	}
	
	public void provideZIPcode_1(String zipcode) {
		
		container.getRequestLegalAddressChangeZIPPostCodeInputField_1().clear();
		container.getRequestLegalAddressChangeZIPPostCodeInputField_1().sendKeys(zipcode);
	}
	
	public void clickRequestLegalAddressChangeSubmitButton_1() {
		
		container.getRequestLegalAddressChangeSubmitButton_1().click();
	}
	
	public void clickRequestLegalAddressChangeYesButton_1() throws IOException, InterruptedException {
		
		CommonFunctions.switchToPopUp();
		container.waitForElement(30, container.getRequestLegalAddressChangeYesButton_1_xpath(), "xpath");
		Thread.sleep(3000);
		container.getRequestLegalAddressChangeYesButton_1().click();
	}
	
	public void clickRequestLegalAddressChangeOKButton_1() throws IOException, InterruptedException {
		
		CommonFunctions.switchToPopUp();
		container.waitForElement(30, container.getRequestLegalAddressChangeOKButton_1_xpath(), "xpath");
		Thread.sleep(3000);
		container.getRequestLegalAddressChangeOKButton_1().click();
	}
	
	public void selectAddressChangeOption() throws IOException {
		
		container.waitForElement(30, container.getChangeRequestForAddress_xpath(),"xpath");
		container.getChangeRequestForAddress().click();
	}
	
	public void provideAddressLine_2(String address) throws IOException {
		
		CommonFunctions.switchToPopUp();
		container.waitForElement(30, container.getRequestLegalAddressChangeAddressLine1InputField_2_xpath(), "xpath");
		container.getRequestLegalAddressChangeAddressLine1InputField_2().clear();
		container.getRequestLegalAddressChangeAddressLine1InputField_2().sendKeys(address);
	}
	
	public void provideCity_2(String city) {
		
		container.getRequestLegalAddressChangeCityInputField_2().clear();
		container.getRequestLegalAddressChangeCityInputField_2().sendKeys(city);
	}
	
	public void selectCountry_2() {
		
		
		container.getRequestLegalAddressChangeCountrySelect_2().click();
		
	}
	
	public void selectState_2() throws InterruptedException {
		Thread.sleep(2000);
		container.getRequestLegalAddressChangeStateSelect_2().click();
			
	}
	
	public void provideZIPcode_2(String zipcode) {
		
		container.getRequestLegalAddressChangeZIPPostCodeInputField_2().clear();
		container.getRequestLegalAddressChangeZIPPostCodeInputField_2().sendKeys(zipcode);
	}
	
	public void clickRequestLegalAddressChangeSubmitButton_2() {
		
		container.getRequestLegalAddressChangeSubmitButton_2().click();
	}
	
	public void clickRequestLegalAddressChangeYesButton_2() throws IOException {
		
		CommonFunctions.switchToPopUp();
		container.waitForElement(10, container.getRequestLegalAddressChangeYesButton_2_xpath(), "xpath");
		container.getRequestLegalAddressChangeYesButton_2().click();
	}
	
	public void clickRequestLegalAddressChangeOKButton_2() throws IOException {
		
		CommonFunctions.switchToPopUp();
		container.waitForElement(10, container.getRequestLegalAddressChangeOKButton_2_xpath(), "xpath");
		container.getRequestLegalAddressChangeOKButton_2().click();
	}
	
	
	///////////////////////////////////////////JOSE VARGAS' PART////////////////////////////////////////////////////
	
	
	
	public void viewProfileForFirstResult(){
		container.getFirstArrowMenu().click();
		container.getFirstViewProfileMenuItem().click();
	}
	
	
	public void goToManageBillingAccounts(){
		container.getManageBillingAccount().click();
	}
	
	public void clicksCreateCustomerGroup(){
		container.getCreateCustomerGroupButton().click();
	}
	
	public void inputGroupName(String newGroupName) throws InterruptedException{
		Thread.sleep(1000);
		container.getInputForCustomerGroupName().sendKeys(newGroupName);
		groupName = newGroupName;
	}
	
	public void clickCreateGroupSubmitButton(){
		container.getCreateCustomerGroupSubmitButton().click();
	}
	
	public boolean isCreatedGroupMessageDisplayed(){
		return container.getCreatedGroupMessage(groupName).isDisplayed();
	}
	
	public void clickOnManageAccountNumbers(){
		container.getManageAccountNumbers().click();
	}
	
	public void selectsAccountNumberAndCustomerGroup() throws InterruptedException{
		container.getFirstAccountNumberCheckBox().click();
		Thread.sleep(2000);
		container.getFirstCustomerGroupRadioButton().click();
		Thread.sleep(2000);
	}
	
	public void changeCustomerGroupId() throws InterruptedException{
		container.getActionsButtonOnManageAccounts().click();
		//Thread.sleep(2000);
		container.getChangeCustomerGroupID().click();
	}
	
	public boolean isMovedGroupMessageDisplayed(){
		return container.getMoveNotification().isDisplayed();
	}
	
	public void viewSensitivityForFirstProfole(){
		container.getFirstArrowMenu().click();
		container.getUpdateSensitivity().click();
	}
	
	public void changeGSAMSensitivity(){
		container.getGSAMSensitivityDropDown().selectByVisibleText("Security Sensitive");
	}
	
	public void moveFirstCountryToSelectedSide() throws InterruptedException{
		container.getGSAMSensitivityCountrySelect().selectByIndex(0);
		Thread.sleep(2000);
		container.getAddSelectedSensisitivityItemButton().click();
		Thread.sleep(2000);
	}
	
	public void clickSaveChangesButton(){
		container.getSensitivitySaveChangesButton().click();
	}
	
	public void acceptSuccesfulPrompt(){
		container.getOperationSuccesfulButton().click();
	}
	
	public void navigateToManageServices(){
		container.getManageServicesButton().click();
	}
	
	public void addUpdatePONumberForService(){
		container.getActionsButtonOnManageAccounts().click();
		container.getAddUpdateLocationPONumber().click();
	}
	
	public boolean isPONumberUpdateScreenDisplayed(){
		return container.getPONumberUpdateServiceScreen().isDisplayed();
	}
	
	public void clickUpdateTaxationAttribute(){
		container.getUpdateTaxationAttributesButton().click();
	}
	
	public void checkApprovedTaxAttribute(){
		container.getTaxationAttributeUpdateCheckBox().click();
	}
	
	public void propagateChanges(){
		container.getUpdateConfirmationButton().click();
	}
	
	public void selectAccountsToPropagate() throws InterruptedException{
		//Thread.sleep(2000);
		container.getCheckBoxForTaxationBanPropagation().click();
		container.getSensitivitySaveChangesButton().click();
	}
	
	public void acceptPropagationConfirmation(){
		container.getBanPropagationConfirmationOKButton().click();
	}
	
	public void changeGSAMSensitivity(String sensitivity){
		container.getGSAMSensitivityDropDown().selectByVisibleText(sensitivity);
	}
	
}

