package com.vz.gch.views;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.vz.gch.containers.SingleSearchContainer;

public class SingleSearch {


	private SingleSearchContainer container;

	
	private CommonFunctions common;
	
	
	public SingleSearch (WebDriver driver)
	{
		container=new SingleSearchContainer(driver);
		common=new CommonFunctions(driver);
	}
	
	public void getSingleSearchPortal() throws IOException
	{
		container.waitForElement(60, container.getSSSearchBar_xpath(), "xpath");
	}
	
	public void searchForBIC(String BIC) throws InterruptedException, IOException
	{
		WebElement SSSearchBar1=container.getSSSearchBar();
		SSSearchBar1.sendKeys(BIC);
		container.waitForElement(10, container.getSSSearchButton_id(), "ById");
		WebElement SSSearchButton1=container.getSSSearchButton();
		Thread.sleep(3000);
		SSSearchButton1.submit();
	
	}
	
	public void BICFound() throws IOException
	{
		container.waitForElement(30, container.getSSBICFound_xpath(), "xpath");
	}
	
	public void clickOnLEIDLink() throws IOException, InterruptedException
	{
		container.waitForElement(10, container.getSSLEIDLink_xpath(), "xpath");
		WebElement SSLEID=container.getSSLEIDLink();
		SSLEID.click();
		
	}
	
	public void clickOnViewCLEProfileOption() throws IOException
	{
		container.waitForElement(10, container.getSSViewCLEProfileOption_xpath(), "xpath");
		WebElement SSViewCLEProfileOption1=container.getSSViewCLEProfileOption();
		SSViewCLEProfileOption1.click();
	}
	
	public void getCLEprofileScreen() throws IOException
	{
		CommonFunctions.switchToPopUp();
		container.waitForElement(30, container.getSSCLEPopupScreen_xpath(), "xpath");
	}
	
	public void clickOnViewInVECRMOption() throws IOException
	{
		container.waitForElement(10, container.getSSViewInVECRMOption_xpath(), "xpath");
		WebElement SSViewInVECRMOption1=container.getSSViewInVECRMOption();
		SSViewInVECRMOption1.click();
	}
	
	public void getVECRMProfileScreen() throws IOException
	{
		CommonFunctions.switchToPopUp();
		container.waitForElement(30, container.getSSVECRMScreen_ID(), "ById");
	}
	
	public void clickOnViewInventoryInSMD() throws IOException
	{
		container.waitForElement(10, container.getSSViewInventorySMDOption_xpath(), "xpath");
		WebElement SSViewInventoryInSMDOption1=container.getSSViewInventorySMDOption();
		SSViewInventoryInSMDOption1.click();
	}
	
	public void getInventoryInSMDScreen() throws IOException
	{
		container.waitForElement(30, container.getSSViewInventorySMDScreen_xpath(), "xpath");
	}
	
	public void clickOnViewAlarmsInSMD() throws IOException
	{
		container.waitForElement(10, container.getSSViewAlarmsInSMDOption_xpath(), "xpath");
		WebElement SSViewAlarmsInSMDOption1=container.getSSViewAlarmsInSMDOption();
		SSViewAlarmsInSMDOption1.click();
	}
	
	public void getAlarmsInSMDScreen() throws IOException
	{
		container.waitForElement(30, container.getSSViewAlarmsInSMDScreen_xpath(), "xpath");
	}
	
	public void clickOnViewTopologyInSMD() throws IOException
	{
		container.waitForElement(10, container.getSSViewTopologyInSMDOption_xpath(), "xpath");
		WebElement SSViewTopologyInSMDOption1=container.getSSViewTopologyInSMDOption();
		SSViewTopologyInSMDOption1.click();
	}
	
	public void getTopologyInSMDScreen() throws IOException
	{
		container.waitForElement(30, container.getSSViewTopologyInSMDScreen_xpath(), "xpath");
	}
	
	public void clickOnServiceMgmtReporting() throws IOException
	{
		container.waitForElement(10, container.getSSServiceMgmtReportingOption_xpath(), "xpath");
		WebElement SSServiceMgmtReporting1=container.getSSServiceMgmtReportingOption();
		SSServiceMgmtReporting1.click();
	}
	
	public void getServiceMgmtReportingScreen() throws IOException
	{	
		container.waitForElement(10, container.getSSServiceMgmtReportingScreen_xpath(), "xpath");
	}
	
	public void clickOnBillingAccountViewLink() throws IOException, InterruptedException
	{
		container.waitForElement(10, container.getSSBillingAccountLinkView_link(), "linkText");
		WebElement SSBillingAccountViewLink1=container.getSSBillingAccountLinkView();
		Thread.sleep(2000);
		SSBillingAccountViewLink1.click();
		CommonFunctions.switchToPopUp();
		
	}
	
	public void getBillingAccountViewLinkScreen() throws IOException
	{
		container.waitForElement(10, container.getSSBillingAccountLinkViewScreen_xpath(), "xpath");
	}
	
	public void getVECRMApprovalButton() throws IOException
	{
		CommonFunctions.maximizeBrowser();
		container.waitForElement(30, container.getSSVECRMPolicyAcceptButton_css(), "cssSelector");
		WebElement SSVECRMPolicyAcceptButton1=container.getSSVECRMPolicyAcceptButton();
		SSVECRMPolicyAcceptButton1.click();
	}	
	
}
