package com.vz.gch.views;

import java.io.IOException;
import java.util.ArrayList;

import junit.framework.Assert;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.vz.gch.containers.LegalViewContainer;


public class LegalView {

	public LegalViewContainer container;
	public CommonFunctions common;
	private WebElement LegalViewTab;
	private WebElement CompanyNameTextBox;
	private WebElement CompanyIDTextBox;
	private WebElement BillingNameTextBox;
	private WebElement BillingNumberTextBox;
	private WebElement Company_Billing_RadioButton;
	private WebElement SearchButton;
	private WebElement TopCompanyNameSort;
	private WebElement TopCompanyIDSort;
	private WebElement CompanyNameSort;
	private WebElement CompanyIDSort;
	private WebElement CountrySort;
	private WebElement MarketingSegmentSort;
	private WebElement AccountManagerSort;
	private WebElement programNameSort;
	private WebElement Pagination;
	private WebElement Bill;
	
	private WebElement WorkFlowTaskTab;
	private WebElement SourceCompanyNameTextBox;
	private WebElement SourceCompanySegmentDropDown;
	private WebElement StatusFilterDropDown;
	private WebElement TaskIdTextBox;
	private WebElement TargetCompanyNameTextBox;
	private WebElement TargetCompanySegmentDropDown;
	private WebElement RequestorDropDown;
	private WebElement EventTypeDropDown;
	private WebElement WorkFlowTaskSearchButton;
	
	private WebElement OrphanBansOnlyCheckBox;
	private WebElement Managed_SummaryBansCheckBox;
	private WebElement SalesViewBansOnlyCheckBox;
	private WebElement TreeViewIcon;
	private WebElement TypeInBilling;
	private WebElement DnBLookupTab;
	private WebElement DnBLookupCompanyNameTextBox;
	private WebElement DnBLookupSearchButton;
	private WebElement DnBLookupSearchResults;
	private WebElement DnBLookupDUNSTextBox;
	private WebElement DnBLookupCityTextBox;
	private WebElement DnBLookupGudunsNameTextBox;
	private WebElement DnBLookupTradeStyleNameTextBox;
	private WebElement DnBLookupStateDropDown;
	private WebElement DnBLookupGUDUNSTextBox;
	private WebElement DnBLookupSecondaryTradeStyleNameTextBox;
	private WebElement DnBLookupZIPTextBox;
	private WebElement DnBLookupStreetTextBox;
	private WebElement DnBLookupCountryTextBox;
	private WebElement DnBLookupPaginationButton;
	private WebElement DnBLookupPaginationResults;
	
	
	private String TypeInBillingTextBoxText;
	private String BlankSpace;
	
	public LegalView(WebDriver driver) {
		container = new LegalViewContainer(driver);
		common = new CommonFunctions(driver);
		BlankSpace="";
	}
	
	public void clickOnLegalViewTab() throws IOException
	{
		container.waitForElement(30, container.getLegalViewTab_xpath(), "xpath");
		LegalViewTab=container.getLegalViewTab();
		LegalViewTab.click();
		container.waitForElement(30, container.getLegalViewFrame_id(), "ById");
		
	}
	
	public void lookupForCompanyName(String CompanyName) throws IOException
	{
		CommonFunctions.switchFrame(container.getLegalViewFrame());
		container.waitForElement(30, container.getLegalViewCompanyNameTextBox_xpath(), "xpath");
		CompanyNameTextBox=container.getLegalViewCompanyNameTextBox();
		CompanyNameTextBox.sendKeys(CompanyName);
	}
	
	public void clickOnWFSearchButton()
	{
		SearchButton=container.getLegalViewSearchButton();
		SearchButton.click();
	}
	public void clickOnSearchButton()
	{
		SearchButton=container.getLegalViewHTMSearchButton();
		SearchButton.click();
	}
	
	public void getSearchCompanyResults() throws IOException
	{
		container.waitForElement(30, container.getSearchCompanyResults_id(), "ById");
	}
	
	public void lookupForCompanyID(String CompanyID) throws IOException
	{
		CommonFunctions.switchFrame(container.getLegalViewFrame());
		container.waitForElement(30, container.getLegalViewCompanyIDTextBox_xpath(), "xpath");
		CompanyIDTextBox=container.getLegalViewCompanyIDTextBox();
		CompanyIDTextBox.sendKeys(CompanyID);
	}
	
	public void shiftRadioButtonToBilling()
	{
		Company_Billing_RadioButton=container.getLegalViewCompany_BillingAccRadioButton();
		Company_Billing_RadioButton.click();
	}
	public void lookupForBillingName(String BillingName) throws IOException
	{
		CommonFunctions.switchFrame(container.getLegalViewFrame());
		container.waitForElement(30, container.getLegalViewBillingNameTextBox_id(), "ById");
		shiftRadioButtonToBilling();
		BillingNameTextBox=container.getLegalViewBillingNameTextBox();
		BillingNameTextBox.sendKeys(BillingName);
		TypeInBillingTextBoxText=BillingName;
	}
	
	public void getSearchBillingResults() throws IOException
	{
		container.waitForElement(30, container.getSearchBillingResults_id(), "ById");
	}
						//SEARCH FOR BILLING ACCOUNT NUMBER//
	public void lookupForBillingAccountNumber(String BillingAccNumb) throws IOException
	{
		CommonFunctions.switchFrame(container.getLegalViewFrame());
		container.waitForElement(30, container.getLegalViewBillingAccNumbTextBox_id(), "ById");
		shiftRadioButtonToBilling();
		BillingNumberTextBox=container.getLegalViewBillingAccNumbTextBox();
		BillingNumberTextBox.sendKeys(BillingAccNumb);
		TypeInBillingTextBoxText=BillingAccNumb;
		
	}
	
	public void sortingHMTColumns() throws IOException, InterruptedException
	{
		container.waitForElement(30, container.getTopCompanyNameSort_id(), "ById");
		
		
		/*
		TopCompanyNameSort=container.getTopCompanyNameSort();
		TopCompanyNameSort.click();
		//CommonFunctions.waitForPageToLoad(5000);
		Thread.sleep(5000);
		if(!container.sortTopCompanyName())
		{
			Assert.assertTrue("Top Company Name not sorted correctly", false);
		}
		
		TopCompanyIDSort=container.getTopCompanyIDSort();
		TopCompanyIDSort.click();
		//CommonFunctions.waitForPageToLoad(5000);
		Thread.sleep(5000);
		if(!container.sortTopCompanyID())
		{
			Assert.assertTrue("Top Company ID not sorted correctly", false);
		}
		
		CompanyNameSort=container.getCompanyNameSort();
		CompanyNameSort.click();
		//CommonFunctions.waitForPageToLoad(5000);
		Thread.sleep(5000);
		if(!container.sortCompanyName())
		{
			Assert.assertTrue("Company Name not sorted correctly", false);
		}
		
		*/

	}
	
	public void getHMTPagination() throws IOException, InterruptedException
	{
		container.waitForElement(30, container.getPaginationSort_id(), "ById");
		Thread.sleep(4000);
		Pagination=container.getPaginationSort();
		Pagination.click();
		CommonFunctions.waitForPageToLoad(4000);
		
	}

	public void getNextPageSeen() throws IOException
	{
		CommonFunctions.switchFrame(container.getLegalViewFrame());
		container.waitForElement(30, container.getAccountMgrTextBox_id(), "ById");
	}
	
	public void HMTBillingNamesearchIncludingCheckBox() throws InterruptedException, IOException
	{
		HMTsearchIncludingCheckBox("BillingName");
	}
	
	public void HMTBillingAccNumbsearchIncludingCheckBox() throws InterruptedException, IOException
	{
		HMTsearchIncludingCheckBox("BillingAccNumb");
	}
	
	public void HMTsearchIncludingCheckBox(String Billing) throws InterruptedException, IOException
	{
		
		if(Billing.equalsIgnoreCase("BillingName"))
		{
			Bill=container.getLegalViewBillingNameTextBox();
		}
		else if(Billing.equalsIgnoreCase("BillingAccNumb"))
		{
			Bill=container.getLegalViewBillingAccNumbTextBox();
		}
		
		TypeInBilling=Bill;
		TypeInBilling.clear();
		
		OrphanBansOnlyCheckBox=container.getOrphanBansCheckboxSort();
		OrphanBansOnlyCheckBox.click();
		
		
		TypeInBilling.sendKeys(TypeInBillingTextBoxText);
		SearchButton=container.getLegalViewHTMSearchButton();
		SearchButton.click();
		CommonFunctions.waitForPageToLoad(4000);
		CommonFunctions.switchFrame(container.getLegalViewFrame());
		container.waitForElement(30, container.getAccountMgrTextBox_id(), "ById");
		
		OrphanBansOnlyCheckBox=container.getOrphanBansCheckboxSort();
		OrphanBansOnlyCheckBox.click();
		
		
		//CommonFunctions.switchFrame(container.getLegalViewFrame());
		//Thread.sleep(5000);
		
		if(Billing.equalsIgnoreCase("BillingName"))
		{
			Bill=container.getLegalViewBillingNameTextBox();
		}
		else if(Billing.equalsIgnoreCase("BillingAccNumb"))
		{
			Bill=container.getLegalViewBillingAccNumbTextBox();
		}
		
		TypeInBilling=Bill;
		TypeInBilling.clear();
		
		Managed_SummaryBansCheckBox=container.getmanaged_summaryCheckboxSort();
		Managed_SummaryBansCheckBox.click();
		
		
		TypeInBilling.sendKeys(TypeInBillingTextBoxText);
		SearchButton=container.getLegalViewHTMSearchButton();
		SearchButton.click();
		CommonFunctions.waitForPageToLoad(3000);
		CommonFunctions.switchFrame(container.getLegalViewFrame());
		container.waitForElement(30, container.getAccountMgrTextBox_id(), "ById");
		
		Managed_SummaryBansCheckBox=container.getmanaged_summaryCheckboxSort();
		Managed_SummaryBansCheckBox.click();
		
		if(Billing.equalsIgnoreCase("BillingName"))
		{
			Bill=container.getLegalViewBillingNameTextBox();
		}
		else if(Billing.equalsIgnoreCase("BillingAccNumb"))
		{
			Bill=container.getLegalViewBillingAccNumbTextBox();
		}
		
		TypeInBilling=Bill;
		TypeInBilling.clear();
		
		SalesViewBansOnlyCheckBox=container.getSalesViewBansCheckboxSort();
		SalesViewBansOnlyCheckBox.click();
		
		TypeInBilling=Bill;
		TypeInBilling.sendKeys(TypeInBillingTextBoxText);
		SearchButton=container.getLegalViewHTMSearchButton();
		SearchButton.click();
		CommonFunctions.waitForPageToLoad(3000);
		CommonFunctions.switchFrame(container.getLegalViewFrame());
		container.waitForElement(30, container.getAccountMgrTextBox_id(), "ById");
		
		SalesViewBansOnlyCheckBox=container.getSalesViewBansCheckboxSort();
		SalesViewBansOnlyCheckBox.click();
		
		if(Billing.equalsIgnoreCase("BillingName"))
		{
			Bill=container.getLegalViewBillingNameTextBox();
		}
		else if(Billing.equalsIgnoreCase("BillingAccNumb"))
		{
			Bill=container.getLegalViewBillingAccNumbTextBox();
		}
		
		TypeInBilling=Bill;
		TypeInBilling.clear();
	}
	
	public void checkFilteringResults() throws IOException, InterruptedException
	{
		CommonFunctions.waitForPageToLoad(3000);
		CommonFunctions.switchFrame(container.getLegalViewFrame());
		container.waitForElement(30, container.getAccountMgrTextBox_id(), "ById");
	}
	
	public void clickonTreeView()
	{
		TreeViewIcon=container.getTreeViewIcon();
		TreeViewIcon.click();
	}
	
	public void viewCompanyTreeView() throws IOException
	{
		container.waitForElement(30, container.getTreeViewLabel_css(), "cssSelector");	
	}
	
	public void clickOnWorkflowTaskTab() throws IOException, InterruptedException
	{
		
		container.waitForElement(30, container.getWorkflowTaskTab_xpath(), "xpath");
		WorkFlowTaskTab=container.getWorkflowTaskTab();
		WorkFlowTaskTab.click();
		container.waitForElement(30,container.getSourceCompanyNameTextBox_xpath(), "xpath");
		CommonFunctions.maximizeBrowser();
	}
	
	
	public void searchBySourceCompanyName(String SourceCompanyName)
	{
		SourceCompanyNameTextBox=container.getSourceCompanyNameTextBox();
		SourceCompanyNameTextBox.sendKeys(SourceCompanyName);
		WorkFlowTaskSearchButton=container.getWorkflowTaskSearchButton();
		WorkFlowTaskSearchButton.click();
	}
	
	public void searchBySourceCompanySegment(String SourceCompanySegment) 
	{
		SourceCompanyNameTextBox=container.getSourceCompanyNameTextBox();
		SourceCompanyNameTextBox.clear();
		
		SourceCompanySegmentDropDown=container.getSourceCompanySegmentDropDown();
		new Select(SourceCompanySegmentDropDown).selectByVisibleText(SourceCompanySegment);
		WorkFlowTaskSearchButton=container.getWorkflowTaskSearchButton();
		WorkFlowTaskSearchButton.click();
	}
	
	public void searchByStatusFilter(String StatusFilter)
	{
		SourceCompanySegmentDropDown=container.getSourceCompanySegmentDropDown();
		new Select(SourceCompanySegmentDropDown).selectByVisibleText(BlankSpace);
		
		StatusFilterDropDown=container.getStatusFilterDropDown();
		new Select(StatusFilterDropDown).selectByVisibleText(StatusFilter);
		WorkFlowTaskSearchButton=container.getWorkflowTaskSearchButton();
		WorkFlowTaskSearchButton.click();
	}
	
	public void searchByTaskId(String TaskId)
	{
		StatusFilterDropDown=container.getStatusFilterDropDown();
		new Select(StatusFilterDropDown).selectByVisibleText(BlankSpace);
		
		TaskIdTextBox=container.getTaskIdTextBox();
		TaskIdTextBox.sendKeys(TaskId);
		WorkFlowTaskSearchButton=container.getWorkflowTaskSearchButton();
		WorkFlowTaskSearchButton.click();
	}
	
	public void searchByTargetCompanyName(String TargetCompanyName)
	{
		TaskIdTextBox=container.getTaskIdTextBox();
		TaskIdTextBox.clear();
		
		TargetCompanyNameTextBox=container.getTargetCompanyNameTextBox();
		TargetCompanyNameTextBox.sendKeys(TargetCompanyName);
		WorkFlowTaskSearchButton=container.getWorkflowTaskSearchButton();
		WorkFlowTaskSearchButton.click();
	}
	
	public void searchByTargetCompanySegment(String TargetCompanySegment)
	{
		TargetCompanyNameTextBox=container.getTargetCompanyNameTextBox();
		TargetCompanyNameTextBox.clear();
		
		TargetCompanySegmentDropDown=container.getTargetCompanySegmentDropDown();
		new Select(TargetCompanySegmentDropDown).selectByVisibleText(TargetCompanySegment);
		WorkFlowTaskSearchButton=container.getWorkflowTaskSearchButton();
		WorkFlowTaskSearchButton.click();
	}
	
	public void searchByRequestor(String Requestor)
	{
		TargetCompanySegmentDropDown=container.getTargetCompanySegmentDropDown();
		new Select(TargetCompanySegmentDropDown).selectByVisibleText(BlankSpace);
		
		RequestorDropDown=container.getRequestorDropDown();
		new Select(RequestorDropDown).selectByVisibleText(Requestor);
		WorkFlowTaskSearchButton=container.getWorkflowTaskSearchButton();
		WorkFlowTaskSearchButton.click();
	}
	
	public void searchByEventType(String EventType)
	{
		RequestorDropDown=container.getRequestorDropDown();
		new Select(RequestorDropDown).selectByVisibleText(BlankSpace);
		
		EventTypeDropDown=container.getEventTypeDropDown();
		new Select(EventTypeDropDown).selectByVisibleText(EventType);
		WorkFlowTaskSearchButton=container.getWorkflowTaskSearchButton();
		WorkFlowTaskSearchButton.click();
	}
	
	public void verifyWorkflowTaskSearchResults() throws IOException
	{
		container.waitForElement(30, container.getWorkFlowTaskSearchResults_xpath(), "xpath");
	}
	
	public void clickOnDnBLookupTab() throws IOException
	{
		container.waitForElement(30, container.getDnBLookupTab_xpath(), "xpath");
		DnBLookupTab=container.getDnBLookupTab();
		DnBLookupTab.click();
	}
	
	public void DnBLookupByCompanyName(String CompanyName) throws IOException, InterruptedException
	{
		CommonFunctions.waitForPageToLoad(3000);
		CommonFunctions.switchFrame(container.getLegalViewFrame());
		container.waitForElement(30, container.getDnBCompanyNameTextBox_xpath(), "xpath");
		DnBLookupCompanyNameTextBox=container.getDnBCompanyNameTextBox();
		DnBLookupCompanyNameTextBox.sendKeys(CompanyName);
		
	}
	
	public void DnBLookupSearchButtonClick()
	{
		DnBLookupSearchButton=container.getDnBSearchButton();
		DnBLookupSearchButton.click();
	}
	public void DnBLookupSearchResults() throws IOException
	{
		container.waitForElement(30, container.getDnBSearchResults_id(), "ById");
	}
	
	public void DnBLookupByDUNS(String DUNS) throws IOException
	{
		container.waitForElement(30, container.getDnBDunsTextBox_xpath(), "xpath");
		
		DnBLookupCompanyNameTextBox=container.getDnBCompanyNameTextBox();
		DnBLookupCompanyNameTextBox.clear();
		
		DnBLookupDUNSTextBox=container.getDnBDunsTextBox();
		DnBLookupDUNSTextBox.sendKeys(DUNS);
		
		
	}
	
	public void DnBLookupByCity(String City) throws IOException
	{
		container.waitForElement(30, container.getDnBCityTextBox_xpath(), "xpath");
		
		DnBLookupDUNSTextBox=container.getDnBDunsTextBox();
		DnBLookupDUNSTextBox.clear();
		
		DnBLookupCityTextBox=container.getDnBCityTextBox();
		DnBLookupCityTextBox.sendKeys(City);
		
		DnBLookupStateDropDown=container.getDnBStateDropDown();
		new Select(DnBLookupStateDropDown).selectByVisibleText("CO");
		
		
	}
	
	public void DnBLookupByGudunsName(String GudunsName) throws IOException
	{
		container.waitForElement(30, container.getDnBGudunsNameTextBox_xpath(), "xpath");
	
		DnBLookupCityTextBox=container.getDnBCityTextBox();
		DnBLookupCityTextBox.clear();
		
		DnBLookupStateDropDown=container.getDnBStateDropDown();
		new Select(DnBLookupStateDropDown).selectByVisibleText("");
		
		DnBLookupGudunsNameTextBox=container.getDnBGudunsNameTextBox();
		DnBLookupGudunsNameTextBox.sendKeys(GudunsName);
		
		
	}
	
	public void DnBLookupByTradeStyleName(String TradeStyleName) throws IOException
	{
		container.waitForElement(30, container.getDnBTradeStyleNameTextBox_xpath(), "xpath");
		
		DnBLookupGudunsNameTextBox=container.getDnBGudunsNameTextBox();
		DnBLookupGudunsNameTextBox.clear();
		
		DnBLookupTradeStyleNameTextBox=container.getDnBTradeStyleNameTextBox();
		DnBLookupTradeStyleNameTextBox.sendKeys(TradeStyleName);
		
		
	}
	
	public void DnBLookupByState(String State) throws IOException
	{
		container.waitForElement(30, container.getDnBStateDropDown_xpath(), "xpath");
		
		DnBLookupTradeStyleNameTextBox=container.getDnBTradeStyleNameTextBox();
		DnBLookupTradeStyleNameTextBox.clear();
		
		DnBLookupStateDropDown=container.getDnBStateDropDown();
		new Select(DnBLookupStateDropDown).selectByVisibleText(State);
		
		
	}
	
	public void DnBLookupByGUDUNS(String GUDUNS) throws IOException
	{
		container.waitForElement(30, container.getDnBGudunsTextBox_xpath(), "xpath");
		
		DnBLookupStateDropDown=container.getDnBStateDropDown();
		new Select(DnBLookupStateDropDown).selectByVisibleText("");
		
		DnBLookupGUDUNSTextBox=container.getDnBGudunsTextBox();
		DnBLookupGUDUNSTextBox.sendKeys(GUDUNS);
		
		
	}
	
	public void DnBLookupBySecondaryTradeStyleName(String SecondaryTradeStyleName) throws IOException
	{
		container.waitForElement(30, container.getDnBSecondaryTradeStyleNameTextBox_xpath(), "xpath");
		
		DnBLookupGUDUNSTextBox=container.getDnBGudunsTextBox();
		DnBLookupGUDUNSTextBox.clear();
		
		DnBLookupSecondaryTradeStyleNameTextBox=container.getDnBSecondaryTradeStyleNameTextBox();
		DnBLookupSecondaryTradeStyleNameTextBox.sendKeys(SecondaryTradeStyleName);
		
		
	}
	
	public void DnBLookupByZIP(String ZIP) throws IOException
	{
		container.waitForElement(30, container.getDnBZipTextBox_xpath(), "xpath");
	
		DnBLookupSecondaryTradeStyleNameTextBox=container.getDnBSecondaryTradeStyleNameTextBox();
		DnBLookupSecondaryTradeStyleNameTextBox.clear();
		
		DnBLookupZIPTextBox=container.getDnBZipTextBox();
		DnBLookupZIPTextBox.sendKeys(ZIP);
		
		DnBLookupStateDropDown=container.getDnBStateDropDown();
		new Select(DnBLookupStateDropDown).selectByVisibleText("CO");
		
		
	}
	
	public void DnBLookupByStreet(String Street) throws IOException
	{
		container.waitForElement(30, container.getDnBStreetTextBox_xpath(), "xpath");
		
		DnBLookupZIPTextBox=container.getDnBZipTextBox();
		DnBLookupZIPTextBox.clear();
		
		DnBLookupStreetTextBox=container.getDnBStreetTextBox();
		DnBLookupStreetTextBox.sendKeys(Street);
		
		DnBLookupStateDropDown=container.getDnBStateDropDown();
		new Select(DnBLookupStateDropDown).selectByVisibleText("CO");
		
		
	}
	
	public void DnBLookupByCountry(String Country) throws IOException
	{
		container.waitForElement(30, container.getDnBCountryTextBox_xpath(), "xpath");
		
		DnBLookupStreetTextBox=container.getDnBStreetTextBox();
		DnBLookupStreetTextBox.clear();
		
		DnBLookupStateDropDown=container.getDnBStateDropDown();
		new Select(DnBLookupStateDropDown).selectByVisibleText("");
		
		DnBLookupCountryTextBox=container.getDnBCountryTextBox();
		DnBLookupCountryTextBox.sendKeys(Country);

	}
	
	public void DnBLookupPaginationClick()
	{
		DnBLookupPaginationButton=container.getDnBPaginationButton();
		DnBLookupPaginationButton.click();
	}
	
	public void DnBLookupPaginationResultsClick() throws IOException
	{
		container.waitForElement(30, container.getDnBSearchResults_id(), "ById");
	}
}

