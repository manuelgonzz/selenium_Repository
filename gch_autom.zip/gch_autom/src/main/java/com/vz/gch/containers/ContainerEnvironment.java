package com.vz.gch.containers;

public class ContainerEnvironment {
	 private static String PROD_ENV = "https://gch.verizon.com/gch/cle/main.xhtml";
	 private static String QA4_ENV = "https://gchqa4.ebiz.verizon.com/gch/cle/main.xhtml";
	 private static String QA3_ENV = "https://gchqa3.ebiz.verizon.com/gch/cle/main.xhtml";
	 private static String QA2_ENV = "https://gchqa2.ebiz.verizon.com/gch/cle/main.xhtml";
	 private static String QA1_ENV = "https://gchqa1.ebiz.verizon.com/gch/cle/main.xhtml";
	 private static String UAT1_ENV = "https://gchuat1.ebiz.verizon.com/gch/cle/main.xhtml";
	 private static String UAT2_ENV = "https://gchuat2.ebiz.verizon.com/gch/cle/main.xhtml";
	 private static String SSQA4_ENV = "https://gchqa4.ebiz.verizon.com/gch/crm/search/protected/search/sglIndex.faces";
	 private static String SSQA3_ENV = "https://gchqa3.ebiz.verizon.com/gch/crm/search/protected/search/sglIndex.faces";
	 private static String SSQA2_ENV = "https://gchqa2.ebiz.verizon.com/gch/crm/search/protected/search/sglIndex.faces";
	 private static String SSQA1_ENV = "https://gchqa1.ebiz.verizon.com/gch/crm/search/protected/search/sglIndex.faces";
	 private static String SVQA1_ENV = "https://gchqa1.ebiz.verizon.com/gch/sv/main.xhtml";
	 private static String SVQA2_ENV = "https://gchqa2.ebiz.verizon.com/gch/sv/main.xhtml";
	 private static String SVQA3_ENV = "https://gchqa3.ebiz.verizon.com/gch/sv/main.xhtml";
	 private static String SVQA4_ENV = "https://gchqa4.ebiz.verizon.com/gch/sv/main.xhtml";
	 private static String NTQA1_ENV = "https://gchqa1.ebiz.verizon.com/gch/sv/salesview/nasp/naspRequestTool/NaspTool/index.html#naspTool";
	 private static String NTQA2_ENV = "https://gchqa2.ebiz.verizon.com/gch/sv/salesview/nasp/naspRequestTool/NaspTool/index.html#naspTool";
	 private static String NTQA3_ENV = "https://gchqa3.ebiz.verizon.com/gch/sv/salesview/nasp/naspRequestTool/NaspTool/index.html#naspTool";
	 private static String NTQA4_ENV = "https://gchqa4.ebiz.verizon.com/gch/sv/salesview/nasp/naspRequestTool/NaspTool/index.html#naspTool";
	 private static String NTRVQA1_ENV = "https://gchqa1.ebiz.verizon.com/gch/sv/salesview/nasp/naspRequestTool/NaspTool/index.html#nasphome/naspToolRevloc";
	 private static String NTRVQA2_ENV = "https://gchqa2.ebiz.verizon.com/gch/sv/salesview/nasp/naspRequestTool/NaspTool/index.html#nasphome/naspToolRevloc";
	 private static String NTRVQA3_ENV = "https://gchqa3.ebiz.verizon.com/gch/sv/salesview/nasp/naspRequestTool/NaspTool/index.html#nasphome/naspToolRevloc";
	 private static String NTRVQA4_ENV = "https://gchqa4.ebiz.verizon.com/gch/sv/salesview/nasp/naspRequestTool/NaspTool/index.html#nasphome/naspToolRevloc";
	 private static String GCHDBURL_QA1= "jdbc:oracle:thin:@//uiisctd1scan.ebiz.verizon.com:1800/QGCHDB1";
	 private static String GCHDBURL_QA2= "jdbc:oracle:thin:@//uiisctd1scan.ebiz.verizon.com:1800/QGCHDB2";
	 private static String GCHDBURL_QA3= "jdbc:oracle:thin:@//uiisctd1scan.ebiz.verizon.com:1800/QGCHDB3";
	 private static String GCHDBURL_QA4= "jdbc:oracle:thin:@//uiisctd1scan.ebiz.verizon.com:1800/QGCHDB4";
	 private static String GCHDBURL_UAT1= "jdbc:oracle:thin:@//gchscplnd1scan.ebiz.verizon.com:1800/UGCHDBB";
	 private static String GCHDBURL_UAT2= "jdbc:oracle:thin:@//gchscplnd1scan.ebiz.verizon.com:1800/UGCHDBA";
	 private static String GCHDBURL_PROD= "jdbc:oracle:thin:@//gchfdpd1vip.verizon.com:1800/PGCHDB";
	 public static String URL;
	 public static String DB_URL;
	 
	  public static void getEnvironment()
	    {
	    	switch(System.getProperty("env")){
	    	
	    		case "QA1":
	    		URL=QA1_ENV;
	    		break;
	    		
	    		case "QA2":
	    		URL=QA2_ENV;
	    		break;
	    		
	    		case "QA3":
	    		URL=QA3_ENV;
	    		break;
	    		
	    		case "QA4":
		    	URL=QA4_ENV;
		    	break;
		    	
	    		case "SSQA1":
		    	URL=SSQA1_ENV;
		    	break;
		    		
		    	case "SSQA2":
		    	URL=SSQA2_ENV;
		   		break;
		    		
		   		case "SSQA3":
		   		URL=SSQA3_ENV;
		   		break;
		   		
		   		case "SSQA4":
				URL=SSQA4_ENV;
				break;
		    		
	    		case "SVQA1":
		    	URL=SVQA1_ENV;
		    	break;
		    	
	    		case "SVQA2":
			    URL=SVQA2_ENV;
			   	break;
			   
	    		case "SVQA3":
			   	URL=SVQA3_ENV;
			    break;
			   
	    		case "SVQA4":
			   	URL=SVQA4_ENV;
			    break;
			    
	    		case "NTQA1":
	    		URL=NTQA1_ENV;
	    		break;

	    		case "NTQA2":
	    		URL=NTQA2_ENV;
	    		break;

	    		case "NTQA3":
	    		URL=NTQA3_ENV;
	    		break;
	    	
	    		case "NTQA4":
	    		URL=NTQA4_ENV;
	    		break;
	    		
	    		case "NTRVQA1":
		    	URL=NTRVQA1_ENV;
		    	break;

		   		case "NTRVQA2":
		   		URL=NTRVQA2_ENV;
		   		break;

		   		case "NTRVQA3":
	    		URL=NTRVQA3_ENV;
	    		break;
		
		   		case "NTRVQA4":
		    	URL=NTRVQA4_ENV;
		   		break;
	    		
		   		case "UAT1":
		   		URL=UAT1_ENV;
		   		break;
		   		
		   		case "UAT2":
			   	URL=UAT2_ENV;
			   	break;
			    	
		   		case "PROD":
		   		URL=PROD_ENV;
	    		break;
	    	}	
	    	/*
	    	switch(System.getProperty("db_env")){
	    		case "QA1":
		   		DB_URL=GCHDBURL_QA1;
		   		break;
	    		
	    		case "QA2":
			   	DB_URL=GCHDBURL_QA2;
			   	break;
			   	
	    		case "QA3":
			   	DB_URL=GCHDBURL_QA3;
			   	break;
			   	
	    		case "QA4":
			   	DB_URL=GCHDBURL_QA4;
			   	break;
			   	
	    		case "UAT1":
	    		DB_URL=GCHDBURL_UAT1;
	    		break;
	    		
	    		case "UAT2":
	    		DB_URL=GCHDBURL_UAT2;
	    		break;
	    		
	    		case "PROD":
	    		DB_URL=GCHDBURL_PROD;
	    		break;
		    		
	    	}	*/
		    		
	    }
}
