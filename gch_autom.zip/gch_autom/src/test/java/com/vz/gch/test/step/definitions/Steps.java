
package com.vz.gch.test.step.definitions;

import static org.junit.Assert.assertTrue;


import java.awt.RadialGradientPaint;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import junit.framework.Assert;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.Thucydides;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.springframework.test.util.AssertionErrors;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.Select;




import com.vz.gch.views.HealthcheckView;
import com.vz.gch.views.LegalEntity;
import com.vz.gch.views.LegalView;
import com.vz.gch.views.NASPTool;
import com.vz.gch.views.SFDCView;
import com.vz.gch.views.SalesView;
import com.vz.gch.views.SingleSearch;
import com.vz.gch.views.SFDCView;


import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.runtime.CucumberException;
import cucumber.runtime.snippets.Concatenator;

import static org.hamcrest.MatcherAssert.assertThat;
//import static org.hamcrest.text.IsEqualIgnoringCase.equalToIgnoringCase;
import static org.hamcrest.CoreMatchers.is;

public class Steps{

	

	
	private WebDriver driver = BrowserConfig.driver;
	private LegalEntity LEntity;
	private LegalView LView;
	private SingleSearch SSearch;
	private SalesView SV;
	private NASPTool RId 	= null;
	private HealthcheckView HCV = new HealthcheckView(driver);
	//private BasePage currentPage;
	private NASPTool npID = new NASPTool(driver); 
	private SFDCView sfdc = new SFDCView(driver);
	
											//LEGAL ENTITY MODULE//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
												//Login Into GCH//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	

	
	@Given("^a Username \\(Vzid\\) and Password$")
	public void a_Username_Vzid_and_Password() throws Throwable {
	LEntity = new LegalEntity(driver);
	LEntity.LogIn(System.getenv("VERIZON_VZID"),System.getenv("VERIZON_PASSWORD"));
	}

	@When("^System checks for authentication$")
	public void system_checks_for_authentication() throws Throwable {
	LEntity.authenticate();
	}

	@Then("^User should see GCH main Portal$")
	public void user_should_see_GCH_main_Portal() throws Throwable {
	LEntity.ViewGchPortal();
	LView = new LegalView(driver);
	}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
													//CREATE CLE PROCESS//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	@Given("^a Customer Name  and Customer Address$")
	public void a_Customer_Name_and_Customer_Address(List<String> CLEInfo) throws Throwable {
	LEntity.receiveCustomerNameAddress(CLEInfo.get(0), CLEInfo.get(1), CLEInfo.get(2), CLEInfo.get(3), CLEInfo.get(4), CLEInfo.get(5), CLEInfo.get(6), CLEInfo.get(7), CLEInfo.get(8));
	}
	@When("^Click on Create CLE link$")
	public void click_on_Create_CLE_link() throws Throwable {
	LEntity.clickCreateCLE();
	}

	@When("^Fill all Customer Legal Entity Information$")
	public void fill_all_Customer_Legal_Entity_Information() throws Throwable {
	LEntity.CustomerInformationFill();
	}
	@When("^Submitting CLE Information$")
	public void submitting_CLE_Information() throws Throwable {
	LEntity.CreateButtonClick();
	}

	@When("^Confirm Address format$")
	public void confirm_Address_format() throws Throwable {
	LEntity.confirmAddressFormat();
	}

	@Then("^New Customer Legal Entity should be created$")
	public void new_Customer_Legal_Entity_should_be_created() throws Throwable {
	LEntity.newCleCreated();   
	}
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
										//MANAGE BILLING ACCOUNTS MODULE//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	


//**********************************************//MANAGE CUSTOMER GROUPS TAB//***************************************
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
												//RENAME CGI//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	@Given("^a Old CGI Name \"(.*?)\", a new CGI Name \"(.*?)\" and a Customer Legal Entity \"(.*?)\"$")
	public void a_Old_CGI_Name_a_new_CGI_Name_and_a_Customer_Legal_Entity(String arg1, String arg2, String arg3) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	LEntity.receiveOldNewCGICLE(arg1,arg2,arg3);
	}

	@When("^User searches for Manage Billing Accounts$")
	public void user_searches_for_Manage_Billing_Accounts() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	LEntity.searchForManageBillingAccounts();	
	}

	@When("^User looks for a Customer Legal Entity$")
	public void user_looks_for_a_Customer_Legal_Entity() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	LEntity.MBACustomerLegalEntitySearch();
	}

	@When("^User selects a valid Customer Legal Entity$")
	public void user_selects_a_valid_Customer_Legal_Entity() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	LEntity.MBAselectValidCLE();
	}

	@When("^User checks on Manage Accounts Groups Tab for the Customer Legal Entity selected$")
	public void user_checks_on_Manage_Accounts_Groups_Tab_for_the_Customer_Legal_Entity_selected() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	LEntity.checkMBATabforCLE();
	}

	@When("^User looks for Customer Group to rename$")
	public void user_looks_for_Customer_Group_to_rename() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	LEntity.lookForCGIToRename();
	}

	@When("^User renames the Customer Group selected$")
	public void user_renames_the_Customer_Group_selected() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	LEntity.renamingCustomerGroupId();	
	}

	@Then("^User should see a confirmation message with the new CGI updated$")
	public void user_should_see_a_confirmation_message_with_the_new_CGI_updated() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	LEntity.confirmCGIUpdated();
	}
	
													//DELETE CGI//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	@Given("^a  CGI Name \"(.*?)\", and a Customer Legal Entity \"(.*?)\"$")
	public void a_CGI_Name_and_a_Customer_Legal_Entity(String arg1, String arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 LEntity.receiveDeleteCGIandCLE(arg1, arg2);
	
	}
	
	@When("^User looks for Customer Group to delete$")
	public void user_looks_for_Customer_Group_to_delete() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		LEntity.lookForCGIToDelete();
	}
	
	@When("^User deletes the Customer Group selected$")
	public void user_deletes_the_Customer_Group_selected() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		LEntity.deletingCustomerGroupId();
	}
	
	
	@Then("^User should see a confirmation message with the CGI deleted$")
	public void user_should_see_a_confirmation_message_with_the_CGI_deleted() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		LEntity.confirmCGIDeleted();
	}
	
													//CREATE CGI//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	@When("^User should click on  Create CGI button$")
	public void user_should_click_on_Create_CGI_button() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
		LEntity.createCGIButtonPress();
	}
	

	@Then("^as the user has the new CGI Name for create, user should write new CGI Name and submit$")
	public void as_the_user_has_the_new_CGI_Name_for_create_user_should_write_new_CGI_Name_and_submit() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   LEntity.writenewCGIName();
	}
	
	@Then("^User should see a confirmation message showing the CGI created$")
	public void user_should_see_a_confirmation_message_showing_the_CGI_created() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LEntity.confirmCGICreated();
	}
	
	//**********************************************//MANAGE ACCOUNT NUMBERS TAB//***************************************
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
															//FIND ACCOUNT/OBJECT//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	@Given("^a Customer Legal Entity \"(.*?)\"$")
	public void a_Customer_Legal_Entity(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		LEntity.receiveCLEFindAccountNumberObj(arg1);
	}

	@Then("^User should click Manage Account Numbers Tab$")
	public void user_should_click_Manage_Account_Numbers_Tab() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LEntity.clickOnManageAccountNumbersTab();
	}

	@Given("^an Account/Object to search \"(.*?)\", a Number/ Object description \"(.*?)\", and an Account/Object status \"(.*?)\"$")
	public void an_Account_Object_to_search_a_Number_Object_description_and_an_Account_Object_status(String arg1, String arg2, String arg3) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LEntity.receiveAccount_Descript_Status(arg1, arg2, arg3);
	}

	@Then("^User should look for the Account/object desired$")
	public void user_should_look_for_the_Account_object_desired() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LEntity.lookForTheObjectDesired();
	}

	@Then("^User should see Account/Object search results$")
	public void user_should_see_Account_Object_search_results() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   LEntity.accountSearchResults();
	}
	
	
													//CHANGE ACCOUNT CUSTOMER GROUP IDENTIFIER//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	@When("^User selects the desired account And User looks for Customer Group Search Type \"(.*?)\" and Customer Group Description \"(.*?)\"$")
	public void user_selects_the_desired_account_And_User_looks_for_Customer_Group_Search_Type_and_Customer_Group_Description(String arg1, String arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LEntity.mapAccountToCGI(arg1, arg2);
	}

	@Then("^User will select Change Customer Group ID Option from Actions Dropdown$")
	public void user_will_select_Change_Customer_Group_ID_Option_from_Actions_Dropdown() throws IOException, InterruptedException{
	    // Write code here that turns the phrase above into concrete actions
	    LEntity.selectChangeCGIOption();
	}
	
									//UPDATE LEGAL NAME//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@Then("^User will select Update Customer Legal Name Option from Actions Dropdown$")
	public void user_will_select_Update_Customer_Legal_Name_Option_from_Actions_Dropdown() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LEntity.selectUpdateCustomerLegalName();
	}
	
	@When("^User fill the new Legal Name Information with the new Name \"(.*?)\"$")
	public void User_fill_the_new_Legal_Name_Information_with_the_new_Name(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LEntity.fillUpdateLegalNameInfo(arg1);
	}
	
	@Then("^Request ID confirmation will be shown to the user$")
	public void request_ID_confirmation_will_be_shown_to_the_user() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LEntity.requestIDConfirmationUpdateLegalName();
	}
	
												//UPDATE LEGAL ADDRESS//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@Then("^User will select Update Customer Legal Address Option from Actions Dropdown$")
	public void user_will_select_Update_Customer_Legal_Address_Option_from_Actions_Dropdown() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   LEntity.clickOnUpdateLegalAddressOption();
	}

	@When("^User fill the new Legal Address Information with the new Address$")
	public void user_fill_the_new_Legal_Address_Information_with_the_new_Address(List<String> arg1) throws Throwable {
	    LEntity.fillLegalAddressInformation(arg1);
	}

	@Then("^Request ID Address confirmation will be shown to the user$")
	public void request_ID_Address_confirmation_will_be_shown_to_the_user() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   LEntity.confirmUpdateAddressFormat();
	}
	
													//TEST GCM MANAGE SERVICES/LOCATIONS POP UP//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	@Then("^User should click Manage Services/Locations tab$")
	public void user_should_click_Manage_Services_Locations_tab() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LEntity.clickOnManageServicesLocationsTab();
	}
	
	@When("^User see the Action Button$")
	public void user_see_the_Action_Button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		LEntity.clickOnActionButtonManageServicesLocations();
	}

	@Then("^User should click on Add/Update Purchase Order in order to get GCM Popup$")
	public void user_should_click_on_Add_Update_Purchase_Order_in_order_to_get_GCM_Popup() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		LEntity.clickOnAddUpdatePurchaseOrder();
	}

	@Then("^User should close the GCM PopUp$")
	public void user_should_close_the_GCM_PopUp() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LEntity.CloseGCMPopUp();
	}
	
	
													//CREATE CPNI USER//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@Given("^a Customer Legal Entity for CLE Search Bar")
	public void a_Customer_Legal_Entity_for_CLE_Search_Bar() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		LEntity.receiveCustomerLegalEntityForSearch(System.getenv("CLE_NAME_REQUEST_1"));
	}
	
	@Then("^User should search for the CLE on the search bar$")
	public void user_should_search_for_the_CLE_on_the_search_bar() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
    	LEntity.SearchOnCLEBar();
	}

	@When("^User clicks on the little arrow next to the CLE Label$")
	public void user_clicks_on_the_little_arrow_next_to_the_CLE_Label() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		LEntity.ClickOnCLELittleArrow();
	}

	@When("^user selects View Profile Option from the dropdown$")
	public void user_selects_View_Profile_Option_from_the_dropdown() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		LEntity.SelectViewProfileFromDropDown();
	}

	@When("^user selects Customer Contact Tab on View Profile Page$")
	public void user_selects_Customer_Contact_Tab_on_View_Profile_Page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		LEntity.ClickOnCustomerContactTab();
	}

	@When("^user clicks on Create button$")
	public void user_clicks_on_Create_button() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		LEntity.clickOnCreateCPNIButton();
	}

	@When("^user fill the required information to create user$")
	public void user_fill_the_required_information_to_create_user(List<String> CPNIInfo) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		LEntity.fillCPNIInformation(CPNIInfo);
	}

	@When("^user clicks on Create button to submit the information filled$")
	public void user_clicks_on_Create_button_to_submit_the_information_filled() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		LEntity.clickOnCreateCPNISubmitButton();
	}

	@Then("^user should see address confirmation popup and accept$")
	public void user_should_see_address_confirmation_popup_and_accept() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		LEntity.CPNIConfirmAddressClick();
	}	

	@When("^user sees User info confirmation popup$")
	public void user_sees_User_info_confirmation_popup() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		LEntity.viewCPNIInfoConfirmationPopUp();
	}

	@Then("^user should save the changes on confirmation popup$")
	public void user_should_save_the_changes_on_confirmation_popup() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		LEntity.clickOnCPNISaveChanges();
	}

	@Then("^user should see the message indicating process was succesfull$")
	public void user_should_see_the_message_indicating_process_was_succesfull() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		LEntity.CPNIProcessSucessfullLabel();
	}
	
										//REQUEST LEGAL ENTITY NAME CHANGE THROUGH CLE SEARCH//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@When("^user selects Request Legal Name Change Option from the dropdown$")
	public void user_selects_Request_Legal_Name_Change_Option_from_the_dropdown() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LEntity.selectCLERequestLegalNameChange();
	}
	
	@When("^User fill the new Legal Name Information with the new Name \"(.*?)\" on the CLE Option$")
	public void user_fill_the_new_Legal_Name_Information_with_the_new_Name_on_the_CLE_Option(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LEntity.fillCLEUpdateLegalNameInfo(arg1);
	}
	
										//REQUEST LEGAL ENTITY ADDRESS CHANGE THROUGH CLE SEARCH//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@When("^user selects Request Legal Address Change Option from the dropdown$")
	public void user_selects_Request_Legal_Address_Change_Option_from_the_dropdown() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		LEntity.selectCLERequestLegalAddressChange();
	}
	
	@When("^User fill the new Legal Address Information with the new Address on the CLE Option$")
	public void user_fill_the_new_Legal_Address_Information_with_the_new_Address_on_the_CLE_Option(List<String> arg1) throws Throwable {
	    LEntity.fillCLELegalAddressInformation(arg1);
	}
	
										//REQUEST INQUIRY THROUGH CLE SEARCH//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@When("^user selects Request Inquiry Option from the dropdown$")
	public void user_selects_Request_Inquiry_Option_from_the_dropdown() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		LEntity.selectRequestInquiryOptionFromDrowDown();
	}
	
	@When("^User writes down a comment for the inquiry request \"(.*?)\"$")
	public void user_writes_down_a_comment_for_the_inquiry_request(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		LEntity.writeRequestInquiryComment(arg1);
	}

	@Then("^User  finally submits the request$")
	public void user_finally_submits_the_request() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   LEntity.submitRequestInquiry();
	}
	
									//EDIT BASIC ENTITY INFORMATION//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@When("^User clicks on Entity Information Tab$")
	public void user_clicks_on_Entity_Information_Tab() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   LEntity.clickOnEntityInformationTab();
	}

	@Then("^User clicks on the Update Button besides Entity Basic Info label$")
	public void user_clicks_on_the_Update_Button_besides_Entity_Basic_Info_label() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   LEntity.clickOnUpdateBasicCLEInfo();
	}

	@When("^User fills the CLE Information with the Legal Entity Status \"(.*?)\" and the Main Phone Number \"(.*?)\"$")
	public void user_fills_the_CLE_Information_with_the_Legal_Entity_Status_and_the_Main_Phone_Number(String arg1, String arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   LEntity.fillBasicCLEInfo(arg1,arg2);
	}

	@Then("^User clicks on the Update button to submit the changes$")
	public void user_clicks_on_the_Update_button_to_submit_the_changes() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   LEntity.updateCLEBasicInfoOperationSuccessfull();
	}
	
										//UPDATE DUNS FOR CUSTOMER LEGAL ENTITY//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@Then("^User clicks on the Update Button besides DUNS Entity Info label$")
	public void user_clicks_on_the_Update_Button_besides_DUNS_Entity_Info_label() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   LEntity.clickOnUpdateDUNSIcon();
	}


@When("^User updates the Legal Entity with the new DUNS \"(.*?)\"$")
public void user_updates_the_Legal_Entity_with_the_new_DUNS(String arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    	LEntity.updateCLEWithNewDUNS(arg1);
	}

	@Then("^User clicks save changes in order to submit$")
	public void user_clicks_save_changes_in_order_to_submit() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   LEntity.updateDUNSSaveChanges();
	}

	@Then("^User confirms operation was succesfull$")
	public void user_confirms_operation_was_succesfull() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   LEntity.updateDUNSConfirmOperation();
	}
	
	//CREATE ALIAS/LABEL FOR CUSTOMER LEGAL ENTITY//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@When("^User clicks on Create Alias/Label button$")
	public void user_clicks_on_Create_Alias_Label_button() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		LEntity.clickOnCreateAliasLabelButton();
	}

	@When("^User fills the Alias/Label name information \"(.*?)\" and type \"(.*?)\"$")
	public void user_fills_the_Alias_Label_name_information_and_type(String arg1, String arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LEntity.fillAliasLabelInformation(arg1, arg2);
	}

	@When("^User save the Alias/Label changes$")
	public void user_save_the_Alias_Label_changes() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		LEntity.createAliasLabelSaveChanges();
	}

	@Then("^User will see label with operation sucessfull message$")
	public void user_will_see_label_with_operation_sucessfull_message() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		LEntity.createAliasLabelOperationSuccessfull();
	}
	
	
												//LEGAL VIEW MODULE//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
											    //SEARCH BY COMPANY NAME//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	@When("^User should click on Legal View Tab$")
	public void user_should_click_on_Legal_View_Tab() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		
		LView.clickOnLegalViewTab();
	}

	@When("^User should look for a Company by a name  \"(.*?)\"$")
	public void user_should_look_for_a_Company_by_a_name(String arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		LView.lookupForCompanyName(arg1);
	}

	@When("^User should click on Search button$")
	public void user_should_click_on_Search_button() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		LView.clickOnSearchButton();
	}
	
	@When("^User should click on WF Search button$")
	public void user_should_click_on_WF_Search_button() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		LView.clickOnWFSearchButton();
	}

	@Then("^User should see information related to the Company$")
	public void user_should_see_information_related_to_the_Company() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		LView.getSearchCompanyResults();
	}

	@When("^User clicks on Pagination Button$")
	public void user_clicks_on_Pagination_Button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.getHMTPagination();
	}

	@Then("^User should see the next page$")
	public void user_should_see_the_next_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.getNextPageSeen();
	}

	@When("^User check the Billing Name checkbox filters$")
	public void user_check_the_Billing_Name_checkbox_filters() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		LView.HMTBillingNamesearchIncludingCheckBox();
	}
	
	@When("^User check the Billing Account Number checkbox filters$")
	public void user_check_the_Billing_Account_Number_checkbox_filters() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		LView.HMTBillingAccNumbsearchIncludingCheckBox();
	}

	@Then("^User should see results based on the filters$")
	public void user_should_see_results_based_on_the_filters() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.checkFilteringResults();
	}

	@When("^User clicks on the Tree View$")
	public void user_clicks_on_the_Tree_View() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.clickonTreeView();
	}

	@Then("^User should see the Company Tree$")
	public void user_should_see_the_Company_Tr() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.viewCompanyTreeView();
	}
	
    										//SEARCH BY COMPANY ID//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@When("^User should look for a Company by an ID  \"(.*?)\"$")
	public void user_should_look_for_a_Company_by_an_ID(String arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		LView.lookupForCompanyID(arg1);
	}
											//SEARCH BY BILLING NAME//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@When("^User should look for a Company by a Billing Name  \"(.*?)\"$")
	public void user_should_look_for_a_Company_by_a_Billing_Name(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.lookupForBillingName(arg1);
	}
	
	@Then("^User should see information related to the Billing provided$")
	public void user_should_see_information_related_to_the_Billing_provided() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		LView.getSearchBillingResults();
	}
	
    										//SEARCH BY BILLING ACCOUNT NUMBER//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@When("^User should look for a Company by a Billing Account Number  \"(.*?)\"$")
	public void user_should_look_for_a_Company_by_a_Billing_Account_Number(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		LView.lookupForBillingAccountNumber(arg1);
	}
	
											//WORKFLOW TASK//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@When("^User should click on Workflow Task Tab$")
	public void user_should_click_on_Workflow_Task_Tab() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.clickOnWorkflowTaskTab();
	}

	@When("^User should look for a Task by a Source Company Name  \"(.*?)\"$")
	public void user_should_look_for_a_Task_by_a_Source_Company_Name(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.searchBySourceCompanyName(arg1);
	}

	@Then("^User should see information related to the information provided$")
	public void user_should_see_information_related_to_the_information_provided() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.verifyWorkflowTaskSearchResults();
	}

	@When("^User should look for a Task by a Source Company Segment  \"(.*?)\"$")
	public void user_should_look_for_a_Task_by_a_Source_Company_Segment(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.searchBySourceCompanySegment(arg1);
	}

	@When("^User should look for a Task by a Status Filter  \"(.*?)\"$")
	public void user_should_look_for_a_Task_by_a_Status_Filter(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.searchByStatusFilter(arg1);
	}

	@When("^User should look for a Task by a Task ID  \"(.*?)\"$")
	public void user_should_look_for_a_Task_by_a_Task_ID(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.searchByTaskId(arg1);
	}

	@When("^User should look for a Task by a Target Company Name  \"(.*?)\"$")
	public void user_should_look_for_a_Task_by_a_Target_Company_Name(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.searchByTargetCompanyName(arg1);
	}
	

	@When("^User should look for a Task by a Target Company Segment  \"(.*?)\"$")
	public void user_should_look_for_a_Task_by_a_Target_Company_Segment(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.searchByTargetCompanySegment(arg1);
	}

	@When("^User should look for a Task by a Requestor  \"(.*?)\"$")
	public void user_should_look_for_a_Task_by_a_Requestor(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.searchByRequestor(arg1);
	}

	@When("^User should look for a Task by a Event Type  \"(.*?)\"$")
	public void user_should_look_for_a_Task_by_a_Event_Type(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.searchByEventType(arg1);
	}
	
												//D&B LOOKUP//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	@When("^User should click on D&B Lookup Tab$")
	public void user_should_click_on_D_B_Lookup_Tab() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.clickOnDnBLookupTab();
	}

	@When("^User look for a Company Name \"(.*?)\"$")
	public void user_look_for_a_Company_Name(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		LView.DnBLookupByCompanyName(arg1);
	}

	@When("^User clicks on the DnB Search Button$")
	public void user_clicks_on_the_DnB_Search_Button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.DnBLookupSearchButtonClick();
	}

	@Then("^User should see information related to the searched DB$")
	public void user_should_see_information_related_to_the_searched_DB() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.DnBLookupSearchResults();
	}

	@When("^User look for a DUNS \"(.*?)\"$")
	public void user_look_for_a_DUNS(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.DnBLookupByDUNS(arg1);
	}

	@When("^User look for a City \"(.*?)\"$")
	public void user_look_for_a_City(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.DnBLookupByCity(arg1);
	}

	@When("^User look for a GUDUNS Name \"(.*?)\"$")
	public void user_look_for_a_GUDUNS_Name(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.DnBLookupByGudunsName(arg1);
	}

	@When("^User look for a Trade Style Name \"(.*?)\"$")
	public void user_look_for_a_Trade_Style_Name(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.DnBLookupByTradeStyleName(arg1);
	}

	@When("^User look for a State \"(.*?)\"$")
	public void user_look_for_a_State(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.DnBLookupByState(arg1);
	}

	@When("^User look for a GUDUNS \"(.*?)\"$")
	public void user_look_for_a_GUDUNS(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.DnBLookupByGUDUNS(arg1);
	}

	@When("^User look for a Secondary Trade Style Name \"(.*?)\"$")
	public void user_look_for_a_Secondary_Trade_Style_Name(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.DnBLookupBySecondaryTradeStyleName(arg1);
	}

	@When("^User look for a ZIP \"(.*?)\"$")
	public void user_look_for_a_ZIP(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.DnBLookupByZIP(arg1);
	}

	@When("^User look for a Street \"(.*?)\"$")
	public void user_look_for_a_Street(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.DnBLookupByStreet(arg1);
	}

	@When("^User look for a Country \"(.*?)\"$")
	public void user_look_for_a_Country(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.DnBLookupByCountry(arg1);
	}

	@When("^User clicks on Pagination Button related to D&B Lookup$")
	public void user_clicks_on_Pagination_Button_related_to_D_B_Lookup() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.DnBLookupPaginationClick();
	    
	}

	@Then("^User should see the next page on D&B Lookup results$")
	public void user_should_see_the_next_page_on_D_B_Lookup_results() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    LView.DnBLookupPaginationResultsClick();
	}
	
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
													//SINGLE SEARCH MODULE//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	


//**********************************************//CUSTOMER/NASP/BILLING ACCOUNT SEARCH//***************************************
	

	@Then("^User should see GCH Single Search Portal$")
	public void user_should_see_GCH_Single_Search_Portal() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		SSearch=new SingleSearch(driver);
		SSearch.getSingleSearchPortal();
	}

	@When("^User looks for a Customer/BAN/Billing Account \"(.*?)\"$")
	public void user_looks_for_a_Customer_BAN_Billing_Account(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		SSearch.searchForBIC(arg1);
	}

	@Then("^User should see information related to this requested BIC$")
	public void user_should_see_information_related_to_this_requested_BIC() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		SSearch.BICFound();
	}
	
	//**********************************************//VIEW CLE PROFILE OPTION//***************************************
	@When("^User clicks on LE ID number link$")
	public void user_clicks_on_LE_ID_number_link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   SSearch.clickOnLEIDLink();
	}

	@Then("^User should see a Dropdown Menu and click on View CLE Profile Option$")
	public void user_should_see_a_Dropdown_Menu_and_click_on_View_CLE_Profile_Option() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   SSearch.clickOnViewCLEProfileOption();
	}

	@Then("^User should see the Legal Entity Profile Details$")
	public void user_should_see_the_Legal_Entity_Profile_Details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   SSearch.getCLEprofileScreen();
	}
	
	@Then("^User should see a Dropdown Menu and click on View in VECRM Profile Option$")
	public void user_should_see_a_Dropdown_Menu_and_click_on_View_in_VECRM_Profile_Option() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   SSearch.clickOnViewInVECRMOption();
	}

	@Then("^User should see the Legal Entity VECRM Profile Details$")
	public void user_should_see_the_Legal_Entity_VECRM_Profile_Details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   SSearch.getVECRMProfileScreen();
	}
		
	@Then("^User should see a Dropdown Menu and click on View in Inventory SMD Option$")
	public void user_should_see_a_Dropdown_Menu_and_click_on_View_in_Inventory_SMD_Option() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   SSearch.clickOnViewInventoryInSMD();
	}
	//**********************************************//VIEW INVENTORY SMD OPTION//***************************************
	@Then("^User should see the Legal Entity View In Inventory SMD Details$")
	public void user_should_see_the_Legal_Entity_View_In_Inventory_SMD_Details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   SSearch.getInventoryInSMDScreen();
	}
	
	//**********************************************//VIEW ALARMS IN SMD OPTION//***************************************
	@Then("^User should see a Dropdown Menu and click on View Alarms in SMD Option$")
	public void user_should_see_a_Dropdown_Menu_and_click_on_View_Alarms_in_SMD_Option() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   SSearch.clickOnViewAlarmsInSMD();
	}
	
	@Then("^User should see the Legal Entity View Alarms in SMD Details$")
	public void user_should_see_the_Legal_Entity_View_Alarms_in_SMD_Details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   SSearch.getAlarmsInSMDScreen();
	}
	

	//**********************************************//VIEW TOPOLOGY IN SMD OPTION//***************************************
	@Then("^User should see a Dropdown Menu and click on View Topology in SMD Option$")
	public void user_should_see_a_Dropdown_Menu_and_click_on_View_Topology_in_SMD_Option() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  SSearch.clickOnViewTopologyInSMD();
	}


	@Then("^User should see the Legal Entity View Topology in SMD Details$")
	public void user_should_see_the_Legal_Entity_View_Topology_in_SMD_Details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
 	 SSearch.getTopologyInSMDScreen();
	}
	
	//**********************************************//SERVICE MANAGEMENT REPORTING OPTION//***************************************
	@Then("^User should see a Dropdown Menu and click on Service Management Reporting Option$")
	public void user_should_see_a_Dropdown_Menu_and_click_on_Service_Management_Reporting_Option() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
     SSearch.clickOnServiceMgmtReporting();
	}

	@Then("^User should see the Legal Entity Service Management Reporting Details$")
	public void user_should_see_the_Legal_Entity_Service_Management_Reporting_Details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  SSearch.getServiceMgmtReportingScreen();
	}
	
	@When("^User tries to go through SSO Login$")
	public void user_tries_to_go_through_SSO_Login() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   LEntity.ReLogin();
	}

	
	@When("^User clicks on LE Billing Account View link$")
	public void user_clicks_on_LE_Billing_Account_View_link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  SSearch.clickOnBillingAccountViewLink();
	}

	@Then("^User should see all the Billing Account and details regarding to this Legal Entity$")
	public void user_should_see_all_the_Billing_Account_and_details_regarding_to_this_Legal_Entity() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 SSearch.getBillingAccountViewLinkScreen();
	}
	
	//**************************************************************************************Sales View********************************************************************
	
	
	
	
	
	
	
	
	
		//////////////////////////////////////////Bank NASP Create////////////////////////////////////
		@When("^user should see Sales View Application main page$")
		public void user_should_see_Sales_View_Application_main_page() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			SV = new SalesView(driver);
		    SV.salesViewAppMainPage();
		}

		@When("^click on Create Bank NASP$")
		public void click_on_Create_Bank_NASP() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    SV.CreateBankNASP();
		    
		}
		    @Given("^Create Bank NASPs$")
		    public void create_Bank_NASPs(List<String> SVInfo)   throws Throwable {
		  
		    SV.GetSV_Managementdata(SVInfo.get(0), SVInfo.get(1), SVInfo.get(2), SVInfo.get(3), SVInfo.get(4), SVInfo.get(5), SVInfo.get(6));
		   	SV.CustomerInformationFillNASPs();
		    
		}
		    

		@Then("^User click on Create to complete the Create Bank NASPS$")
		public void user_click_on_Create_to_complete_the_Create_Bank_NASPS() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    SV.Create();
		}

		@Then("^User should see a message that notifies Bank Nasps have been created successfully$")
		public void user_should_see_a_message_that_notifies_Bank_Nasps_have_been_created_successfully() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    SV.BankNaspCreated();
		}
		
		//////////////////////////////////////////NASP Search Edit////////////////////////////////////
		
		
		
		
		@When("^User Click on NASP Search$")
		public void user_Click_on_NASP_Search() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		   SV.clickNASPSearch();
		}

		@Given("^NASP Name OR GUDUNS Name$")
		public void nasp_Name_OR_GUDUNS_Name(List<String> SVInfo) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    // For automatic transformation, change DataTable to one of
		    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
		    // E,K,V must be a scalar (String, Integer, Date, enum etc)
		    SV.GetSVManagementParentNASPSearchData(SVInfo.get(0), SVInfo.get(1), SVInfo.get(2), SVInfo.get(3), SVInfo.get(4), SVInfo.get(5), SVInfo.get(6),SVInfo.get(7), SVInfo.get(8), SVInfo.get(9), SVInfo.get(10), SVInfo.get(11), SVInfo.get(12), SVInfo.get(13));
		    SV.fillInformationforParentNASPSearch();
		}

		@Given("^User Click on Search$")
		public void user_Click_on_Search() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		   SV.clickParentNASPSearch_SearchButton();
		}

		
		@Given("^User Check the NASP ID$")
		public void user_Check_the_NASP_ID() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    SV.CheckButtonNASP_ParentNASPSearchResult();
		}


		@Given("^User Click the Edit button$")
		public void user_Click_the_Edit_button(List<String> SVInfo) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    // For automatic transformation, change DataTable to one of
		    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
		    // E,K,V must be a scalar (String, Integer, Date, enum etc)
			SV.clickEdiButton();
			SV.getSV_ManagementdataEditNASP(SVInfo.get(0), SVInfo.get(1), SVInfo.get(2), SVInfo.get(3), SVInfo.get(4), SVInfo.get(5), SVInfo.get(6));
	        SV.editNASP();
		}

		@Given("^User Place the Comment \"(.*?)\"$")
		public void user_Place_the_Comment(String arg1) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    SV.editComments(arg1);
		}

		@When("^User Click on Save Changes$")
		public void user_Click_on_Save_Changes() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    SV.clickSaveChanges();
		}
		
		@Then("^User should see a message that notifies that NASP has been modified successfully$")
		public void user_should_see_a_message_that_notifies_that_NASP_has_been_modified_successfully() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    SV.NaspSearchEdited();
		}
		
		
		
		@Given("^Search by NASP  ID,NASP Name,GUDUNS,GUDUNS Name,DUNS OR GUDUNS$")
		public void search_by_NASP_ID_NASP_Name_GUDUNS_GUDUNS_Name_DUNS_OR_GUDUNS(List<String> SVInfo) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    // For automatic transformation, change DataTable to one of
		    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
		    // E,K,V must be a scalar (String, Integer, Date, enum etc)
			SV.GetSVManagementParentNASPSearchData2(SVInfo.get(0), SVInfo.get(1), SVInfo.get(2), SVInfo.get(3), SVInfo.get(4), SVInfo.get(5));
		    SV.fillInformationforParentNASPSearch2();

		}
		
		@Given("^User Click the Export button$")
		public void user_Click_the_Export_button() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		  SV.ExportButton();
		}
		
		@Then("^User should see Export Pop Up working properly$")
		public void user_should_see_Export_Pop_Up_working_properly() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		   SV.exportPopUp();
		}
	
		@Then("^User click on Export$")
		public void user_click_on_Export() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		  SV.clickOnSegmentExport();
		}
		
		@Then("^User should see Segment Export Pop Up$")
		public void user_should_see_Segment_Export_Pop_Up() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		  SV.SegmentExportPopUp();
		}

		@Then("^User Select the File type Excel$")
		public void user_Select_the_File_type_Excel() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			SV.clickExcelCheckButton();
		   
		}
		
		@Then("^User click on Cancel$")
		public void user_click_on_Cancel() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		  
		}
		
		@Given("^User Click the Delete button$")
		public void user_Click_the_Delete_button() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		 SV.clickDeleteButton();
		}


		@Then("^User click the Red Delete Button$")
		public void user_click_the_Red_Delete_Button() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		 SV.clickRedDeleteButton();
		}
		
		
		@Then("^User should receive confirmation that NASP was correctly deleted$")
		public void user_should_receive_confirmation_that_NASP_was_correctly_deleted() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		 SV.confirmNASPIDDeleted();
		}
		
		@Then("^User click on Account Search$")
		public void user_click_on_Account_Search() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    SV.clickAccountSearch();
		}

		@When("^User Entering Search Criteria$")
		public void user_Entering_Search_Criteria(List<String> SVInfo) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    // For automatic transformation, change DataTable to one of
		    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
		    // E,K,V must be a scalar (String, Integer, Date, enum etc)
			
			SV.getSVManagementSearchCriteria(SVInfo.get(0), SVInfo.get(1), SVInfo.get(2), SVInfo.get(3), SVInfo.get(4), SVInfo.get(5), SVInfo.get(6), SVInfo.get(7), SVInfo.get(8), SVInfo.get(9), SVInfo.get(10));
		    SV.fillSearchCriteria();
		
		}
		
		
		@When("^User Click the Search button$")
		public void user_Click_the_Search_button() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    SV.clickAccountSearch_SearchButton();
		}
		
		
		@When("^User Click the Account Search Export button$")
		public void user_Click_the_Account_Search_Export_button() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    SV.clickAccountSearch_ExportButton();
		}
		
		
		@Then("^User click on Download(\\d+)$")
		public void user_click_on_Download(int arg1) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		   SV.clickDownloadFileAccountSearchExport();
		}
		
		@Then("^User click on Cancel(\\d+)$")
		public void user_click_on_Cancel(int arg1) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    SV.clickAccountSearchCancel();
		}

		@When("^User click on Segments$")
		public void user_click_on_Segments() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		   SV.clickSegmentsLink();
		}
		
		@When("^User Click the Segments Export button$")
		public void user_Click_the_Segments_Export_button() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    SV.clickSegments_ExportButton();
		}


		@Then("^User can click on Download$")
		public void user_can_click_on_Download() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    SV.clickDownloadFileSegmentsExport();
		}
		
		@Then("^User click on the Cancel button$")
		public void user_click_on_the_Cancel_button() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		   SV.clickSegmentsCancel();
		}
		
		@When("^User click on Regions$")
		public void user_click_on_Regions() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    SV.clickRegionsLink();
		}
		
		@When("^User Click the Regions Export button$")
		public void user_Click_the_Regions_Export_button() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
	      SV.clickRegions_ExportButton();
		}
		
		@Then("^User should see Regions Export Pop Up$")
		public void user_should_see_Regions_Export_Pop_Up() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		  SV. RegionExportPopUp();
		}
		
		@Then("^User can click on Download Regions$")
		public void user_can_click_on_Download_Regions() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		   SV.clickDownloadFileRegionsExport();
		}
		
		@When("^User click on Manager Roles$")
		public void user_click_on_Manager_Roles() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    SV.clickManagerRoles();
		}
		
		@Then("^User should see Manager Roles Export Pop Up$")
		public void user_should_see_Manager_Roles_Export_Pop_Up() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    SV.ManageRolesExportPopUp();
		}
		@When("^User Click the Manager Roles Export button$")
		public void user_Click_the_Manager_Roles_Export_button() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		   SV.clickManagerRoles_Export();
		}

		@Then("^User can click on Download Manager Roles$")
		public void user_can_click_on_Download_Manager_Roles() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		   SV.clickDownloadFileManagerRolesExport();
		}

	    @When("^User Select a level_A$")
	    public void user_Select_a_level_A() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    	SV.clickgetlevel_A_ManagerRoles();
	    }

	    @When("^User Select a level_B$")
	    public void user_Select_a_level_B() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    	SV.clickgetlevel_B_ManagerRoles();
	    }

	    @When("^User Select a level_C$")
	    public void user_Select_a_level_C() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    	SV.clickgetlevel_C_ManagerRoles();
	    }

	    @When("^User Select a level_D$")
	    public void user_Select_a_level_D() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    	SV.clickgetlevel_D_ManagerRoles();
	    }

	    @When("^User Select a level_E$")
	    public void user_Select_a_level_E() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    	SV.clickgetlevel_E_ManagerRoles();
	    }

	    @When("^User Select a level_F$")
	    public void user_Select_a_level_F() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    	SV.clickgetlevel_F_ManagerRoles();
	    }

		@When("^User Enter the Change$")
		public void user_Enter_the_Change(List<String> SVInfo) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    // For automatic transformation, change DataTable to one of
		    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
		    // E,K,V must be a scalar (String, Integer, Date, enum etc)
			SV.getManagerRolesCriteria(SVInfo.get(0), SVInfo.get(1), SVInfo.get(2));
			SV.fillSearchCriteriaManagerRoles();
		
		}

		@When("^User Save Changes Manager Roles$")
		public void user_Save_Changes_Manager_Roles() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			SV.ClickToSave_CommentMR();    
		}


		@When("^User clicks on Account Search link$")
		public void user_clicks_on_Account_Search_link() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    SV.clickOnAccountSearchLink();
		}

		@Then("^User shoud populate Account Search Textbox with the Account desired \"(.*?)\"$")
		public void user_shoud_populate_Account_Search_Textbox_with_the_Account_desired(String arg1) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    SV.lookForAccountValue(arg1);
		}

		@When("^User clicks on Search Button$")
		public void user_clicks_on_Search_Button() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    SV.clickOnSearchButton();
		}

		@Then("^User should be able to see the Account requested$")
		public void user_should_be_able_to_see_the_Account_requested() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    SV.getAccountSearchResults();
		}
		
		
		
///////////////////////////////////////////////////NASP TOOL /////////////////////////////////////////////////////////////
	
		@Given("^Request Id is \"(.*?)\" for first approval$")
		public void FirstApprove(String arg1) throws Throwable {
			RId.Approve(arg1, true);
		}
		
		@Then("^Request Id is the already request for first approval$")
		public void FirstApproveRequest() throws Throwable {
			RId.Approve(true);
		}
		
		@Then("^Request Id is the already request for second approval$")
		public void SecpmdApproveRequest() throws Throwable {
			RId.Approve(false);
		}	
		
		@Then("^Approve It$")
		public void FirstApproveIt() throws Throwable {
			RId.ApproveIt();
		}
		
		@Then("^It is Done$")
		public void Done() throws Throwable {
			RId.Done();
		}
		
		@Given("^Definitive Nasp Id is \"(.*?)\"$")
		public void InputDefinitiveNaspId(String arg1) throws Throwable {
			RId.SetNaspIdApproval(arg1);
		}
		
		@Then("^Check if it was succesful$")
		public void FirstApproveWait() throws Throwable {
			RId.ApproveWait();
		}
		
		@Then("^Wait \"(.*?)\" seconds$")
		public void FirstApproveWait(String arg1) throws Throwable {
			RId.Wait(arg1);
		}	
		
		@Given("^A Username \"(.*?)\" and Password \"(.*?)\"$")
		public void LoginUsernamePass(String arg1, String arg2) throws Throwable {
			RId = new NASPTool(driver);
			RId.LogIn(arg1, arg2);
		}
		
		@Given("^Branch type is \"([^\"]*)\"$")
		public void branch_type_is(String arg1) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		   RId.SelectBranch(arg1);
		}
		@When("^System check if logged in$")
		public void CheckAuthentication() throws Throwable {
			RId.Authenticated();
		}

		@Given("^NASP ID \"(.*?)\"$")
		public void InputNaspId(String arg1) throws Throwable {
			RId.GetToIdRequest(arg1);
		}
		
		@Then("^should see NASP Tool Request Id Screen$")
		public void GetToRequestId() throws Throwable {
			RId.WaitForUI();
		}
		
		@Given("^NASP Type is \"(.*?)\"$")
		public void InputNASPType(String arg1) throws Throwable {
			RId.SetNaspType(arg1);
		}
		
		@Given("^RevLoc is \"(.*?)\"$")
		public void InputRevLoc(String arg1) throws Throwable {
			RId.SetRevLoc(arg1);
		}
		
		@Given("^GCH Id Filter is \"(.*?)\"$")
		public void InputGCHFilter(String arg1) throws Throwable {
			RId.SetGCHId(arg1);
		}
		
		@Then("^User Should see the GCH Field filled$")
		public void InputNaspRevLocGCH() throws Throwable {
			RId.WaitGCHIdScreen();
		}
		
		@Given("^Name is \"(.*?)\"$")
		public void FillName(String arg1) throws Throwable {
			RId.SetFirstName(arg1);
		}
		
		@Given("^Lastname is \"(.*?)\"$")
		public void FillLastname(String arg1) throws Throwable {
			RId.SetLastName(arg1);
		}
		
		@Given("^Phone Number is \"(.*?)\"$")
		public void FillPhone(String arg1) throws Throwable {
			RId.SetPhoneNumber(arg1);
		}
		
		@Given("^Country is \"(.*?)\"$")
		public void FillCountry(String arg1) throws Throwable {
			RId.SetCountry(arg1);
		}
		
		@Given("^Street Address is \"(.*?)\"$")
		public void FillStreet(String arg1) throws Throwable {
			RId.SetStreet(arg1);
		}
		
		@Given("^City is \"(.*?)\"$")
		public void FillCity(String arg1) throws Throwable {
			RId.SetCity(arg1);
		}

		@Given("^State is \"(.*?)\"$")
		public void FillState(String arg1) throws Throwable {
			RId.SetState(arg1);
		}
		
		@Given("^Postal Code is \"(.*?)\"$")
		public void FillPostalCode(String arg1) throws Throwable {
			RId.SetPostalCode(arg1);
		}
		
		@Then("^User should submit and succesfully made the request$")
		public void SubmitIt() throws Throwable {
			RId.Submit();
		}
/////////////////////////// NASPTOOL MANAGE REVLOC MAPPING ///////////////////////////
		
		@When("^User click on the NASP Tool Revloc Button$")
		public void user_click_on_the_NASP_Tool_Revloc_Button() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    npID.NaspToolRevlocButtonClick();
		}


		@Then("^the user should see Manage RevLOC - Segment Mapping$")
		public void userShouldSeeManageRevLocSegmentMapping()
		{
			//assertThat( currentPage.getPageTitle() , equalToIgnoringCase("NaspTool") );
		}
		//****************Background end********************************************************
		
		
		//****************Scenario start: Add a new RevLoc Segment mapping*********************
		@Given("^The segment mapping (.*) and the segment (.*) does not exist$")
		public void segmentMappingDoesNotExist(String revLocCode, String segmentCode) throws InterruptedException, IOException
		{
			assertThat( npID.checkIfMappingExist(revLocCode, segmentCode) , is(false));
			npID.goToFirstPage();
		}
		
		@When("^the user adds a new segment mapping with the RevLoc Code (.*) and the segment (.*)$")
		public void userAddsNewMapping(String revLocCode, String segmentCode)
		{
			npID.addSegmentMapping(revLocCode, segmentCode);
		}
		
		@Then("^user should see the RevLoc Description (.*) and the segment (.*)$")
		public void userShouldSeeNewMapping(String revLocCode, String segmentCode) throws InterruptedException, IOException
		{
			assertThat( npID.checkIfMappingExist(revLocCode, segmentCode) , is(true));
			
			npID.goToFirstPage();
		}
		//********************Scenario end: Add a new RevLoc Segement mapping***********************************
		
		
		//********************Scenario start: Edit an existing RevLoc Mapping************************************
		@Given("^The segment mapping (.*) and the segment (.*) does exist$")
		public void segmentMappingDoesExist(String revLocCode, String segmentCode) throws InterruptedException, IOException
		{
			assertThat( npID.checkIfMappingExist(revLocCode, segmentCode) , is(true));
		}
		
		@When("^The user clicks edit on the mapping (.*) and segment (.*) and changes the Segment to (.*)$")
		public void editExistingMapping(String revLocCode, String segmentCode, String newSegmentCode) throws InterruptedException, IOException
		{
			npID.editSegmentMapping(revLocCode, segmentCode, newSegmentCode);
			
			npID.goToFirstPage();
		}
		
		//***********************Scenario end: Edit an existing RevLoc Mapping***************************************
		
		
		
		//***********************Scenario start: Delete and existing RevLoc Mapping**********************************
		
		@When("^The user clicks delete for the mapping (.*) and the segment (.*) and confirms the deletion$")
		public void userClicksDelete(String revLocCode, String segmentCode) throws InterruptedException, IOException
		{
			npID.deleteSegmentMapping(revLocCode, segmentCode);
			
			npID.goToFirstPage();
		}
		
		//***********************Scenario end: Delete and existing RevLoc Mapping**********************************

	///////////////////////////////NASP TOOL REQUEST SEARCH//////////////////////////////////////////////
		

		@When("^user click on the NASP Tool Search Request Button$")
		public void user_click_on_the_NASP_Tool_Search_Request_Button() throws Throwable {
    	// Write code here that turns the phrase above into concrete actions
    	npID.clickOnNASPToolSearchRequestButton();
	}

		@Then("^the user is on Search Requests page$")
		public void theUserIsOnSearchRequestPage(){
			driver.manage().timeouts().pageLoadTimeout(5, TimeUnit.SECONDS);
			assertTrue(npID.isUserOnSearchRequestPage());
		}
		
		@When("^he provides NASP Id as \"(.*?)\"$")
		public void heProvidesNaspId(String naspId){
			npID.provideNaspId(naspId);
		}
		
		@When("^he provides NASP Name as \"(.*?)\"$")
		public void heProvidesNaspName(String naspName) throws IOException{
			npID.provideNaspName(naspName);
		}
		
		@When("^he provides NASP created date from as \"(.*?)\"$")
		public void heProvidesNaspCreatedDateFrom(String arg){
			npID.provideCreatedDateFrom(arg);
		}
		
		@When("^he provides NASP created date to as \"(.*?)\"$")
		public void heProvidesNaspCreatedDateTo(String arg){
			npID.provideCreatedDateTo(arg);
		}

		@When("^he provides NASP request id as \"(.*?)\"$")
		public void heProvidesNaspRequestId(String arg) throws Throwable {
			npID.provideRequestId(arg);
		}

		@When("^he provides NASP region as \"(.*?)\"$")
		public void heProvidesNaspRegion(String arg){
			npID.provideRegion(arg);
		}
		
		@And("^he clicks the search button$")
		public void heClicksOnTheSearchButton(){
			npID.clickOnSearchButton();
		}
		
		@Then("^a list of requests is shown$")
		public void aListOfRequestIsShown(){
			driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
			assertTrue(npID.tableContainsAtLeastOneItem());
		}
		
		@And("^the user can view a status of his request$")
		public void theUserCanViewaStatusOfHisRequest(){
			assertTrue(npID.userCanViewStatusRequest());
			//assertTrue(npID.isNaspIdFilterCorrectly());
		}
		
		@When("^the user clicks on a request id link with value as \"(.*?)\"$")
		public void userClicksOnRequestIdLink(String arg){
			npID.clickOnRequestIdLink(arg);
		}
		
		@When("^the user clicks the clear button$")
		public void userClicksOnClearButton(){
			npID.clickOnClearButton();
			
		}
		
		@Then("^all the Nasp Tool search parameters should be empty$")
		public void allNaspSearchParametersAreEmpty(){
			assertTrue(npID.areAllSearchParametersEmpty());
		}
		
		@When("^he provides NASP status as \"(.*?)\"$")
		public void heProvidesNaspStatus(String arg){
			npID.provideNaspStatus(arg);
		}
		
		@And("^he clicks on the clear button$")
		public void heClicksTheClearButton(){
			npID.clickOnClearButton();
		}
		
		@And("^he can view a record with NASP Id as \"(.*?)\"$")
		public void heCanViewaRecordWithNaspIdAs(String arg) throws InterruptedException{
			Thread.sleep(2000);
			assertTrue(npID.isfirstRecordRelatedToNaspId(arg));
		}
		
		@And("^he can view a record with Name as \"(.*?)\"$")
		public void heCanViewaRecordWithNameAs(String arg) throws InterruptedException{
			Thread.sleep(2000);
			assertTrue(npID.isfirstRecordRelatedToName(arg));
		}
		
		@And("^he can see a record with date between from as \"(.*?)\" and to as \"(.*?)\"$")
		public void heCanSeeRecordWithDateBetween(String arg1, String arg2) throws InterruptedException, ParseException{
			Thread.sleep(2000);
			assertTrue(npID.isFirstRecordBetweenDates(arg1, arg2));
		}
		
		@And("^he can view a record with request id as \"(.*?)\"$")
		public void heCanViewaRecordWithRecordIdAs(String arg) throws InterruptedException{
			Thread.sleep(2000);
			assertTrue(npID.isFirstRecordRelatedToRecordId(arg));
		}
		
		@And("^he can view a record with region as \"(.*?)\"$")
		public void heCanViewaRecordWithRegionAs(String arg) throws InterruptedException{
			Thread.sleep(2000);
			assertTrue(npID.isFirstRecordRelatedToRegion(arg));	
		}
		
		@And("^he can view a record with status as \"(.*?)\"$")
		public void heCanViewaRecordWithStatusAs(String arg) throws InterruptedException{
			Thread.sleep(2000);
			assertTrue(npID.isFirstRecordRelatedToStatus(arg));	
		}
		
		/*********************************SFDC Punchout to GCH Page*********************************/
		
		///////////////////////////BACKGROUND START///////////////////////////
		@Given("^user logged to SFDC page with username (.*) and password (.*)$")
		public void userLoggedToSFDC(String username, String password)
		{
			sfdc.logInSFDC(username,password);
		}
		
		@When("^user searches for account (.*)$") 
		public void userSearchesForAccount(String searchCriteria) throws InterruptedException
		{   
			Thread.sleep(5000);
			sfdc.searchAccount(searchCriteria);
		}
		
		@Then("^user should see the link with account name (.*)$")
		public void userSeesInfoPage(String accountName) throws InterruptedException
		{   
			Thread.sleep(5000);
			assertTrue( sfdc.checkForLinkWithText(accountName) );
			//a[text()='HCMAR16SA_GCH04112016']
			//HCMAR16SA_GCH04112016
			//Search Results ~ Salesforce - Unlimited Edition
		}
		///////////////////////////BACKGROUND FINISH///////////////////////////
		
		@Given("^user clicks on account name \"(.*?)\"$")
		public void userClicksAccountName(String accountName) throws InterruptedException {
			Thread.sleep(5000);
			sfdc.clickOnLinkWithText(accountName);
		}
		
	    @And("^he clicks on New Nasp ID Request button$")
	    public void userClicksNewNaspIDRequestButton() throws InterruptedException {
	    	
	    	sfdc.clickOnNewNaspIDRequestButton();
	    }
		
		@And("^he clicks the OK button to be redirected to New NASP request tool$")
		public void userClicksOKRedirectButton() throws InterruptedException {
			
			sfdc.clickOKRedirectionNewNaspIDRequestButton();

		}
		
		@Then("^punch out$")
		public void punchOut() throws InterruptedException {

			sfdc.punchOutGCHPage();
		}
		
		
	///////////////////////////////////////////////////////////////////////////////////////
		
		@Given("^user Login again page with username \"([^\"]*)\" and password \"([^\"]*)\"$")
		public void user_Login_again_page_with_username_and_password(String arg1, String arg2) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    sfdc.logInSFDC2(arg1, arg2);
		}

		@Then("^User should select a NASPType \"([^\"]*)\"$")
		public void user_should_select_a_NASPType(String arg1) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			Thread.sleep(5000);
	     sfdc.sfdcenter_nasptype(arg1);
	  
	     
	     

		}

		@Then("^User should select a RevLOC \"([^\"]*)\"$")
		public void user_should_select_a_RevLOC(String arg1) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			Thread.sleep(5000);
            sfdc.sfdcenter_revloctype(arg1);
		}

		@Given("^User should enter a Contact First Name\"([^\"]*)\"$")
		public void user_should_enter_a_Contact_First_Name(String arg1) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		sfdc.sfdccontactfirstname(arg1);
		}

		@Given("^User should enter a Contact Last Name \"([^\"]*)\"$")
		public void user_should_enter_a_Contact_Last_Name(String arg1) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		   sfdc.sfdccontactlastname(arg1);
		   
		
		}

		@Then("^User should click to the submit buton$")
		public void user_should_click_to_the_submit_buton() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		   sfdc.sfdcsubmit_nasprequestid();
		   
		}
		
		@Then("^User should click Ok$")
		public void user_should_click_Ok() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		   sfdc.sfdcnasprequestidok();

		}
		
		
		///////////////////////////////////////////////HCV///////////////////////////////////////////////////
		
		//CPNI USER CREATION
		
		@Then("^User should click on the little arrow and select the View Profile Option$")
		public void user_should_click_on_the_little_arrow_and_select_the_View_Profile_Option() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    HCV.clickViewProfOption();
		}

		@Then("^User should see the View Profile page and click on the Customer Contact tab$")
		public void user_should_see_the_View_Profile_page_and_click_on_the_Customer_Contact_tab() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			HCV.clickCustomerContactTab();
		}

		@When("^User is on the Customer Contact tab, user should click on Create button$")
		public void user_is_on_the_Customer_Contact_tab_user_should_click_on_Create_button() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			HCV.clickCreateCPNIButton();
		}

		@Then("^User should fill the required information for User Creation$")
		public void user_should_fill_the_required_information_for_User_Creation(List<String> arg1) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    // For automatic transformation, change DataTable to one of
		    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
		    // E,K,V must be a scalar (String, Integer, Date, enum etc)
			HCV.fillRequiredFieldsCPNI(arg1);
		}

		@Then("^User should now click on Create in order to submit the information$")
		public void user_should_now_click_on_Create_in_order_to_submit_the_information() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			HCV.clickCreateFinalCPNIButton();
		}

		@Then("^User should go through Address Validation process$")
		public void user_should_go_through_Address_Validation_process() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			HCV.addressValidationCPNI();
		}

		@Then("^User should click on Save Changes in order to have the process done$")
		public void user_should_click_on_Save_Changes_in_order_to_have_the_process_done() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			HCV.clickSaveChangesCPNIButton();;
		}

		@Then("^User should see a message stating the User was created successfully$")
		public void user_should_see_a_message_stating_the_User_was_created_successfully() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			HCV.userCreatedSuccessfully();
		}
		
		
		
		//REQUEST INQUIRY
		
		@Then("^User should click on the little arrow and select the Request Inquiry$")
		public void user_should_click_on_the_little_arrow_and_select_the_Request_Inquiry() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		   HCV.requestInquiryOption();
		}
		
		@Given("^the Request Inquiry textbox user should set a description \"([^\"]*)\"$")
		public void the_Request_Inquiry_textbox_user_should_set_a_description(String desc) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		  HCV.requestInquiryDescription(desc);
		}

		@Then("^user should click on send button$")
		public void user_should_click_on_send_button() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			HCV.requestInquirySendButton();
		}

		@Then("^user should verify the inquiry was created as expected$")
		public void user_should_verify_the_inquiry_was_created_as_expected() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			HCV.requestInquirySuccessfullMsg();
		}
		
		
		//SINGLE SEARCH

		@Then("^User should move to the Customer Search$")
		public void user_should_move_to_the_Customer_Search() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    HCV.moveToCustomerSearch();
		}
		
		@Then("^User should see GCH Single Search$")
		public void user_should_see_GCH_Single_Search() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    HCV.seeSingleSearchPortal();
		}
		
		@Given("^a Customer Legal Entity for CLE Single Search Bar \"([^\"]*)\"$")
		public void a_Customer_Legal_Entity_for_CLE_Single_Search_Bar(String arg1) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    HCV.receiveCLEtoSingleSearch(arg1);
		}
		
		@When("^user click on the Search button$")
		public void user_click_on_the_Search_button() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    HCV.clickOnSingleSearchButton();
		}
		
		@Then("^user should see the CLE information from the Single Search$")
		public void user_should_see_the_CLE_information_from_the_Single_Search() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		   HCV.getSingleSearchCLEInfo();
		}
				
		@When("^User click on the Tax Attributes update icon$")
		public void user_click_on_the_Tax_Attributes_update_icon() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		  HCV.clickOnTaxAtUpdateIcon();
		}

		@Then("^User should see a pop up to update the Tax ID$")
		public void user_should_see_a_pop_up_to_update_the_Tax_ID() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		  HCV.getUpdateTaxIDPopup();
		}

		@Given("^a Tax ID Number \"([^\"]*)\"$")
		public void a_Tax_ID_Number(String arg1) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		  HCV.taxIdPassed(arg1);
		}

		@When("^user inputs the Tax ID Number and save changes$")
		public void user_inputs_the_Tax_ID_Number_and_save_changes() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		  HCV.clickOnTaxIDSaveChanges();
		}

		@Then("^user should be able to see the Tax ID Modified$")
		public void user_should_be_able_to_see_the_Tax_ID_Modified() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		  HCV.TaxIDModified();
		}
		
		////////////////////// VICTOR MERAN'S PART///////////////////////////////

		
//////////////////////-- Scenario: CLE Creation -- //////////////////////
		
		@Given("user clicked on Create Legal Entity$")
		public void userClickedCreateLE() {
		
		HCV.clickOnCreateLE();
		}
				
		@And("user provides name CLE 1$")
		public void userProvidesLEName1() throws IOException, InterruptedException {
		
		HCV.provideLEName(System.getenv("CLE_NAME_REQUEST_1"));
		Thread.sleep(2000);
		}
		
		@And("user provides name CLE 2$")
		public void userProvidesLEName2() throws IOException, InterruptedException {
		
		HCV.provideLEName(System.getenv("CLE_NAME_REQUEST_2"));
		Thread.sleep(2000);
		}
				
		@And("user provides address line \"(.*?)\"$")
		public void userProvidesLEAddress(String address) {
		
		HCV.provideLEAddress(address);
		}
				
		@And("user provides city \"(.*?)\"$")
		public void userProvidesLECity(String city) {
		
		HCV.provideLECity(city);
		}
				
		@And("user selects country United States - USA$") 
		public void userSelectsLECountry() {
		
		HCV.selectLECountryDropdown();
		}
				
		@And("user selects state Colorado - CO$") 
		public void userSelectsLEState() throws InterruptedException {
		
		HCV.selectLEStateDropdown();
		}
				
		@And("user provides ZIP code \"(.*?)\"$") 
		public void userProvidesLEZip(String zipcode) {
		
		HCV.provideLEZIPPostcode(zipcode);
		}
			
		@When("user provides telephone number \"(.*?)\"$")
		public void userProvidesLETelephoneNumber(String phonenumber) {
		
		HCV.provideLEMainTelephoneNumber(phonenumber);
		}
			
		@Then("user should click Create LE button$") 
		public void userClicksLECreateButton() {
		
		HCV.clickLECreateButton();
		}
				
		@And("user should click Create LE Yes button$")
		public void userClicksLEYesButton() throws IOException {
		
		HCV.clickLEYesButton();
		}
				
		@And("user should click Create LE OK button$")
		public void userClicksLEOKButton() throws IOException {
		
		HCV.clickLEOKButton();
		}
		
		
		////////////////////// -- Scenario: Request Legal Name Change Pt. I -- //////////////////////
		
		@Given("user searched for CLE 1$")
		public void userSearchesCLE1() throws ClassNotFoundException, SQLException {
		
		HCV.searchForCLE(System.getenv("CLE_NAME_REQUEST_1"));
		}
		
		@Given("user searched for CLE 2$")
		public void userSearchesCLE2() throws ClassNotFoundException, SQLException {
		
		HCV.searchForCLE(System.getenv("CLE_NAME_REQUEST_2"));
		}
		
		@And("user clicks on the arrow dropdown menu next to the CLE name$")
		public void userClicksArrowDropdown() throws IOException, InterruptedException {
		
		HCV.clickArrowDropdown();
		}
		
		@And("user clicks on Request Legal Name Change$")
		public void userClicksRequesLegalNameChange() {
		
		HCV.selectRequestLegalNameChange();
		}
		
		@When("user provides new Legal Entity Name$")
		public void userProvidesNewLegalEntityName() throws IOException {
		
		HCV.provideLENameRequestChange_1(System.getenv("CLE_NAME_REQUEST_1")+".1");
		}
		
		@Then("user should click Change LE Name1 Submit button$")
		public void userClicksRequestLegalNameChange1SubmitButton() {
		
		HCV.clickRequestLegalNameChange1SubmitButton(); 
		}
		
		@And("user should click Change LE Name1 OK button$")
		public void userClicksRequestLegalNameChange1OKButton() throws IOException {
		
		HCV.clickRequestLegalNameChange1OKButton();
		}
		
		////////////////////// -- Scenario: Request Legal Name Change Pt. II -- //////////////////////
		
		@And("user clicks on View Profile$")
		public void userClicksViewProfile() {
		
		HCV.clickViewProfile();
		}
		
		
		@And("user clicks on Entity Information tab$")
		public void userClicksEntityInformationTab() throws IOException {
		
		HCV.clickEntityInformationTab();
		}
		
		@And("user clicks on Address/Name Change Request icon$")
		public void userClicksAddressNameChangeIcon() throws IOException {
		
		HCV.clickAddressNameChangeIcon();
		}
		
		@And("user selects Name in the dropdown menu$")
		public void userSelectsNameInDropdown() throws IOException {
		
		HCV.selectNameChangeOption();
		}
		
		@And("user clicks Update button$")
		public void userClickUpdateButton() {
		
		HCV.clickUpdateButton();
		}
		
		@When("user provides new Legal Entity Name Change II$")
		public void userProvidesNewLegalEntityNameChangeII() throws IOException {
		
		HCV.provideNameChangePopup(System.getenv("CLE_NAME_REQUEST_2")+".1");
		}
		
		@Then("user should click Change LE Name2 Submit button$")
		public void userClicksChangeLEName2SubmitButton() {
		
		HCV.clickRequestLegalNameChange2SubmitButton();
		}
		
		@And("user should click Change LE Name2 OK button$")
		public void userClicksChangeLEName2OKButton() throws IOException {
		
		HCV.clickRequestLegalNameChange2OKButton();
		}
		
		//////////////////////-- Scenario: Request Legal Address Change Pt. I -- //////////////////////
		
		@And("user clicks on Request Legal Address Change$")
		public void userClicksRequestLegalAddressChange() {
		
		HCV.clickRequestLegalAddressChange();
		}
		
		@When("user provides address line I \"(.*?)\"$") 
		public void userProvidesAddressLine_1(String address) throws IOException, InterruptedException {
		
		HCV.provideAddressLine_1(address);
		}
		
		@And("user provides city I \"(.*?)\"$")
		public void userProvidesCity_1(String city) {
		
		HCV.provideCity_1(city);
		}
		
		@And("user selects country I United States - USA$")
		public void userSelectsCountry_1() {
		
		HCV.selectCountry_1();
		}
		
		@And("user selects state I Colorado - CO$")
		public void userSelectsState_1() throws InterruptedException {
		
		HCV.selectState_1();
		}
		
		@And("user provides ZIP code I \"(.*?)\"$")
		public void userProvidesZIPCode_1(String zipcode) {
		
		HCV.provideZIPcode_1(zipcode);
		}
		
		@Then("user should click Change LE Address1 Submit button$")
		public void userClicksChangeLEAddressSubmitButton_1() {
		
		HCV.clickRequestLegalAddressChangeSubmitButton_1();
		}
		
		@And("user should click Change LE Address1 Yes button$")
		public void userClicksChangeLEAddressYesButton_1() throws IOException, InterruptedException {
		
		HCV.clickRequestLegalAddressChangeYesButton_1();
		}
		
		@And("user should click Change LE Address1 OK button$")
		public void userClicksChangeLEAddressOKButton_1() throws IOException, InterruptedException {
		
		HCV.clickRequestLegalAddressChangeOKButton_1();
		}
		
		//////////////////////-- Scenario: Request Legal Address Change Pt. II -- //////////////////////
		
		@And("user selects Address in the dropdown menu$")
		public void userSelectsAddressInDropdown() throws IOException {
		
		HCV.selectAddressChangeOption();
		}
		
		@When("user provides address line II \"(.*?)\"$")
		public void userProvidesAddressLineChange_2(String address) throws IOException {
		
		HCV.provideAddressLine_2(address);
		}
		
		@And("user provides city II \"(.*?)\"$")
		public void userProvidesCity_2(String city) {
		
		HCV.provideCity_2(city);
		}
		
		@And("user selects country II United States - USA$")
		public void userSelectsCountry_2() {
		
		HCV.selectCountry_2();
		}
		
		@And("user selects state II Colorado - CO$")
		public void userSelectsState_2() throws InterruptedException {
		
		HCV.selectState_2();
		}
		
		@And("user provides ZIP code II \"(.*?)\"$")
		public void userProvidesZIPCode_2(String zipcode) {
		
		HCV.provideZIPcode_2(zipcode);
		}
		
		@Then("user should click Change LE Address2 Submit button$")
		public void userClicksChangeLEAddressSubmitButton_2() {
		
		HCV.clickRequestLegalAddressChangeSubmitButton_2();
		}
		
		@And("user should click Change LE Address2 Yes button$")
		public void userClicksChangeLEAddressYesButton_2() throws IOException {
		
		HCV.clickRequestLegalAddressChangeYesButton_2();
		}
		
		@And("user should click Change LE Address2 OK button$")
		public void userClicksChangeLEAddressOKButton_2() throws IOException {
		
		HCV.clickRequestLegalAddressChangeOKButton_2();
		
	}
		
		///////////////////////////////////////JOSE VARGAS' PART///////////////////////////////////////////////
		
		@Given("^User searchs for Contracted CLE$")
		public void user_searchs_for_Contracted_CLE() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			HCV.searchForCLE(System.getenv("CONTRACTED_CLE"));
		}
		
		@Given("^User searchs for CLE \"([^\"]*)\"$")
		public void searchForCLE(String cle) throws Throwable {
		    
			HCV.searchForCLE(cle);
			//Thread.sleep(4000);
		}

		@Given("^User selects View Profile for first result$")
		public void clickArrowMenu() throws Throwable {
			HCV.viewProfileForFirstResult();
		}

		@When("^The profile loads and user goes to Manage billing accounts$")
		public void userGoestoManageBillingAccounts() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			HCV.goToManageBillingAccounts();
		}

		@When("^User clicks on Create Customer Group Button$")
		public void clicksOnCreateCustomerGroupButton() throws Throwable {
		    HCV.clicksCreateCustomerGroup();
		}
 
		@When("^Input \"([^\"]*)\" in Group Name field$")
		public void inputGroupName(String arg1) throws Throwable {
		    HCV.inputGroupName(arg1+Calendar.getInstance().getTime().toString());
		}

		@When("^Clicks Submit button$")
		public void clickSubmitButton() throws Throwable {
			HCV.clickCreateGroupSubmitButton();
		}

		@Then("^New Customer Group Name \"([^\"]*)\" should appear$")
		public void newCustomerGroupAppeared(String arg1) throws Throwable {
			assertTrue( HCV.isCreatedGroupMessageDisplayed() );
		}
		
		@When("^User clicks on Manage Account Numbers$")
		public void userClicksOnManageAccountNumbers() throws Throwable {
			HCV.clickOnManageAccountNumbers();
		}

		@When("^selects an account number and a customer group$")
		public void selectsAnAccountNumberAndCustomerGroup() throws Throwable {
		    HCV.selectsAccountNumberAndCustomerGroup();
		}

		@When("^clicks on actions button and selects Change Customer Group ID$")
		public void clicksOnActionsButtonAndSelectsChangeCustomerGroupID() throws Throwable {
		    HCV.changeCustomerGroupId();
		}

		@Then("^Notification of movement should be displayed$")
		public void notification_of_movement_should_be_displayed() throws Throwable {
			assertTrue( HCV.isMovedGroupMessageDisplayed() );
		}
		
		@Given("^User selects Update Sensitivity for first result$")
		public void userSelectsUpdateSensitivityforfirstresult() throws Throwable {
		    HCV.viewSensitivityForFirstProfole();
		}

		@When("^User changes GSAM Sensitivity to Security Sensitive$")
		public void userChangesGSAMSensitivitytoSecuritySensitive() throws Throwable {
			HCV.changeGSAMSensitivity();
		}

		@When("^moves the first sensitive country to the selected side$")
		public void movesTheFirstSsensitiveCountryToTheSelectedSide() throws Throwable {
		    HCV.moveFirstCountryToSelectedSide();
		}

		@When("^clicks Save Changes Button$")
		public void clicksSaveChangesButton() throws Throwable {
		    HCV.clickSaveChangesButton();
		}

		@Then("^User should accept the successful operation prompt$")
		public void userShouldAcceptTheSuccessfulOperationPrompt() throws Throwable {
			HCV.acceptSuccesfulPrompt();
		}
		
		@And("^User changes back to Non-Sensitive$")
		public void changesBackToNonSensitive() throws InterruptedException{
			Thread.sleep(2000);
			HCV.viewSensitivityForFirstProfole();
			HCV.changeGSAMSensitivity("Non-Sensitive");
			HCV.clickSaveChangesButton();
		}
		
		@When("^Clicks Manage Services$")
		public void clicksManageServices() throws Throwable {
			HCV.navigateToManageServices();
		}

		@When("^Clicks on actions button and clicks Add/Update Purchase Order Number for a Service ID\\(s\\)$")
		public void clicksOnActionsButtonAndClicksAddUpdatePurchaseOrderNumberforaServiceID() throws Throwable {
			HCV.addUpdatePONumberForService();
		}

		@Then("^User should see Purchase Order Number Update - Service screen$")
		public void userShouldSeePurchaseOrderNumberUpdateServiceScreen() throws Throwable {
			assertTrue(HCV.isPONumberUpdateScreenDisplayed());
		}
		
		@Given("^Clicks Update taxation attributes$")
		public void clicksUpdateTaxationAttributes() throws Throwable {
			HCV.clickUpdateTaxationAttribute();
		}

		@Given("^Selects approved check box$")
		public void selectsApprovedCheckBox() throws Throwable {
			HCV.checkApprovedTaxAttribute();
		}

		@Given("^Save Changes$")
		public void saveChanges() throws Throwable {
			HCV.clickSaveChangesButton();
		}

		@Given("^Click Yes to Propagate changes to billing account$")
		public void clickYesToPropagateChangesToBillingAccount() throws Throwable {
		    HCV.propagateChanges();
		}

		@Then("^User selects wich accounts should be propagated$")
		public void userSelectsWichAccountsShouldBePropagated() throws Throwable {
		    HCV.selectAccountsToPropagate();
		}

		@Then("^Click OK on propagation confirmation$")
		public void clickOKOnPropagationConfirmation() throws Throwable {
			HCV.acceptPropagationConfirmation();
		}
		
		

}
