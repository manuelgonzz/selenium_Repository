package com.vz.gch.test.step.definitions;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.vz.gch.containers.ContainerEnvironment;

public class GCHDBDataFetch {

	public static String CLENameField;
	public static String ContractedCLENameField;
	public static String CLENameForNameAddField;
	
	
	 public static  String fetchGCHDBCLEName()  throws ClassNotFoundException, SQLException
	    {
	    	System.out.println("before url");
	    	//CONNECTION URL
	    	String DBURL = ContainerEnvironment.DB_URL;
	    	
	    	System.out.println("before user");
	    	//DB USERNAME
	    	String username = System.getenv("GCH_DB_USER_ID");
	    	
	    	//DB PASSWORD
	    	String password = System.getenv("GCH_DB_USER_PASSWORD");
	    	
	    	//Query to Execute
	    	String query = "SELECT DISTINCT ER.SUBSCRIBER_NAME FROM ESG.SUBSCRIBER ER " +
	    			"WHERE ER.CODE_TYPE = 'LE'"+
	    			"AND CODE_NAME NOT LIKE '%#%' AND SUBSCRIBER_NAME LIKE '%HEALTHCHECK%'  AND GARM_LEVEL != 8 AND  ROWNUM < 10";
	    	
	    	
	    	//Loading mysql jdbc driver
	    	Class.forName("com.mysql.jdbc.Driver");
	    	
	    	
	    	//Connection to the database
	    	Connection con = DriverManager.getConnection(DBURL, username, password);
	    	
	    	//Create Statement Object
	    	Statement stmt = con.createStatement();
	    	System.out.println("executing query");
	    	//Execute the query and store in ResultSet
	    	ResultSet rs = stmt.executeQuery(query);
	    	String CLEName=null;
	    	//Iterate through data 
	    	while (rs.next())
	    	{
	    		 CLEName = rs.getString(1);
	    		 break;
	    	}
	    	//Close DB Connection
	    	con.close();
	    	CLENameField=CLEName;
	    	return CLEName;
	    }
	 
	public static String fetchGCHDBCLENameForNameAddRequest()  throws ClassNotFoundException, SQLException
	    {
	    	System.out.println("before url");
	    	//CONNECTION URL
	    	String DBURL = "jdbc:oracle:thin:@//uiisctd1scan.ebiz.verizon.com:1800/QGCHDB2";
	    	
	    	System.out.println("before user");
	    	//DB USERNAME
	    	String username = "z829708";
	    	
	    	//DB PASSWORD
	    	String password = "Testing5221";
	    	
	    	//Query to Execute
	    	String query = "SELECT ER.SUBSCRIBER_NAME FROM ESG.SUBSCRIBER ER "
	    					+"LEFT JOIN ESG.LE_INQUIRY I ON ER.SUBSCRIBER_OID=I.SUBSCRIBER_OID "
	    					+"WHERE I.SUBSCRIBER_OID IS NULL "
	    					+"AND ER.CODE_TYPE = 'LE' AND CODE_NAME NOT LIKE '%#%' "
	    					+"AND ER.SUBSCRIBER_NAME LIKE '%USA%' AND GARM_LEVEL != 8 "
	    					+"GROUP BY SUBSCRIBER_NAME";
                        		
	    	
	    	
	    	//Loading mysql jdbc driver
	    	Class.forName("com.mysql.jdbc.Driver");
	    	
	    	//Connection to the database
	    	Connection con = DriverManager.getConnection(DBURL, username, password);
	    	
	    	//Create Statement Object
	    	Statement stmt = con.createStatement();
	    	System.out.println("executing query");
	    	//Execute the query and store in ResultSet
	    	ResultSet rs = stmt.executeQuery(query);
	    	String NameAddCLEName = null;
	    	//Iterate through data 
	    	while (rs.next())
	    	{
	    		NameAddCLEName = rs.getString(1);
	    		break;
	    	}
	    	//Close DB Connection
	    	con.close();
	    	CLENameForNameAddField=NameAddCLEName;
	    	return NameAddCLEName;
	    }
	
	public static String fetchGCHDBContractedCLEName()  throws ClassNotFoundException, SQLException
    {
		System.out.println("before url");
    	//CONNECTION URL
    	String DBURL = ContainerEnvironment.DB_URL;
    	
    	System.out.println("before user");
    	//DB USERNAME
    	String username = System.getenv("GCH_DB_USER_ID");
    	
    	//DB PASSWORD
    	String password = System.getenv("GCH_DB_USER_PASSWORD");
    	
    	//Query to Execute
    	String query = "SELECT  ER.SUBSCRIBER_NAME FROM ESG.SUBSCRIBER ER, ESG.SB_SP_MAP AP, ESG.SUBSCRIPTION T "
    				+"WHERE ER.SUBSCRIBER_OID = AP.SUBSCRIBER_OID " 
    				+"AND ER.CODE_TYPE = 'LE' "
    				+"AND ER.CODE_NAME NOT LIKE '%#%' "
    				+"AND AP.SUBSCRIPTION_OID = T.SUBSCRIPTION_OID "
    				+"AND T.SERVICE_TYPE='BTN' AND BACKEND_SYSTEM='PRIMEBILG' AND GARM_LEVEL != 8 AND ROWNUM < 50 ";
                    		
    	
    	
    	//Loading mysql jdbc driver
    	Class.forName("com.mysql.jdbc.Driver");
    	
    	//Connection to the database
    	Connection con = DriverManager.getConnection(DBURL, username, password);
    	
    	//Create Statement Object
    	Statement stmt = con.createStatement();
    	System.out.println("executing query");
    	//Execute the query and store in ResultSet
    	ResultSet rs = stmt.executeQuery(query);
    	String NameAddCLEName = null;
    	//Iterate through data 
    	while (rs.next())
    	{
    		NameAddCLEName = rs.getString(1);
    		break;
    	}
    	//Close DB Connection
    	con.close();
    	ContractedCLENameField=NameAddCLEName;
    	return NameAddCLEName;
    }
	
	

}
