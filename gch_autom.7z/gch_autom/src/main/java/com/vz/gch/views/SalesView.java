package com.vz.gch.views;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.vz.gch.containers.LegalEntityContainer;
import com.vz.gch.containers.SalesViewContainer;

public class SalesView {

	private SalesViewContainer container;
	private CommonFunctions common;
	private WebElement SalesAccounts;
	private WebElement NumberOfNASPID;
	private WebElement NASPID_DC;
	private WebElement NASPID_F2AlphaC;
	private WebElement Branch;
	private WebElement FinanceRevLoc;
	private WebElement FinanceRevLoc_Description;
	private WebElement FinanceRevLoc_Button;
	private WebElement NASPType;
	private WebElement Cancel;
	private WebElement Create;
	private WebElement CreateBankNASPs;
	private WebElement CreateBankNASP;
	private WebElement SelectFinanceRevLoc;
	private WebElement FinanceRevLoc_SearchButton;
	private WebElement NASPSearch;
	private WebElement NASPID;
	private WebElement NASPName;
	private WebElement GUDUNS;
	private WebElement GUDUNSName;
	private WebElement DUNS;
	private WebElement DUNSName;
	private WebElement NASPTypeName;
	private WebElement NASPTypeCodeCode;
	private WebElement BranchNameName;
	private WebElement SegmentNameName;
	private WebElement SegmentCodeCode;
	private WebElement RegionNameName;
	private WebElement RegionCodeCode;
	private WebElement BranchCodeCode;
	private WebElement ParentNASPSearch_SearchButton;
	private WebElement CheckButtonNASP_ParentNASPSearchResult;
	private WebElement EditButton;
	private WebElement UpdateNASPName;
	private WebElement UpdateNASPType;
	private WebElement UpdateVerticalReporting;
	private WebElement UpdateLowerIndustry;
    private WebElement CheckValidforTagging;
    private WebElement CheckPublishType1;
    private WebElement CheckPublishType2;
    private WebElement CheckPublishType3;
    private WebElement CheckViewable;
    private WebElement UpdateBranch;
    private WebElement UpdateFinanceRevLoc;
    private WebElement UpdateFinanceRevLoc_Description;
	private WebElement UpdateFinanceRevLoc_Button;
    private WebElement UpdateComments;
    private WebElement SaveChanges;
    private WebElement ClickExportButton;
    private WebElement TextFileCheckButton;
    private WebElement ExcelCheckButton;
    private WebElement ExportParentNASPSearchExport;
    private WebElement DownloadFileParentNASPSearchExport;
    private WebElement CancelExport;
    private WebElement DeleteButton;
    private WebElement RedDeleteButton;
    private WebElement DeleteComment;
    private WebElement AccountSearch;
    private WebElement OriginalAccountIDTB;
    private WebElement TranslatedAccountIDTB;
    private WebElement ParentNaspIDTB;
    private WebElement ParentNaspNameTB;
    private WebElement ParentBranchTB;
    private WebElement SubNaspIDTB;
    private WebElement SubNaspNameTB;
    private WebElement OpcoCodeTB;
    private WebElement AccountNameTB;
    private WebElement DunsIDTB;
    private WebElement DunsNameTB;
    private WebElement AccountSearch_SearchButton;
    private WebElement AccountSearch_ExportButton;
    private WebElement DownloadFileAccountSearchExport;
    private WebElement AccountSearchCancel;
    private WebElement SegmentLink;
    private WebElement RegionsLink;
    private WebElement Segments_ExportButton;
    private WebElement Regions_ExportButton;
    private WebElement DownloadFileSegmentsExport;
    private WebElement SegmentsCancel;
    private WebElement DownloadFileRegionsExport;
    private WebElement ManagerRoles;
    private WebElement ManagerRoles_Export;
    private WebElement DownloadFileManagerRolesExport;
    private WebElement MR_RoleLongName;
    private WebElement MR_RoleShortName;
    private WebElement MR_Comment;
    private WebElement level_A;
    private WebElement level_B;
    private WebElement level_C;
    private WebElement level_D;
    private WebElement level_E;
    private WebElement level_F;
    private WebElement Save_CommentMR;
    private WebElement SegmentExportButton;
    private WebElement AccountSearchLink;
    private WebElement AccountSearchTextBox;
    private WebElement AccountSearchButtonSearch;
    private WebElement AccountSearchResults;
    
    
	public static String parentWindow;
	private String SVNumberOfNASPs;
	private String SVNASPID_DC;
	private String SVNASPID_F2AlphaC;
	private String SVBranch;
	private String SVFinanceRevLoc;
	private String SVFinanceRevLoc_Description;
	private String SVNASPType;
	private String SVNASPID;
	private String SVNASPName;
	private String SVGUDUNS;
	private String SVGUDUNSName;
	private String SVDUNS;
	private String SVDUNSName;
	private String SVNASPTypeName;
	private String SVNASPTypeCodeCode;
	private String SVBranchNameName;
	private String SVSegmentNameName;
	private String SVSegmentCodeCode;
	private String SVRegionNameName;
	private String SVRegionCodeCode;
	private String SVBranchCodeCode;
	private String SVUpdateNASPName;
	private String SVUpdateNASPType;
	private String SVUpdateVerticalReporting;
	private String SVUpdateLowerIndustry;
	private String SVCheckValidforTagging;
	private String SVCheckPublishType1;
	private String SVCheckPublishType2;
	private String SVCheckPublishType3;
	private String SVCheckViewable;
	private String SVUpdateBranch;
	private String SVUpdateFinanceRevLoc;
	private String SVUpdateFinanceRevLoc_Description;
	private String SVUpdateComments;
	private String SVSaveChanges;
	private String SVOriginalAccountIDTB;
    private String SVTranslatedAccountIDTB;
    private String SVParentNaspIDTB;
    private String SVParentNaspNameTB;
    private String SVParentBranchTB;
    private String SVSubNaspIDTB;
    private String SVSubNaspNameTB;
    private String SVOpcoCodeTB;
    private String SVAccountNameTB;
    private String SVDunsIDTB;
    private String SVDunsNameTB;
    private String SVMR_Level;
    private String SVMR_RoleLongName;
    private String SVMR_RoleShortName;
    private String SVMR_Comment;
    private String AccountSearchValue;

	
	
	
	
	
	public SalesView(WebDriver driver) {
		container = new SalesViewContainer(driver);
		common = new CommonFunctions(driver);
	}
	
	public void salesViewAppMainPage() throws IOException
	{	
	 CommonFunctions.switchToPopUp();
	 CommonFunctions.maximizeBrowser();
	 container.waitForElement(120, container.getCreateBankNASPsxpath(),"xpath");
	}
	

	
	public void GetSV_Managementdata(String NumberOfNASPs, String NASPID_DC, String NASPID_F2AlphaC, String Branch, String FinanceRevLoc, String FinanceRevLoc_Description, String NASPType)
	{
		ArrayList <String> SVInfo = new ArrayList<String>(); 
		SVInfo.add(NumberOfNASPs);
		SVInfo.add(NASPID_DC);
		SVInfo.add(NASPID_F2AlphaC);
		SVInfo.add(Branch);
		SVInfo.add(FinanceRevLoc);
		SVInfo.add(FinanceRevLoc_Description);
		SVInfo.add(NASPType);


		
		for(int i=0; i<SVInfo.size(); i++)
		{
			if(SVInfo.get(i).equals(null))
			{
				System.out.format("SV Info element is empty", SVInfo.get(i));
				
			}
			System.out.println(SVInfo.get(i));
		}
		
		
		this.SVNumberOfNASPs=SVInfo.get(0);
		this.SVNASPID_DC=SVInfo.get(1);
		this.SVNASPID_F2AlphaC=SVInfo.get(2);
		this.SVBranch=SVInfo.get(3);
		this.SVFinanceRevLoc=SVInfo.get(4);
		this.SVFinanceRevLoc_Description=SVInfo.get(5);
		this.SVNASPType=SVInfo.get(6);

		
		

		
	
	}
	
/*	public void clickCreateCLE() throws IOException
	{	CommonFunctions.switchToPopUp();
		CreateCLELink=container.getCreateCLElink();
		String CCLELink=CreateCLELink.getText();
		container.waitForElement(30,CommonFunctions.ConcatenateXpath(CCLELink),"xpath");
		CreateCLELink.click();
	}
	*/
	
	public void CreateBankNASP() throws IOException
	{	
	 CommonFunctions.switchToPopUp();
	 CommonFunctions.maximizeBrowser();
     container.waitForElement(120, container.getCreateBankNASPsxpath(),"xpath");
     CreateBankNASPs = container.getCreateBankNASPs();
     CreateBankNASPs.click();
     
	}
	
	
	public void CustomerInformationFillNASPs() throws IOException, InterruptedException
	{
		
		 CommonFunctions.switchToPopUp();
	     container.waitForElement(120, container.getNumberOfNASPIDxpath(),"xpath");
	     Thread.sleep(5000);
	     NumberOfNASPID = container.getNumberOfNASPID();
	     NumberOfNASPID.click();
		
		
	    Thread.sleep(1000);
		CommonFunctions.switchToPopUp();
		NumberOfNASPID=container.getNumberOfNASPID();
		Thread.sleep(1000);
		CommonFunctions.switchToPopUp();
		CommonFunctions.maximizeBrowser();
		NASPID_DC=container.getNASPID_DC();
		Thread.sleep(1000);
		CommonFunctions.switchToPopUp();
		NASPID_F2AlphaC=container.getNASPID_F2AlphaC();
		
		
		CommonFunctions.switchToPopUp();
		NumberOfNASPID.sendKeys(SVNumberOfNASPs);
		
		Thread.sleep(1000);
		CommonFunctions.switchToPopUp();
		CommonFunctions.maximizeBrowser();
		NASPID_DC.sendKeys(SVNASPID_DC);
		
		
		Thread.sleep(1000);
		CommonFunctions.switchToPopUp();
		NASPID_F2AlphaC.sendKeys(SVNASPID_F2AlphaC);
	  
		
	     //String CreateBankNASPlink = CreateBankNASP.getText();
	     //container.waitForElement(40,CommonFunctions.ConcatenateXpath(CreateBankNASPlink),"xpath");
	     
	    CommonFunctions.switchToPopUp();
		CommonFunctions.maximizeBrowser();
		container.waitForElement(120, container.getBranchxpath(), "xpath");
		Branch=container.getBranch();
		new Select(Branch).selectByVisibleText(SVBranch);
				
		CommonFunctions.switchToPopUp();
	    container.waitForElement(120, container.getFinanceRevLoc_Buttonxpath(),"xpath");
	    FinanceRevLoc_Button = container.getFinanceRevLoc_Button();
	    CommonFunctions.maximizeBrowser();
	    FinanceRevLoc_Button.click();
	   
	    
	    CommonFunctions.switchToPopUp();
		CommonFunctions.maximizeBrowser();
		container.waitForElement(120, container.getFinanceRevLocxpath(),"xpath");
		FinanceRevLoc=container.getFinanceRevLoc();
	
		
		CommonFunctions.switchToPopUp();
		CommonFunctions.maximizeBrowser();
		container.waitForElement(120, container.getFinanceRevLoc_Descriptionxpath(),"xpath");
		FinanceRevLoc_Description=container.getFinanceRevLoc_Description();
	
		CommonFunctions.switchToPopUp();
	    CommonFunctions.maximizeBrowser();
	    container.waitForElement(120, container.getFinanceRevLocxpath(),"xpath");
		FinanceRevLoc.sendKeys(SVFinanceRevLoc);

		CommonFunctions.switchToPopUp();
		container.waitForElement(120, container.getFinanceRevLoc_Descriptionxpath(),"xpath");
		FinanceRevLoc_Description.sendKeys(SVFinanceRevLoc_Description);
		
		CommonFunctions.switchToPopUp();
	    container.waitForElement(40, container.getFinanceRevLoc_SearchButtonxpath(),"xpath");
	    FinanceRevLoc_SearchButton = container.getFinanceRevLoc_SearchButton();
	    FinanceRevLoc_SearchButton.click();
			
	    CommonFunctions.switchToPopUp();
	    container.waitForElement(40, container.getSelectFinanceRevLocxpath(),"xpath");
	    SelectFinanceRevLoc = container.getSelectFinanceRevLoc();
	    SelectFinanceRevLoc.click();
	    Thread.sleep(4000);
	    
	    container.waitForElement(120, container.getNASPTypexpath(), "xpath");
		NASPType =container.getNASPType();
		new Select(NASPType).selectByVisibleText(SVNASPType);
				
				
	}
	
	
	public void Create() throws IOException, InterruptedException
	{	
	
	 CommonFunctions.switchToPopUp();
	 //CommonFunctions.maximizeBrowser();
     container.waitForElement(120, container.getCreatexpath(),"xpath");
     Thread.sleep(2000);
     Create = container.getCreate();
     Create.click();
     
	}
	
	
	public void BankNaspCreated() throws IOException, InterruptedException
	{	
		
		container.waitForElement(10, container.getBankNASPIDCreatedLabel_xpath(), "xpath");
     
	}
	   
	public void NaspSearchEdited() throws IOException, InterruptedException
	{	
		
		container.waitForElement(10, container.getBankNASPIDCreatedLabel_xpath(), "xpath");
     
	}
	
	    public void clickNASPSearch() throws IOException, InterruptedException{
	    	Thread.sleep(5000);
	    	CommonFunctions.switchToPopUp();
	    	container.waitForElement(120, container.getNASPSearchxpath(), "xpath");
	    	NASPSearch = container.getNASPSearch();
	    	NASPSearch.click();
	    	
	    }
	    
	    
	 public void GetSVManagementParentNASPSearchData(String NASPID, String NASPName, String GUDUNS, String GUDUNSName, String DUNS, String DUNSName, String NASPTypeName, String NASPTypeCodeCode, String BranchNameName, String SegmentNameName, String SegmentCodeCode, String RegionNameName, String RegionCodeCode, String BranchCodeCode){
		ArrayList <String> SVInfo = new ArrayList<String>(); 
		SVInfo.add(NASPID);
		SVInfo.add(NASPName);
		SVInfo.add(GUDUNS);
		SVInfo.add(GUDUNSName);
		SVInfo.add(DUNS);
		SVInfo.add(DUNSName);
		SVInfo.add(NASPTypeName);
		SVInfo.add(NASPTypeCodeCode);
		SVInfo.add(BranchNameName);
		SVInfo.add(SegmentNameName);
		SVInfo.add(SegmentCodeCode);
		SVInfo.add(RegionNameName);
		SVInfo.add(RegionCodeCode);
		SVInfo.add(BranchCodeCode);
		
		
		
		for(int i=0; i<SVInfo.size(); i++)
		{
			if(SVInfo.get(i).equals(null))
			{
				System.out.format("SV Info element is empty", SVInfo.get(i));
				
			}
			System.out.println(SVInfo.get(i));
		}
		
		
		this.SVNASPID = SVInfo.get(0);
		this.SVNASPName = SVInfo.get(1);
		this.SVGUDUNS = SVInfo.get(2);
		this.SVGUDUNSName = SVInfo.get(3);
		this.SVDUNS = SVInfo.get(4);
		this.SVDUNSName = SVInfo.get(5);
		this.SVNASPTypeName = SVInfo.get(6);
		this.SVNASPTypeCodeCode = SVInfo.get(7);
		this.SVBranchNameName = SVInfo.get(8);
		this.SVSegmentNameName = SVInfo.get(9);
		this.SVSegmentCodeCode = SVInfo.get(10);
		this.SVRegionNameName = SVInfo.get(11);
		this.SVRegionCodeCode = SVInfo.get(12);
		this.SVBranchCodeCode = SVInfo.get(13);
		
	 }
	 
 public void fillInformationforParentNASPSearch() throws IOException, InterruptedException{
	 
	 CommonFunctions.switchToPopUp();
	 container.waitForElement(60,container.getNASPIDxpath(), "xpath");
	 NASPID = container.getNASPID();
	 NASPID.click();
	 NASPName = container.getNASPName();
	 GUDUNS = container.getGUDUNS();
	 GUDUNSName = container.getGUDUNSName();
	 DUNS = container.getDUNS();
	 DUNSName = container.getDUNSName();
	 NASPTypeName = container.getNASPTypeName();
	 NASPTypeCodeCode = container.getNASPTypeCodeCode();
	 BranchNameName = container.getBranchNameName();
	 SegmentNameName = container.getSegmentNameName();
	 SegmentCodeCode = container.getSegmentCodeCode();
	 RegionNameName = container.getRegionNameName();
	 RegionCodeCode = container.getRegionCodeCode();
	 BranchCodeCode = container.getBranchCodeCode();
     
	 
	 NASPID.sendKeys(SVNASPID);
	 NASPName.sendKeys(SVNASPName);
	 GUDUNS.sendKeys(SVGUDUNS);
	 GUDUNSName.sendKeys(SVGUDUNSName);
	 DUNS.sendKeys(SVDUNS);
	 DUNSName.sendKeys(SVDUNSName);
	 new Select(NASPTypeName).selectByVisibleText(SVNASPTypeName);
	 new Select(NASPTypeCodeCode).selectByVisibleText(SVNASPTypeCodeCode);
	 new Select(BranchNameName).selectByVisibleText(SVBranchNameName);
	 new Select(SegmentNameName).selectByVisibleText(SVSegmentNameName);
	 new Select(SegmentCodeCode).selectByVisibleText(SVSegmentCodeCode);
	 new Select(RegionNameName).selectByVisibleText(SVRegionNameName);
	 new Select(RegionCodeCode).selectByVisibleText(SVRegionCodeCode);		 
	 }
 
     
 public void clickParentNASPSearch_SearchButton() throws IOException{
	 container.waitForElement(40, container.getParentNASPSearch_SearchButtonxpath(), "xpath");
	 ParentNASPSearch_SearchButton = container.getParentNASPSearch_SearchButton();
	 ParentNASPSearch_SearchButton.click();
 }
 
 public void CheckButtonNASP_ParentNASPSearchResult() throws IOException, InterruptedException{
	 CommonFunctions.switchToPopUp();
	 container.waitForElement(20, container.getCheckButtonNASP_ParentNASPSearchResultxpath(), "xpath");
	 Thread.sleep(2000);
	 CheckButtonNASP_ParentNASPSearchResult = container.getCheckButtonNASP_ParentNASPSearchResult();
	 Thread.sleep(2000);
	 CheckButtonNASP_ParentNASPSearchResult.click();
	 
 }
 
 public void clickEdiButton() throws IOException, InterruptedException{
	 container.waitForElement(10, container.getEditButtonxpath(), "xpath");
	 EditButton = container.getEditButton();
	 EditButton.click();
	 
 }
 
 
 public void getSV_ManagementdataEditNASP(String UpdateNASPName, String UpdateNASPType, String UpdateVerticalReporting, String UpdateLowerIndustry, String UpdateBranch, String FinanceRevLoc, String FinanceRevLoc_Description)
	{
		ArrayList <String> SVInfo = new ArrayList<String>(); 
		SVInfo.add(UpdateNASPName);
		SVInfo.add(UpdateNASPType);
		SVInfo.add(UpdateVerticalReporting);
		SVInfo.add(UpdateLowerIndustry);
		SVInfo.add(UpdateBranch);
		SVInfo.add(FinanceRevLoc);
		SVInfo.add(FinanceRevLoc_Description);
		
		

		
		for(int i=0; i<SVInfo.size(); i++)
		{
			if(SVInfo.get(i).equals(null))
			{
				System.out.format("SV Info element is empty", SVInfo.get(i));
				
			}
			System.out.println(SVInfo.get(i));
		}
		
		

		this.SVUpdateNASPName = SVInfo.get(0);
		this.SVUpdateNASPType = SVInfo.get(1);
		this.SVUpdateVerticalReporting = SVInfo.get(2);
		this.SVUpdateLowerIndustry = SVInfo.get(3);
		this.SVUpdateBranch = SVInfo.get(4);
		this.SVUpdateFinanceRevLoc = SVInfo.get(5);
		this.SVUpdateFinanceRevLoc_Description=SVInfo.get(6);
		
		
		

		
	
	}
 
 
 public void editNASP() throws IOException, InterruptedException{
	 CommonFunctions.switchToPopUp();
	 container.waitForElement(40,container.getUpdateNASPNamexpath(), "xpath");
	 UpdateNASPName = container.getUpdateNASPName();
	 UpdateNASPName.click();
	 UpdateNASPName.clear();
	
 	 CommonFunctions.switchToPopUp();
	 container.waitForElement(40,container.getUpdateNASPTypexpath(), "xpath");
	 UpdateNASPType = container.getUpdateNASPType();
	 
 	 CommonFunctions.switchToPopUp();
	 container.waitForElement(40,container.getUpdateVerticalReportingxpath(), "xpath");
	 UpdateVerticalReporting = container.getUpdateVerticalReporting();

 	 CommonFunctions.switchToPopUp();
	 container.waitForElement(40,container.getUpdateLowerIndustryxpath(), "xpath");
	 UpdateLowerIndustry = container.getUpdateLowerIndustry();
	
 	 CommonFunctions.switchToPopUp();
	 container.waitForElement(40,container.getUpdateBranchxpath(), "xpath");
	 UpdateBranch = container.getUpdateBranch();
	 
	 
	 UpdateNASPName.sendKeys(SVUpdateNASPName);
	 new Select(UpdateNASPType).selectByVisibleText(SVUpdateNASPType);
	 new Select(UpdateVerticalReporting).selectByVisibleText(SVUpdateVerticalReporting);
	 new Select(UpdateLowerIndustry).selectByVisibleText(SVUpdateLowerIndustry);
	 new Select(UpdateBranch).selectByVisibleText(SVUpdateBranch);
	 
	 	
		CommonFunctions.switchToPopUp();
	    container.waitForElement(40, container.getFinanceRevLoc_Buttonxpath(),"xpath");
	    FinanceRevLoc_Button = container.getFinanceRevLoc_Button();
	    CommonFunctions.maximizeBrowser();
	    FinanceRevLoc_Button.click();
	   
	    
	    
		CommonFunctions.switchToPopUp();
		CommonFunctions.maximizeBrowser();
		container.waitForElement(40, container.getFinanceRevLocxpath(),"xpath");
		FinanceRevLoc=container.getFinanceRevLoc();
	
		
	
		CommonFunctions.switchToPopUp();
		CommonFunctions.maximizeBrowser();
		container.waitForElement(40, container.getFinanceRevLoc_Descriptionxpath(),"xpath");
		FinanceRevLoc_Description=container.getFinanceRevLoc_Description();
	
		
		
		

	 
	    CommonFunctions.maximizeBrowser();
	    container.waitForElement(40, container.getFinanceRevLocxpath(),"xpath");
		FinanceRevLoc.sendKeys(SVUpdateFinanceRevLoc);

		

		CommonFunctions.switchToPopUp();
		container.waitForElement(40, container.getFinanceRevLoc_Descriptionxpath(),"xpath");
		FinanceRevLoc_Description.sendKeys(SVUpdateFinanceRevLoc_Description);
		

		CommonFunctions.switchToPopUp();
	    container.waitForElement(40, container.getFinanceRevLoc_SearchButtonxpath(),"xpath");
	    FinanceRevLoc_SearchButton = container.getFinanceRevLoc_SearchButton();
	    FinanceRevLoc_SearchButton.click();
			
	    

		CommonFunctions.switchToPopUp();
	    container.waitForElement(40, container.getSelectFinanceRevLocxpath(),"xpath");
	    SelectFinanceRevLoc = container.getSelectFinanceRevLoc();
	    SelectFinanceRevLoc.click();
	 
	    
	    
	 
   } 
      
 public void editComments(String arg1) throws IOException, InterruptedException{
	    Thread.sleep(5000);
	    CommonFunctions.switchToPopUp();
	    container.waitForElement(40, container.getUpdateCommentsxpath(), "xpath");
	    UpdateComments = container.getUpdateComments();
	    //UpdateComments.clear();
	    UpdateComments.sendKeys(arg1);
	 
	 
 }
 
 
 public void clickSaveChanges() throws IOException, InterruptedException{
	 Thread.sleep(5000);
	 CommonFunctions.switchToPopUp();
	 container.waitForElement(40, container.getSaveChangesxpath(), "xpath");
	 SaveChanges = container.getSaveChanges();
	 SaveChanges.click();
 }
 
 public void Cancelupdate() throws IOException, InterruptedException
	{	
		
		Thread.sleep(5000);
CommonFunctions.switchToPopUp();
	 //CommonFunctions.maximizeBrowser();
  container.waitForElement(120, container.getCancelUpdatexpath(),"xpath");
  Cancel= container.getCancelUpdate();
  Cancel.click();
  
	}
 
 
 
 
 
 
 
 
 public void GetSVManagementParentNASPSearchData2(String NASPID, String NASPName, String GUDUNS, String GUDUNSName, String DUNS, String DUNSName){
		ArrayList <String> SVInfo = new ArrayList<String>(); 
		SVInfo.add(NASPID);
		SVInfo.add(NASPName);
		SVInfo.add(GUDUNS);
		SVInfo.add(GUDUNSName);
		SVInfo.add(DUNS);
		SVInfo.add(DUNSName);

		
		
		
		for(int i=0; i<SVInfo.size(); i++)
		{
			if(SVInfo.get(i).equals(null))
			{
				System.out.format("SV Info element is empty", SVInfo.get(i));
				
			}
			System.out.println(SVInfo.get(i));
		}
		
		
		this.SVNASPID = SVInfo.get(0);
		this.SVNASPName = SVInfo.get(1);
		this.SVGUDUNS = SVInfo.get(2);
		this.SVGUDUNSName = SVInfo.get(3);
		this.SVDUNS = SVInfo.get(4);
		this.SVDUNSName = SVInfo.get(5);

		
	 }
	 
public void fillInformationforParentNASPSearch2() throws IOException, InterruptedException{
	 
	 CommonFunctions.switchToPopUp();
	 container.waitForElement(40,container.getNASPIDxpath(), "xpath");
	 NASPID = container.getNASPID();
	 NASPID.click();
	 NASPName = container.getNASPName();
	 GUDUNS = container.getGUDUNS();
	 GUDUNSName = container.getGUDUNSName();
	 DUNS = container.getDUNS();
	 DUNSName = container.getDUNSName();
	 
  
	 
	 NASPID.sendKeys(SVNASPID);
	 NASPName.sendKeys(SVNASPName);
	 GUDUNS.sendKeys(SVGUDUNS);
	 GUDUNSName.sendKeys(SVGUDUNSName);
	 DUNS.sendKeys(SVDUNS);
	 DUNSName.sendKeys(SVDUNSName);
	 		 
	 }

  
public void clickParentNASPSearch_SearchButton2() throws IOException{
	 container.waitForElement(40, container.getParentNASPSearch_SearchButtonxpath(), "xpath");
	 ParentNASPSearch_SearchButton = container.getParentNASPSearch_SearchButton();
	 ParentNASPSearch_SearchButton.click();
}

public void CheckButtonNASP_ParentNASPSearchResult2() throws IOException{
	 CommonFunctions.switchToPopUp();
	 container.waitForElement(120, container.getCheckButtonNASP_ParentNASPSearchResultxpath(), "xpath");
	 CheckButtonNASP_ParentNASPSearchResult = container.getCheckButtonNASP_ParentNASPSearchResult();
	 CheckButtonNASP_ParentNASPSearchResult.click();
	 
}
 
 
 
 
 
 public void ExportButton() throws IOException, InterruptedException{
	 CommonFunctions.switchToPopUp();
	 container.waitForElement(40, container.getClickExportButtonxpath(), "xpath");
	 ClickExportButton = container.getClickExportButtong();
	 ClickExportButton.click();
 }
 
 public void clickExportParentNASPSearchExport() throws IOException, InterruptedException{
	 Thread.sleep(5000);
	 CommonFunctions.switchToPopUp();
	 container.waitForElement(120, container.getExportParentNASPSearchExportxpath(), "xpath");
	 ExportParentNASPSearchExport = container.getExportParentNASPSearchExport();
	 ExportParentNASPSearchExport.click();
 }
 
 public void clickDownloadFileParentNASPSearchExport() throws IOException, InterruptedException, AWTException{
	 Thread.sleep(5000);
	 CommonFunctions.switchToPopUp();
	 container.waitForElement(120, container.getDownloadFileParentNASPSearchExportxpath(), "xpath");
	 DownloadFileParentNASPSearchExport = container.getDownloadFileParentNASPSearchExport();
	 DownloadFileParentNASPSearchExport.click();
	 Thread.sleep(1000L);
     //create robot object
     Robot robot = new Robot();
     Thread.sleep(1000L);
     //Click Down Arrow Key to select "Save File" Radio Button
     robot.keyPress(KeyEvent.VK_DOWN);
     Thread.sleep(1000L);
     // Click 3 times Tab to take focus on "OK" Button
     robot.keyPress(KeyEvent.VK_TAB);
     Thread.sleep(1000L);
     robot.keyPress(KeyEvent.VK_TAB);
     Thread.sleep(1000L);
     robot.keyPress(KeyEvent.VK_TAB);
     Thread.sleep(1000L);
     //Click "Enter" Button to download file
     robot.keyPress(KeyEvent.VK_ENTER);
     Thread.sleep(5000L);
     System.out.println("Robot work Complete");
 }
 
public void clickExcelCheckButton() throws IOException, InterruptedException{
	CommonFunctions.switchToPopUp();
	Thread.sleep(5000);
	container.waitForElement(40, container.getExcelCheckButtonxpath(), "xpath");
	ExcelCheckButton = container.getExcelCheckButton();
	ExcelCheckButton.click();
}

public void clickCancelExport() throws IOException, InterruptedException{
	CommonFunctions.switchToPopUp();
	Thread.sleep(5000);
	container.waitForElement(40, container.getCancelExportxpath(), "xpath");
	CancelExport = container.getCancelExport();
	CancelExport.click();
}

public void clickDeleteButton() throws IOException, InterruptedException{
	CommonFunctions.switchToPopUp();
	Thread.sleep(5000);
	container.waitForElement(40, container.getDeletexpath(), "xpath");
	DeleteButton = container.getDelete();
	DeleteButton.click();
}

public void clickRedDeleteButton() throws IOException, InterruptedException{
	CommonFunctions.switchToPopUp();
	container.waitForElement(40, container.getRedDeleteButtonxpath(), "xpath");
	RedDeleteButton = container.getRedDeleteButton();
	RedDeleteButton.click();
	Thread.sleep(5000);
	
}

public void clickAccountSearch() throws IOException, InterruptedException{
	CommonFunctions.switchToPopUp();
	container.waitForElement(40, container.getAccountSearchxpath(), "xpath");
	AccountSearch = container.getAccountSearch();
	AccountSearch.click();	
}


public void getSVManagementSearchCriteria(String OriginalAccountIDTB, String TranslatedAccountIDTB, String ParentNaspIDTB, String ParentNaspNameTB, String ParentBranchTB, 
		String SubNaspIDTB, String SubNaspNameTB, String OpcoCodeTB, String AccountNameTB,String DunsIDTB,String DunsNameTB){
	ArrayList <String> SVInfo = new ArrayList<String>(); 
	SVInfo.add(OriginalAccountIDTB);
	SVInfo.add(TranslatedAccountIDTB);
	SVInfo.add(ParentNaspIDTB);
	SVInfo.add(ParentNaspNameTB);
	SVInfo.add(ParentBranchTB);
	SVInfo.add(SubNaspIDTB);
	SVInfo.add(SubNaspNameTB);
	SVInfo.add(OpcoCodeTB);
	SVInfo.add(AccountNameTB);
	SVInfo.add(DunsIDTB);
	SVInfo.add(DunsNameTB);

	
	
	
	for(int i=0; i<SVInfo.size(); i++)
	{
		if(SVInfo.get(i).equals(null))
		{
			System.out.format("SV Info element is empty", SVInfo.get(i));
			
		}
		System.out.println(SVInfo.get(i));
	}
	
	
	this.SVOriginalAccountIDTB = SVInfo.get(0);
	this.SVTranslatedAccountIDTB = SVInfo.get(1);
	this.SVParentNaspIDTB = SVInfo.get(2);
	this.SVParentNaspNameTB = SVInfo.get(3);
	this.SVParentBranchTB = SVInfo.get(4);
	this.SVSubNaspIDTB = SVInfo.get(5);
	this.SVSubNaspNameTB = SVInfo.get(6);
	this.SVOpcoCodeTB = SVInfo.get(7);
	this.SVAccountNameTB = SVInfo.get(8);
	this.SVDunsIDTB = SVInfo.get(9);
	this.SVDunsNameTB = SVInfo.get(10);
	

	
 }
 
public void fillSearchCriteria() throws IOException, InterruptedException{
 
 CommonFunctions.switchToPopUp();
 container.waitForElement(40,container.getOriginalAccountIDxpath(), "xpath");
 OriginalAccountIDTB = container.getOriginalAccountID();
 OriginalAccountIDTB.click();
 TranslatedAccountIDTB = container.getTranslatedAccountID();
 ParentNaspIDTB = container.getParentNaspID();
 ParentNaspNameTB = container.getParentNaspName();
 ParentBranchTB = container.getParentBranch();
 SubNaspIDTB = container.getSubNaspID();
 SubNaspNameTB = container.getSubNaspName();
 OpcoCodeTB = container.getOpcoCode();
 AccountNameTB = container.getAccountNameTextbox();
 DunsIDTB = container.getDunsID();
 DunsNameTB = container.getDunsName();
 

 
 OriginalAccountIDTB.sendKeys(SVOriginalAccountIDTB);
 TranslatedAccountIDTB.sendKeys(SVTranslatedAccountIDTB);
 ParentNaspIDTB.sendKeys(SVParentNaspIDTB);
 ParentNaspNameTB.sendKeys(SVParentNaspNameTB);
 ParentBranchTB.sendKeys(SVParentBranchTB);
 SubNaspIDTB.sendKeys(SVSubNaspIDTB);
 SubNaspNameTB.sendKeys(SVSubNaspNameTB);
 OpcoCodeTB.sendKeys(SVOpcoCodeTB);
 AccountNameTB.sendKeys(SVAccountNameTB);
 DunsIDTB.sendKeys(SVDunsIDTB);
 DunsNameTB.sendKeys(SVDunsNameTB);
 		 
 }

public void clickAccountSearch_SearchButton() throws IOException{
	 container.waitForElement(40, container.getAccountSearch_SearchButtonxpath(), "xpath");
	 AccountSearch_SearchButton = container.getAccountSearch_SearchButton();
	 AccountSearch_SearchButton.click();
}

public void clickAccountSearch_ExportButton() throws IOException{
	 container.waitForElement(40, container.getAccountSearch_ExportButtonxpath(), "xpath");
	 AccountSearch_ExportButton = container.getAccountSearch_ExportButton();
	 AccountSearch_ExportButton.click();
}


public void clickDownloadFileAccountSearchExport() throws IOException, InterruptedException, AWTException{
	 Thread.sleep(5000);
	 CommonFunctions.switchToPopUp();
	 container.waitForElement(120, container.getDownloadFileAccountSearchExportxpath(), "xpath");
	 DownloadFileParentNASPSearchExport = container.getDownloadFileAccountSearchExport();
	 DownloadFileParentNASPSearchExport.click();
	 Thread.sleep(1000L);
    //create robot object
    Robot robot = new Robot();
    Thread.sleep(1000L);
    //Click Down Arrow Key to select "Save File" Radio Button
    robot.keyPress(KeyEvent.VK_DOWN);
    Thread.sleep(1000L);
    // Click 3 times Tab to take focus on "OK" Button
    robot.keyPress(KeyEvent.VK_TAB);
    Thread.sleep(1000L);
    robot.keyPress(KeyEvent.VK_TAB);
    Thread.sleep(1000L);
    robot.keyPress(KeyEvent.VK_TAB);
    Thread.sleep(1000L);
    //Click "Enter" Button to download file
    robot.keyPress(KeyEvent.VK_ENTER);
    Thread.sleep(5000L);
    System.out.println("Robot work Complete");
}


public void clickAccountSearchCancel() throws IOException, InterruptedException
{	
	
 Thread.sleep(5000);
 CommonFunctions.switchToPopUp();
 //CommonFunctions.maximizeBrowser();
 container.waitForElement(120, container.getAccountSeachCancelxpath(),"xpath");
 AccountSearchCancel= container.getAccountSearchCancel();
 AccountSearchCancel.click();
 
}

public void clickSegmentsLink() throws IOException, InterruptedException{
	Thread.sleep(5000);
	CommonFunctions.switchToPopUp();
	container.waitForElement(40, container.getSegmentsLinkxpath(), "xpath");
	SegmentLink = container.getSegmentLink();
	SegmentLink.click();
}

public void clickSegments_ExportButton() throws IOException, InterruptedException{
	Thread.sleep(5000);
	CommonFunctions.switchToPopUp();
	 container.waitForElement(40, container.getSegments_ExportButtonxpath(), "xpath");
	 Segments_ExportButton = container.getSegments_ExportButton();
	 Segments_ExportButton.click();
}

public void clickDownloadFileSegmentsExport() throws IOException, InterruptedException, AWTException{
	Thread.sleep(5000);
	 CommonFunctions.switchToPopUp();
	 container.waitForElement(160, container.getDownloadFileSegmentsExportxpath(), "xpath");
	 DownloadFileSegmentsExport = container.getDownloadFileSegmentsExport();
	 DownloadFileSegmentsExport.click();
	 
  Thread.sleep(1000L);
   //create robot object
   Robot robot = new Robot();
   Thread.sleep(1000L);
   //Click Down Arrow Key to select "Save File" Radio Button
   robot.keyPress(KeyEvent.VK_DOWN);
   Thread.sleep(1000L);
   // Click 3 times Tab to take focus on "OK" Button
   robot.keyPress(KeyEvent.VK_TAB);
   Thread.sleep(1000L);
   robot.keyPress(KeyEvent.VK_TAB);
   Thread.sleep(1000L);
   robot.keyPress(KeyEvent.VK_TAB);
   Thread.sleep(1000L);
   //Click "Enter" Button to download file
   robot.keyPress(KeyEvent.VK_ENTER);
   Thread.sleep(5000L);
   System.out.println("Robot work Complete");
}


public void clickSegmentsCancel() throws IOException, InterruptedException
{	
	
 Thread.sleep(5000);
 CommonFunctions.switchToPopUp();
 //CommonFunctions.maximizeBrowser();
 container.waitForElement(120, container.getSegmentsCancelxpath(),"xpath");
 SegmentsCancel= container.getSegmentsCancel();
 SegmentsCancel.click();
 
}


public void clickRegionsLink() throws IOException, InterruptedException{
	Thread.sleep(5000);
	CommonFunctions.switchToPopUp();
	container.waitForElement(40, container.getRegionsLinkxpath(), "xpath");
	RegionsLink = container.getRegionsLink();
	RegionsLink.click();
}

public void clickRegions_ExportButton() throws IOException, InterruptedException{
	Thread.sleep(5000);
	CommonFunctions.switchToPopUp();
	 container.waitForElement(40, container.getRegions_ExportButtonxpath(), "xpath");
	 Regions_ExportButton = container.getRegions_ExportButton();
	 Regions_ExportButton.click();
}

public void clickDownloadFileRegionsExport() throws IOException, InterruptedException, AWTException{
	Thread.sleep(5000);
	 CommonFunctions.switchToPopUp();
	 container.waitForElement(160, container.getDownloadFileRegionsExportxpath(), "xpath");
	 DownloadFileRegionsExport = container.getDownloadFileRegionsExport();
	 DownloadFileRegionsExport.click();
	 
  Thread.sleep(1000L);
   //create robot object
   Robot robot = new Robot();
   Thread.sleep(1000L);
   //Click Down Arrow Key to select "Save File" Radio Button
   robot.keyPress(KeyEvent.VK_DOWN);
   Thread.sleep(1000L);
   // Click 3 times Tab to take focus on "OK" Button
   robot.keyPress(KeyEvent.VK_TAB);
   Thread.sleep(1000L);
   robot.keyPress(KeyEvent.VK_TAB);
   Thread.sleep(1000L);
   robot.keyPress(KeyEvent.VK_TAB);
   Thread.sleep(1000L);
   //Click "Enter" Button to download file
   robot.keyPress(KeyEvent.VK_ENTER);
   Thread.sleep(5000L);
   System.out.println("Robot work Complete");
}

public void clickManagerRoles() throws IOException, InterruptedException, AWTException{
	CommonFunctions.switchToPopUp();
	container.waitForElement(10, container.getManagerRolesxpath(),"xpath");
	ManagerRoles = container.getManagerRoles();
	ManagerRoles.click();
}

public void clickManagerRoles_Export() throws IOException, InterruptedException, AWTException{
	
	CommonFunctions.switchToPopUp();
	container.waitForElement(10, container.getManagerRoles_Exportxpath(), "xpath");
	ManagerRoles_Export = container.getManagerRoles_Export();
	ManagerRoles_Export.click();
} 

public void clickDownloadFileManagerRolesExport() throws IOException, InterruptedException, AWTException{
	Thread.sleep(5000);
	CommonFunctions.switchToPopUp();
	container.waitForElement(160,container.getDownloadFileManagerRolesExportxpath(),"xpath");
	DownloadFileManagerRolesExport = container.getDownloadFileManagerRolesExport();
	DownloadFileManagerRolesExport.click();
	
	  Thread.sleep(1000L);
	   //create robot object
	   Robot robot = new Robot();
	   Thread.sleep(1000L);
	   //Click Down Arrow Key to select "Save File" Radio Button
	   robot.keyPress(KeyEvent.VK_DOWN);
	   Thread.sleep(1000L);
	   // Click 3 times Tab to take focus on "OK" Button
	   robot.keyPress(KeyEvent.VK_TAB);
	   Thread.sleep(1000L);
	   robot.keyPress(KeyEvent.VK_TAB);
	   Thread.sleep(1000L);
	   robot.keyPress(KeyEvent.VK_TAB);
	   Thread.sleep(1000L);
	   //Click "Enter" Button to download file
	   robot.keyPress(KeyEvent.VK_ENTER);
	   Thread.sleep(5000L);
	   System.out.println("Robot work Complete");
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void clickgetlevel_A_ManagerRoles() throws IOException, InterruptedException{
	 Thread.sleep(5000);
	 CommonFunctions.switchToPopUp();
	 container.waitForElement(40, container.getlevel_A_ManagerRolesxpath(), "xpath");
	 level_A = container.getlevel_A_ManagerRoles();
	 level_A.click();
}

public void clickgetlevel_B_ManagerRoles() throws IOException, InterruptedException{
	 Thread.sleep(5000);
	 CommonFunctions.switchToPopUp();
	 container.waitForElement(40, container.getlevel_B_ManagerRolesxpath(), "xpath");
	 level_B = container.getlevel_B_ManagerRoles();
	 level_B.click();
}


public void clickgetlevel_C_ManagerRoles() throws IOException, InterruptedException{
	 Thread.sleep(5000);
	 CommonFunctions.switchToPopUp();
	 container.waitForElement(40, container.getlevel_C_ManagerRolesxpath(), "xpath");
	 level_C = container.getlevel_C_ManagerRoles();
	 level_C.click();
}


public void clickgetlevel_D_ManagerRoles() throws IOException, InterruptedException{
	 Thread.sleep(5000);
	 CommonFunctions.switchToPopUp();
	 container.waitForElement(40, container.getlevel_D_ManagerRolesxpath(), "xpath");
	 level_D = container.getlevel_D_ManagerRoles();
	 level_D.click();
}


public void clickgetlevel_E_ManagerRoles() throws IOException, InterruptedException{
	 Thread.sleep(5000);
	 CommonFunctions.switchToPopUp();
	 container.waitForElement(40, container.getlevel_E_ManagerRolesxpath(), "xpath");
	 level_E = container.getlevel_E_ManagerRoles();
	 level_E.click();
}


public void clickgetlevel_F_ManagerRoles() throws IOException, InterruptedException{
	 Thread.sleep(5000);
	 CommonFunctions.switchToPopUp();
	 container.waitForElement(40, container.getlevel_F_ManagerRolesxpath(), "xpath");
	 level_F = container.getlevel_F_ManagerRoles();
	 level_F.click();
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
public void getManagerRolesCriteria(String MR_RoleLongName, String MR_RoleShortName, String MR_Comment){
	ArrayList <String> SVInfo = new ArrayList<String>(); 
	SVInfo.add(MR_RoleLongName);
	SVInfo.add(MR_RoleShortName);
	SVInfo.add(MR_Comment);
	

	
	
	
	for(int i=0; i<SVInfo.size(); i++)
	{
		if(SVInfo.get(i).equals(null))
		{
			System.out.format("SV Info element is empty", SVInfo.get(i));
			
		}
		System.out.println(SVInfo.get(i));
	}
	
	
	this.SVMR_RoleLongName = SVInfo.get(0);
	this.SVMR_RoleShortName = SVInfo.get(1);
	this.SVMR_Comment = SVInfo.get(2);
	

	
 }
 
public void fillSearchCriteriaManagerRoles() throws IOException, InterruptedException{
 
 CommonFunctions.switchToPopUp();
 container.waitForElement(40,container.getMR_RoleLongNamexpath(), "xpath");
 MR_RoleLongName = container.getMR_RoleLongName();
 MR_RoleLongName.click();
 MR_RoleLongName.clear();
 MR_RoleShortName = container.getMR_RoleShortName();
 MR_RoleShortName.clear();
 MR_Comment = container.getMR_Comment();
 

 MR_RoleLongName.sendKeys(SVMR_RoleLongName);
 MR_RoleShortName.sendKeys(SVMR_RoleShortName);
 MR_Comment.sendKeys(SVMR_Comment);
 
 		 
 }


public void ClickToSave_CommentMR() throws IOException, InterruptedException{
	 CommonFunctions.switchToPopUp();
	 container.waitForElement(40, container.getSave_CommentMRxpath(), "xpath");
	 Save_CommentMR = container.getSave_CommentMR();
	 Save_CommentMR.click();
}

public void confirmNASPIDDeleted() throws IOException
{
	container.waitForElement(10, container.getNASPIDDeletedConfirmationLabel_css(), "cssSelector");
}

public void exportPopUp() throws IOException
{
	container.waitForElement(10, container.getNASPIDExportPopUp_xpath(), "xpath");
}

public void clickOnSegmentExport() throws IOException
{
	container.waitForElement(10, container.getSegmentExportButton_xpath(), "xpath");
	SegmentExportButton=container.getSegmentExportButton();
	SegmentExportButton.click();
}

public void  SegmentExportPopUp() throws IOException
{
	CommonFunctions.switchToPopUp();
	container.waitForElement(10, container.getSegmentExportPopUp_xpath(), "xpath");
}

public void  RegionExportPopUp() throws IOException
{
	container.waitForElement(10, container.getRegionExportPopUp_xpath(), "xpath");
}

public void  ManageRolesExportPopUp() throws IOException
{
	container.waitForElement(10, container.getManageRolesExportPopUp_xpath(), "xpath");
}

public void clickOnAccountSearchLink() throws IOException
{
	container.waitForElement(10, container.getAccountSearchLink_xpath(), "xpath");
	AccountSearchLink=container.getAccountSearchLink();
	AccountSearchLink.click();
}

public void lookForAccountValue(String value) throws IOException
{
	container.waitForElement(10, container.getAccountSearchTextBox_xpath(), "xpath");
	AccountSearchTextBox=container.getAccountSearchTextBox();
	AccountSearchTextBox.sendKeys(value);

}

public void clickOnSearchButton()
{
	AccountSearchButtonSearch=container.getAccountSearch_SearchButton();
	AccountSearchButtonSearch.click();
}
public void getAccountSearchResults() throws IOException
{
	container.waitForElement(15, container.getAccountSearchAccountFound_xpath(), "xpath");
}


}
