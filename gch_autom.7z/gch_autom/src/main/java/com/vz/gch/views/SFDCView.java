package com.vz.gch.views;

import com.vz.gch.containers.ContainerEnvironment;
import com.vz.gch.containers.NASPToolContainer;
import com.vz.gch.containers.SFDCContainer;


import java.util.ArrayList;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class SFDCView
{
	private SFDCContainer container;
	private WebDriver driver;
	private final long globalTimeout = 35;
	//private String linkWithTextTemplate = "%s";
	
	public SFDCView(WebDriver driver)
	{
		this.driver = driver;
		container = new SFDCContainer(driver);
	}
	
	public void logInSFDC(String username, String password)
	{
		container.resetImplicitTimeWait();
		container.goToSFDCPage();
		
		container.getUsernameInputField().sendKeys(username);
		container.getPasswordInputField().sendKeys(password);
		container.getLogInButton().click();
		driver.switchTo().alert().accept();
	}
	
	
	
	public void searchAccount(String account)
	{
		container.getSearchField().sendKeys(account);
		container.getSearchButton().click();
	}
	
	public boolean checkForLinkWithText(String accountNumber)
	{
		//String formattedLink = String.format(linkWithTextTemplate, accountNumber);
		WebElement link = container.getLinkWithText(accountNumber);
		
		
		boolean isLinkAvailable = ( link.isDisplayed() && link.isEnabled() ) ? true : false ;
		
		return isLinkAvailable;
	}
	
	public void clickOnLinkWithText(String accountNumber) {
		
		//String formattedLink = String.format(linkWithTextTemplate, accountNumber);
		WebElement link = container.getLinkWithText(accountNumber);
		
		link.click();
	}
	
	public void clickOnNewNaspIDRequestButton() {
		
		container.getNewNaspIDRequestButton().click();
	}
	
	public void clickOKRedirectionNewNaspIDRequestButton() {
		
		driver.switchTo().alert().accept();
	}
	
	public void punchOutGCHPage() {
		
		ArrayList<String> newTab = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(newTab.get(1));
		driver.switchTo().alert().dismiss();
		
	}
	
	

	public void logInSFDC2(String username, String password)
	{
		
		
		
		container.getUsernameInputField2().sendKeys(username);
		container.getPasswordInputField2().sendKeys(password);
		container.getLogInButton2().click();
		driver.switchTo().alert().accept();
	}
	
	public void sfdcenter_nasptype(String Type) throws Exception {

		(new WebDriverWait(driver, globalTimeout)).until(ExpectedConditions.elementToBeClickable(By.xpath("//div[3]/div/div/div[2]")));
        container.getsfdcenternastype().click();
	    container.getsfdcenternastype_select().click();
		
		//driver.findElement(By.cssSelector("a[class='x-component x-border-box x-mask x-component-default']")).click();	
	}
	
	
	public void sfdcenter_revloctype(String Type) throws Exception{
	
		container.getsfdcenterrevloc().click();
	    (new WebDriverWait(driver, globalTimeout)).until(ExpectedConditions.elementToBeClickable(By.xpath("//div[7]/div/ul/li[2]")));
		container.getsfdcenterrevloc_select().click();
		
	}
	

	
	public void sfdccontactfirstname(String firstname) throws Exception{
		container.getsfdccontactfirstname().sendKeys(firstname);
	}
	
	public void sfdccontactlastname(String lastname) throws Exception{
		container.getsfdccontactlastname().sendKeys(lastname);
		
	}
	
	public void sfdcsubmit_nasprequestid(){
		container.getsfdcsubmit_nasprequestid().click();
	}
	
	public  void sfdcnasprequestidok(){
		container.getsfdcconfirmationok().click();
	}
	
	
}
