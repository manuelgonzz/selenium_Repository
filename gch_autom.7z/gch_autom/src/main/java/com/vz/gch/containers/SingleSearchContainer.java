package com.vz.gch.containers;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.vz.gch.views.CommonFunctions;

public class SingleSearchContainer {

	private WebDriver driver;
	
	public SingleSearchContainer(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public void waitForElement(Integer timeout, String ElementString, String Type) throws IOException{
		CommonFunctions.isElementPresent(driver, timeout, ElementString, Type);
	}
	
	public WebElement getSSSearchBar()
	{
		return driver.findElement(By.xpath("//div[2]/input"));
	}
	
	public WebElement getSSSearchButton()
	{
		return driver.findElement(By.id("performSearchButton"));
	}
	
	public WebElement getSSBICFound()
	{
		return driver.findElement(By.xpath("//p/a/span"));
	}
	
	public WebElement getSSLEIDLink()
	{
		return driver.findElement(By.xpath("//p/a/span"));
	}
	
	public WebElement getSSViewCLEProfileOption()
	{
		return driver.findElement(By.xpath("//li[2]/a/span"));
	}
	
	public WebElement getSSCLEPopupScreen()
	{
		return driver.findElement(By.xpath("//td/span"));
	}
	
	public WebElement getSSViewInVECRMOption()
	{
		return driver.findElement(By.xpath("//li[3]/a/span"));
	}
	
	public WebElement getSSVECRMScreen()
	{
		return driver.findElement(By.id("loadingWithTrasn"));
	}
	
	public WebElement getSSViewInventorySMDOption()
	{
		return driver.findElement(By.xpath("//li[5]/a/span"));
	}
	
	public WebElement getSSViewInventorySMDScreen()
	{
		return driver.findElement(By.xpath("//li[7]/a/span"));
	}
	
	public WebElement getSSViewAlarmsInSMDOption()
	{
		return driver.findElement(By.xpath("//li[6]/a/span"));
	}
	
	public WebElement getSSViewAlarmsInSMDScreen()
	{
		return driver.findElement(By.xpath("//div[2]/span"));
	}
	
	public WebElement getSSViewTopologyInSMDOption()
	{
		return driver.findElement(By.xpath("//li[7]/a/span"));
	}
	
	public WebElement getSSServiceMgmtReportingOption()
	{
		return driver.findElement(By.xpath("//li[8]/a/span"));
	}
	
	public WebElement getSSProfilesLinkView()
	{
		return driver.findElement(By.xpath("//li[2]/a/span"));
	}
	
	public WebElement getSSBillingAccountLinkView()
	{
		return driver.findElement(By.linkText("Billing Accounts"));
	}
	
	public WebElement getSSCustomerNotFoundToaster()
	{
		return driver.findElement(By.xpath("//div[2]/p"));
	}
	
	public WebElement getSSVECRMPolicyAcceptButton()
	{
		return driver.findElement(By.cssSelector("button.acceptBtn"));
	}
	
	
	
	public String getSSSearchBar_xpath()
	{
		return "//div[2]/input";
	}
	
	public String getSSSearchButton_id()
	{
		return "performSearchButton";
	}
	
	public String getSSBICFound_xpath()
	{
		return "//p/a/span";
	}
	
	public String getSSLEIDLink_xpath()
	{
		return "//p/a/span";
	}
	
	public String getSSViewCLEProfileOption_xpath()
	{
		return "//li[2]/a/span";
	}
	
	public String getSSCLEPopupScreen_xpath()
	{
		return "//td/span";
	}
	
	public String getSSViewInVECRMOption_xpath()
	{
		return "//li[3]/a/span";
	}
	
	public String getSSVECRMScreen_ID()
	{
		return "loadingWithTrasn";
	}
	
	public String getSSViewInventorySMDOption_xpath()
	{
		return "//li[5]/a/span";
	}
	
	public String getSSViewInventorySMDScreen_xpath()
	{
		return "//li[7]/a/span";
	}
	
	public String getSSViewAlarmsInSMDOption_xpath()
	{
		return "//li[6]/a/span";
	}
	
	public String getSSViewAlarmsInSMDScreen_xpath()
	{
		return "//div[2]/span";
	}
	
	public String getSSViewTopologyInSMDOption_xpath()
	{
		return "//li[7]/a/span";
	}
	
	public String getSSViewTopologyInSMDScreen_xpath()
	{
		return "//li[7]/a/span";
	}
	
	public String getSSServiceMgmtReportingScreen_xpath()
	{
		return "//img";
	}
	
	public String getSSServiceMgmtReportingOption_xpath()
	{
		return "//li[8]/a/span";
	}
	
	public String getSSProfilesLinkView_xpath()
	{
		return "//li[2]/a/span";
	}
	
	public String getSSProfilesLinkViewScreen_xpath()
	{
		return "//strong";
	}
	
	public String getSSBillingAccountLinkView_link()
	{
		return "Billing Accounts";
	}
	
	public String getSSBillingAccountLinkViewScreen_xpath()
	{
		return "//span[6]/span[2]";
	}
	
	public String getSSCustomerNotFoundToaster_xpath()
	{
		return "//div[2]/p";
	}
	
	public String getSSVECRMPolicyAcceptButton_css()
	{
		return "button.acceptBtn";
	}
}
