package com.vz.gch.views;

import java.awt.AWTException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.vz.gch.containers.LegalEntityContainer;



public class LegalEntity{
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
												//Legal Entity Objects//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	private LegalEntityContainer container;
	private CommonFunctions common;
	private WebElement UserName;
	private WebElement PassWord;
	private WebElement Sign_On;
	private WebElement CreateCLELink;
	private WebElement CLECreateButton;
	private WebElement CLENameTextBox;
	private WebElement CLEA1TextBox;
	private WebElement CLEA2TextBox;
	private WebElement CLEA3TextBox;
	private WebElement CLECityTextBox;
	private WebElement CLECountryDropDown;
	private WebElement CLEStateDropDown;
	private WebElement CLEZipCodeTextBox;
	private WebElement CLEPhoneTextBox;
	private WebElement CLEConfirmAddressButton;
	private WebElement CLEisCreatedButton;
	private WebElement CustomerHierarchyOption;
	private WebElement ManageBillingAccountsOption;
	private WebElement MBACLESearchButton;
	private WebElement MBACLESearchLink;
	private Boolean MBACGIRenameExistance;
	private WebElement MBACGIRenameTextBox;
	private List <WebElement> MBARenameLinks;
	private WebElement MBACGIRename;
	private WebElement MBACGIRenameSubmitButton;
	private WebElement MBACLENameTextBox;
	private WebElement MBACGIDelete;
	private WebElement MBACGIDeleteSubmitButton;
	private Boolean MBACGIDeleteExistance;
	private WebElement MBACreateCGIButton;
	private WebElement MBACreateCGITextBox;
	private WebElement MBACreateCGISubmitButton;
	private WebElement ManageAccountNumbersTab;
	private WebElement AccountSearchGoButton;
	private WebElement AccountObjectDropDown;
	private WebElement AccountDescriptionTextBox;
	private WebElement AccountStatusDropDown;
	private WebElement CGISearchTypeDropDown;
	private WebElement CGISearchTextBox;
	private WebElement CGISearchGoButton;
	private WebElement CGIActionButton;
	private WebElement CGIChangeCGIOption;
	private WebElement CGIRadioButton;
	private WebElement CGIChangeCGIConfirmationTextLabel;
	private WebElement CGISearchResultLabel;
	private WebElement CGIUpdateCustomerLegalName;
	private WebElement CGIUpdateCustomerLegalEntityNameTextBox;
	private WebElement CGIUpdateCustomerLegalEntityNameCPEOption;
	private WebElement CGIUpdateCustomerLegalEntityNameSubmitButton;
	private WebElement CGIUpdateCustomerLegalNameConfirmationButton;
	private WebElement CGIUpdateCustomerLegalAddressOption;
	private WebElement CGIUpdateCustomerLegalAddressLine1;
	private WebElement CGIUpdateCustomerLegalAddressLine2;
	private WebElement CGIUpdateCustomerLegalAddressLine3;
	private WebElement CGIUpdateCustomerLegalAddressCity;
	private WebElement CGIUpdateCustomerLegalAddressState;
	private WebElement CGIUpdateCustomerLegalAddressZipCode;
	private WebElement CGIUpdateCustomerLegalAddressSubmitButton;
	private WebElement CGIUpdateCustomerLegalAddressConfirmAddressButton;
	private WebElement CGIUpdateCustomerLegalAddressIDAddressRequest;
	private WebElement CLEUpdateCustomerLegalAddressSubmitButton;
	private WebElement ManageServiceLocationsTab;
	private WebElement ManageServiceLocationsActionButton;
	private WebElement AddUpdatePurchaseOrder;
	private WebElement CloseAddUpdatePurchaseOrderButton;
	private WebElement CLESearchBar;
	private WebElement CLESearchButton;
	private WebElement CLELittleArrow;
	private WebElement ViewProfileOption;
	private WebElement CustomerContactTab;
	private WebElement CPNICreateButton;
	private WebElement CPNIFirstName;
	private WebElement CPNILastName;
	private WebElement CPNIRole;
	private WebElement CPNITitle;
	private WebElement CPNIEmail;
	private WebElement CPNIAddress1;
	private WebElement CPNIAddress2;
	private WebElement CPNIAddress3;
	private WebElement CPNICity;
	private WebElement CPNICountry;
	private WebElement CPNIState;
	private WebElement CPNIZipCode;
	private WebElement CPNIWorkPhone;
	private WebElement CPNISubmitCreateButton;
	private WebElement CPNIAddressConfirmButton;
	private WebElement CPNISaveChangesButton;
	private WebElement CLERequestLegalNameChangeOption;
	private WebElement CLERequestLegalAddressChangeOption;
	private WebElement CLERequestInquiryOption;
	private WebElement CLERequestInquiryCommentsTextBox;
	private WebElement CLERequestInquirySendButton;
	private WebElement CLEEntityInformationTab;
	private WebElement CLEUpdateBasicInformationButton;
	private WebElement LegalEntityStatusDropDown;
	private WebElement MainPhoneNumberTextBox;
	private WebElement UpdateCLEBasicInfoSubmitButton;
	private WebElement UpdateCLEBasicInfoOperationSuccesfullButton;
	private WebElement UpdateDUNSIcon;
	private WebElement UpdateDUNSLookupTextBox;
	private WebElement UpdateDUNSContinueButton;
	private WebElement UpdateDUNSSaveChangesButton;
	private WebElement UpdateDUNSConfirmOperation;
	private WebElement CreateAliasLabelButton;
	private WebElement AliasLabelTextBox;
	private WebElement AliasLabelType;
	private WebElement CreateAliasSaveChanges;
	private WebElement CreateAliasOperationSuccessfullLabel;
	private WebElement CreateAliasErrorLabel;
	
	
	private String CLEName;
	private String CLEA1;
	private String CLEA2;
	private String CLEA3;
	private String CLECity;
	private String CLECountry;
	private String CLEState;
	private String CLEZipCode;
	private String CLEPhone;
	private String OldCGIName;
	private String NewCGIName;
	private String MBACLE;
	public static String parentWindow;
	public String OldCGINamePosition;
	private ArrayList<String> CustomGlobalName = new ArrayList<String>();
	private String MBAdeleteCGI;
	private String MBAdeleteCLE;
	private String MBAdeleteCGIPosition;
	private String MBACreateCGI;
	private String MBACreateCLE;
	private String FindAccountNumberCLE;
	private String Account_ObjectSearch;
	private String Account_ObjectDescript;
	private String Account_Status;
	private String CGIDescript;
	private String CustomerLegalName;
	private String SaveUserName;
	private String SavePassword;
	public static String SSOWINDOW;
	
	
	public LegalEntity(WebDriver driver) {
		container = new LegalEntityContainer(driver);
		common = new CommonFunctions(driver);
		
	}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
											//LOGIN INTO GCH PORTAL//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	
	public void LogIn(String username, String password) throws IOException, InterruptedException, AWTException
	{	
		
		
		SaveUserName=username;
		SavePassword=password;
		container.getUrl();
		
		WebDriverWait wait = new WebDriverWait(container.driver,10);
		Alert alert = wait.until(ExpectedConditions.alertIsPresent());
		
		alert.dismiss();

		container.waitForElement(10, container.getSign_OnButton_xpath(), "xpath");
		SSOWINDOW=container.getWindowHandle();
		
		UserName=container.getUserName();
		PassWord=container.getPassWord();
		
		Sign_On=container.getSign_OnButton();
		container.waitForElement(900000000, "USERID", "ByName");	
		
		UserName.sendKeys(username);
		PassWord.sendKeys(password);
		Sign_On.click();
		
	}
	
	public void ReLogin() throws IOException
	{
		CommonFunctions.switchToPopUp();
		container.waitForElement(10, container.getUserName_ID(), "ById");
		UserName=container.getUserName();
		PassWord=container.getPassWord();
		UserName.sendKeys(SaveUserName);
		PassWord.sendKeys(SavePassword);
		Sign_On=container.getSign_OnButton();
		Sign_On.click();
	}
	
	public void authenticate(){
		
		CommonFunctions.acceptNextAlert=true;
		Assert.assertEquals("NOTICE - PROPRIETARY SYSTEM - This system is intended to be used solely by authorized users in the course of legitimate corporate business.  Users are monitored to the extent necessary to properly administer the system, to identify unauthorized users or users operating beyond their proper authority and to investigate improper access or use.  By accessing this system, you are consenting to this monitoring.", CommonFunctions.closeAlertAndGetItsText());
	}
	
	public void ViewGchPortal() throws IOException
	{
		common.isAlertPresent();
		container.waitForElement(50, "generalForm:searchInputText", "ById");
	}
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
												//CREATE CLE PROCESS//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	public void receiveCustomerNameAddress(String Name, String A1, String A2, String A3, String City, String Country, String State, String ZipCode, String Phone)
	{
		ArrayList <String> CLEInfo = new ArrayList<String>(); 
		CLEInfo.add(Name);
		CLEInfo.add(A1);
		CLEInfo.add(A2);
		CLEInfo.add(A3);
		CLEInfo.add(City);
		CLEInfo.add(Country);
		CLEInfo.add(State);
		CLEInfo.add(ZipCode);
		CLEInfo.add(Phone);
		
		for(int i=0; i<CLEInfo.size(); i++)
		{
			if(CLEInfo.get(i).equals(null))
			{
				System.out.format("CLE Info element is empty", CLEInfo.get(i));
				
			}
			System.out.println(CLEInfo.get(i));
		}
		
		this.CLEName=CLEInfo.get(0);
		this.CLEA1=CLEInfo.get(1);
		this.CLEA2=CLEInfo.get(2);
		this.CLEA3=CLEInfo.get(3);
		this.CLECity=CLEInfo.get(4);
		this.CLECountry=CLEInfo.get(5);
		this.CLEState=CLEInfo.get(6);
		this.CLEZipCode=CLEInfo.get(7);
		this.CLEPhone=CLEInfo.get(8);
		
	
	}
	
	
	
	public void clickCreateCLE() throws IOException
	{	
		CreateCLELink=container.getCreateCLElink();
		String CCLELink=CreateCLELink.getText();
		container.waitForElement(30,CommonFunctions.ConcatenateXpath(CCLELink),"xpath");
		CreateCLELink.click();
	}
	
	public void CustomerInformationFill() throws IOException
	{
		
	    
		CommonFunctions.switchToPopUp();
		container.waitForElement(10, container.getCLECountryDropDown_xpath(), "xpath");
		CLECountryDropDown=container.getCLECountryDropDown();
		new Select(CLECountryDropDown).selectByVisibleText(CLECountry);
		container.waitForElement(10, container.getCLEStateDropDown_xpath(), "xpath");
		CLEStateDropDown=container.getCLEStateDropDown();
	    new Select(CLEStateDropDown).selectByVisibleText(CLEState);
	    
	    CLENameTextBox=container.getCLENameTextBox();
	    CLEA1TextBox=container.getCLEA1TextBox();
	    CLECityTextBox=container.getCLECityTextBox();
	    CLEZipCodeTextBox=container.getCLEZipCodeTextBox();
	    CLEPhoneTextBox=container.getCLEPhoneTextBox();
	    
	    CLENameTextBox.sendKeys(CLEName);
	    CLEA1TextBox.sendKeys(CLEA1);
	    CLECityTextBox.sendKeys(CLECity);
	    CLEZipCodeTextBox.sendKeys(CLEZipCode);
	    CLEPhoneTextBox.sendKeys(CLEPhone);
		
	}
	
	public void CreateButtonClick() throws InterruptedException
	{	
		CLECreateButton=container.getCLECreateButton();
		CLECreateButton.click();
	}
	
	public void confirmAddressFormat() throws IOException, InterruptedException
	{
		CommonFunctions.switchToPopUp();
		Thread.sleep(2000);
		container.waitForElement(20, container.getCLEConfirmAddressButton_xpath(), "xpath"); 
		CLEConfirmAddressButton=container.getCLEConfirmAddressButton();
		CLEConfirmAddressButton.click();
	    CommonFunctions.switchToPopUp();
	}
	
	public void newCleCreated() throws IOException 
	{	
		container.waitForElement(10, container.getCLEisCreatedButton_xpath(), "xpath");
		CLEisCreatedButton=container.getCLEisCreatedButton();
		CLEisCreatedButton.click();
	}
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
											//MANAGE BILLING ACCOUNTS MODULE//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	

													//RENAME CGI//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	
	public void receiveOldNewCGICLE(String OldCGIName, String NewCGIName, String CLE)
	{
		this.OldCGIName=OldCGIName;
		this.NewCGIName=NewCGIName;
		this.MBACLE=CLE;
	}
	
	public void searchForManageBillingAccounts() throws IOException
	{
		container.waitForElement(10, container.getCustomerHierarchyDropDown_xpath(), "cssSelector");
		CustomerHierarchyOption=container.getCustomerHierarchyDropDown();
		ManageBillingAccountsOption=container.getManageBillingAccountOption();
		container.action.moveToElement(CustomerHierarchyOption).moveToElement(ManageBillingAccountsOption).click().build().perform();
		
	}
	
	public void MBACustomerLegalEntitySearch() throws InterruptedException, IOException
	{
		Thread.sleep(2000);
		container.waitForElement(10, container.getMBACLENameTextBox_xpath(), "xpath");
		MBACLENameTextBox=container.getMBACLENameTextBox();
		MBACLENameTextBox.sendKeys(MBACLE);
		parentWindow=container.getWindowHandle();
		MBACLESearchButton=container.getMBACLESearchButton();
		MBACLESearchButton.click();
		Thread.sleep(1000);
		CommonFunctions.switchToPopUp();
		container.waitForElement(20, container.getMBACLESearchLink_xpath(), "xpath");
	
	}
	
	public void MBAselectValidCLE() throws InterruptedException
	{
		MBACLESearchLink=container.getMBACLESearchLink();
		MBACLESearchLink.click();
		CommonFunctions.switchToWindow(parentWindow);
	}
	
	public void checkMBATabforCLE() throws IOException
	{
		CustomGlobalName=CommonFunctions.getMBAcustomerGNames();
	}
	
	public void lookForCGIToRename()
	{
		OldCGINamePosition=CommonFunctions.getCGIfromGroup(OldCGIName, CustomGlobalName);
	}
	
	public void renamingCustomerGroupId() throws IOException
	{
		MBACGIRename=container.getMBACGIRename(OldCGINamePosition);
		MBACGIRenameExistance=container.getMBACGIRenameExistance(OldCGINamePosition);
		
	
		if(MBACGIRenameExistance)
		{
			MBACGIRename.click();
		
			container.waitForElement(10, container.getMBACGIRenameTextBox_xpath(OldCGINamePosition), "xpath");
			MBACGIRenameTextBox=container.getMBACGIRenameTextBox(OldCGINamePosition);
			MBACGIRenameTextBox.clear();
			MBACGIRenameTextBox.sendKeys(NewCGIName);
		}
		else{
			Assert.assertTrue("Customer Group not found",false);
		}
	}
	
	public void confirmCGIUpdated() throws IOException
	{	common.oldCGINamePos=OldCGINamePosition;
		container.waitForElement(10, container.getMBACGIRenameSubmitbutton_xpath(OldCGINamePosition),"xpath");
		MBACGIRenameSubmitButton=container.getMBACGIRenameSubmitbutton(OldCGINamePosition);
		MBACGIRenameSubmitButton.click();
		
		container.waitForElement(10, container.getMBACGIConfirmationMessage_css(), "cssSelector");
	}

													//DELETE CGI//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	

	public void receiveDeleteCGIandCLE(String CGI, String CLE)
	{
		this.MBAdeleteCGI=MBACreateCGI=CGI;
		this.MBAdeleteCLE=MBACreateCLE=MBACLE=CLE;
	}
	
	public void lookForCGIToDelete()
	{
		MBAdeleteCGIPosition=CommonFunctions.getCGIfromGroup(MBAdeleteCGI, CustomGlobalName);
	}
	
	public void deletingCustomerGroupId() throws IOException
	{
		MBACGIDelete=container.getMBACGIDelete(MBAdeleteCGIPosition);
		MBACGIDeleteExistance=container.getMBACGIDeleteExistance(MBAdeleteCGIPosition);
		
	
		if(MBACGIDeleteExistance)
		{
			MBACGIDelete.click();
		
			CommonFunctions.switchToPopUp();
		}
		else{
			Assert.assertTrue("Customer Group not found",false);
		}
	}
	
	
	public void confirmCGIDeleted() throws IOException
	{
		
		container.waitForElement(10, container.getMBACGIDeleteSubmitButton_xpath(), "xpath");
		MBACGIDeleteSubmitButton=container.getMBACGIDeleteSubmitButton();
		MBACGIDeleteSubmitButton.click();
		
		container.waitForElement(10, container.getMBACGIDeleteConfirmation_css(), "cssSelector");
	}
	
													//CREATE CGI//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	public void createCGIButtonPress() throws IOException
	{
		container.waitForElement(10, container.getMBACreateCGIButton_xpath(), "xpath");
		MBACreateCGIButton=container.getMBACreateCGIButton();
		MBACreateCGIButton.click();
	}
	
	public void writenewCGIName() throws IOException
	{
		container.waitForElement(10, container.getMBACreateCGITextBox_xpath(), "xpath");
		MBACreateCGITextBox=container.getMBACreateCGITextBox();
		MBACreateCGITextBox.sendKeys(MBACreateCGI);
	}
	
	public void confirmCGICreated() throws InterruptedException, IOException
	{
		MBACreateCGISubmitButton=container.getMBACreateCGISubmitButton();
		MBACreateCGISubmitButton.click();
		container.waitForElement(10, container.getCreateCGIResultLabelPassed_css(), "cssSelector");
		
		
	}
	
	//**********************************************//MANAGE ACCOUNT NUMBERS TAB//***************************************
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

														//FIND ACCOUNT/OBJECT//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public void receiveCLEFindAccountNumberObj(String CLE)
	{
		this.FindAccountNumberCLE=MBACLE=CLE;
	}
	
	public void clickOnManageAccountNumbersTab() throws IOException
	{
		container.waitForElement(20, container.getManageAccountNumbersTab_xpath(), "xpath");
		ManageAccountNumbersTab=container.getManageAccountNumbersTab();
		ManageAccountNumbersTab.click();
	}
	
	public void receiveAccount_Descript_Status(String AccountObject, String AccountDescript, String AccountStatus)
	{
		this.Account_ObjectSearch=AccountObject;
		this.Account_ObjectDescript=AccountDescript;
		this.Account_Status=AccountStatus;
	}
	
	public void lookForTheObjectDesired() throws IOException, InterruptedException
	{
		container.waitForElement(20, container.getCGIActionButton_xpath(), "xpath");
		Thread.sleep(2000);
		AccountObjectDropDown=container.getAccountObjectDropDown();
		new Select(AccountObjectDropDown).selectByVisibleText(Account_ObjectSearch);
		
		AccountDescriptionTextBox=container.getAccountDescriptionTextBox();
		AccountDescriptionTextBox.sendKeys(Account_ObjectDescript);
		
		AccountStatusDropDown=container.getAccountStatusDropDown();
		new Select(AccountStatusDropDown).selectByVisibleText(Account_Status);

	}
	
	public void accountSearchResults()
	{
		AccountSearchGoButton=container.getAccountSearchGoButton();
		AccountSearchGoButton.click();
	}
	
												//CHANGE CUSTOMER GROUP IDENTIFIER TO ACCOUNT//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void mapAccountToCGI(String CGIType, String CGIDesc) throws IOException, InterruptedException
	{
		Thread.sleep(1000);
		CommonFunctions.selectAccount(Account_ObjectDescript);
		CGISearchTypeDropDown=container.getCGISearchTypeDropDown();
		CGISearchTextBox=container.getCGISearchTextBox();
		CGISearchGoButton=container.getCGISearchGoButton();
		
		new Select(CGISearchTypeDropDown).selectByVisibleText(CGIType);
		CGISearchTextBox.sendKeys(CGIDesc);
		CGISearchGoButton.click();
		Thread.sleep(1000);
		CGIRadioButton=container.getCGIRadioButton();
		CGIRadioButton.click();
		
		CGIDescript=CGIDesc;
		
	}
	
	
	public void selectChangeCGIOption() throws IOException, InterruptedException
	{
		CGIActionButton=container.getCGIActionButton();
		CGIActionButton.click();
		container.waitForElement(30, container.getCGIchangeCGIOption_xpath(), "xpath");
		Thread.sleep(3000);
		CGIChangeCGIOption=container.getCGIchangeCGIOption();
		CGIChangeCGIOption.click();
		
	//	CGIChangeCGIConfirmationTextLabel=container.getCGIChangeCGIConfirmationTextLabel();
	//	CGISearchResultLabel=container.getCGISearchResultLabel();
		
		container.waitForElement(10, container.getCGIChangeCGIConfirmationTextLabelPassed_css(), "cssSelector");
		//Thread.sleep(3000);
		//String CGI_ID_Parenthesis=CGISearchResultLabel.getText().substring(CGISearchResultLabel.getText().indexOf("(")+1,CGISearchResultLabel.getText().indexOf(")"));
		//Assert.assertTrue(CGIChangeCGIConfirmationTextLabel.getText().equalsIgnoreCase("The Account Number(s) "+Account_ObjectDescript+" moved to "+CGIDescript+" ( "+CGI_ID_Parenthesis+" ) successfully."));
		
	}
	
													//UPDATE CUSTOMER LEGAL NAME//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void selectUpdateCustomerLegalName() throws InterruptedException, IOException
	{
		container.waitForElement(10, container.getCGIActionButton_xpath(), "xpath");
		CGIActionButton=container.getCGIActionButton();
		CGIActionButton.click();
		Thread.sleep(3000);
		CGIUpdateCustomerLegalName=container.getCGIUpdateCustomerLegalNameOption();
		CGIUpdateCustomerLegalName.click();
	}
	
	public void fillUpdateLegalNameInfo(String NewUpdateCLEName) throws IOException
	{
		CommonFunctions.switchToPopUp();
		container.waitForElement(10, container.getCGIUpdateCustomerLegalEntityNameTextBox_xpath(), "xpath");
		CGIUpdateCustomerLegalEntityNameTextBox=container.getCGIUpdateCustomerLegalEntityNameTextBox();
		//CGIUpdateCustomerLegalEntityNameCPEOption=container.getCGIUpdateCustomerLegalEntityNameCPEOption();
		CGIUpdateCustomerLegalEntityNameSubmitButton=container.getCGIUpdateCustomerLegalEntityNameSubmitButton();
		
		CGIUpdateCustomerLegalEntityNameTextBox.clear();
		CGIUpdateCustomerLegalEntityNameTextBox.sendKeys(NewUpdateCLEName);
		//new Select(CGIUpdateCustomerLegalEntityNameCPEOption).selectByVisibleText("Yes");
		CGIUpdateCustomerLegalEntityNameSubmitButton.click();
		
	}
	
	public void requestIDConfirmationUpdateLegalName() throws IOException
	{
		container.waitForElement(10, container.getCGIUpdateCustomerLegalNameConfirmationButton_xpath(),"xpath");
		CGIUpdateCustomerLegalNameConfirmationButton=container.getCGIUpdateCustomerLegalNameConfirmationButton();
		CGIUpdateCustomerLegalNameConfirmationButton.click();
	}
											//UPDATE CUSTOMER LEGAL ADDRESS//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void clickOnUpdateLegalAddressOption() throws InterruptedException, IOException
	{	container.waitForElement(10, container.getCGIActionButton_xpath(), "xpath");
		CGIActionButton=container.getCGIActionButton();
		CGIActionButton.click();
		Thread.sleep(3000);
		CGIUpdateCustomerLegalAddressOption=container.getCGIUpdateCustomerLegalAddressOption();
		CGIUpdateCustomerLegalAddressOption.click();
	}
	
	public void fillLegalAddressInformation(List<String> addressInfo) throws IOException
	{
		container.waitForElement(10,container.getCGIUpdateCustomerLegalAddressLine1_xpath(), "xpath");
		CGIUpdateCustomerLegalAddressLine1=container.getCGIUpdateCustomerLegalAddressLine1();
		CGIUpdateCustomerLegalAddressLine2=container.getCGIUpdateCustomerLegalAddressLine2();
		CGIUpdateCustomerLegalAddressLine3=container.getCGIUpdateCustomerLegalAddressLine3();
		CGIUpdateCustomerLegalAddressCity=container.getCGIUpdateCustomerLegalAddressCity();
		CGIUpdateCustomerLegalAddressState=container.getCGIUpdateCustomerLegalAddressState();
		CGIUpdateCustomerLegalAddressZipCode=container.getCGIUpdateCustomerLegalAddressZipCode();
		CGIUpdateCustomerLegalAddressSubmitButton=container.getCGIUpdateCustomerLegalAddressSubmitButton();
		
		CGIUpdateCustomerLegalAddressLine1.clear();
		CGIUpdateCustomerLegalAddressLine2.clear();
		CGIUpdateCustomerLegalAddressLine3.clear();
		CGIUpdateCustomerLegalAddressCity.clear();
		CGIUpdateCustomerLegalAddressZipCode.clear();
		CGIUpdateCustomerLegalAddressLine1.sendKeys(addressInfo.get(0));
		CGIUpdateCustomerLegalAddressLine2.sendKeys(addressInfo.get(1));
		CGIUpdateCustomerLegalAddressLine3.sendKeys(addressInfo.get(2));
		CGIUpdateCustomerLegalAddressCity.sendKeys(addressInfo.get(3));
		new Select(CGIUpdateCustomerLegalAddressState).selectByVisibleText(addressInfo.get(4));
		CGIUpdateCustomerLegalAddressZipCode.sendKeys(addressInfo.get(5));
		CGIUpdateCustomerLegalAddressSubmitButton.click();
	}
	
	public void confirmUpdateAddressFormat() throws IOException
	{
		container.waitForElement(10, container.getCGIUpdateCustomerLegalAddressConfirmAddressButton_xpath(), "xpath");
		CGIUpdateCustomerLegalAddressConfirmAddressButton=container.getCGIUpdateCustomerLegalAddressConfirmAddressButton();
		CGIUpdateCustomerLegalAddressConfirmAddressButton.click();
		
		container.waitForElement(10, container.getCGIUpdateCustomerLegalAddressIDAddressRequest_xpath(), "xpath");
		CGIUpdateCustomerLegalAddressIDAddressRequest=container.getCGIUpdateCustomerLegalAddressIDAddressRequest();
		CGIUpdateCustomerLegalAddressIDAddressRequest.click();
	}
	
	public void clickOnManageServicesLocationsTab() throws IOException
	{
		container.waitForElement(10, container.getManageService_LocationsTab_xpath(), "xpath");
		ManageServiceLocationsTab=container.getManageService_LocationsTab();
		ManageServiceLocationsTab.click();
	}
	
	public void clickOnActionButtonManageServicesLocations() throws IOException
	{
		container.waitForElement(10, container.getManageServicesLocationsActionButton_xpath(), "xpath");
		ManageServiceLocationsActionButton=container.getManageServicesLocationsActionButton();
		ManageServiceLocationsActionButton.click();
	}
	
	public void clickOnAddUpdatePurchaseOrder() throws IOException
	{
		container.waitForElement(10, container.getAddUpdatePurchaseOrderOption_xpath(), "xpath");
		AddUpdatePurchaseOrder=container.getAddUpdatePurchaseOrderOption();
		AddUpdatePurchaseOrder.click();
	}
	
	public void CloseGCMPopUp() throws IOException
	{
		CommonFunctions.switchToPopUp();
		container.waitForElement(10, container.getCloseAddUpdatePurchaseOrdenButton_xpath(), "xpath");
		CloseAddUpdatePurchaseOrderButton=container.getCloseAddUpdatePurchaseOrdenButton();
		CloseAddUpdatePurchaseOrderButton.click();
	}
	
												//CREATE CPNI USER//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	
	public void receiveCustomerLegalEntityForSearch(String CustomerLegalName)
	{
		this.CustomerLegalName=CustomerLegalName;
	}
	
	public void SearchOnCLEBar() throws IOException, InterruptedException
	{
		container.waitForElement(10, container.getCLESearchBar_xpath(), "xpath");
		CLESearchBar=container.getCLESearchBar();
		CLESearchBar.sendKeys(CustomerLegalName);
		CLESearchButton=container.getCLESearchBarButton();
		Thread.sleep(10000); //Wait for SOLR Scanners to display Created CLE
		CLESearchButton.click();
	}
	
	public void ClickOnCLELittleArrow() throws IOException
	{
		container.waitForElement(10, container.getCLEDropDownLittleArrow_xpath(), "xpath");
		CLELittleArrow=container.getCLEDropDownLittleArrow();
		CLELittleArrow.click();
	}
	
	public void SelectViewProfileFromDropDown() throws IOException
	{
		container.waitForElement(10, container.getCLEViewProfileOption_xpath(), "xpath");
		ViewProfileOption=container.getCLEViewProfileOption();
		ViewProfileOption.click();
	}
	
	public void ClickOnCustomerContactTab() throws IOException
	{
		container.waitForElement(10, container.getCustomerContactTab_xpath(), "xpath");
		CustomerContactTab=container.getCustomerContactTab();
		CustomerContactTab.click();
	}
	
	public void clickOnCreateCPNIButton() throws IOException, InterruptedException
	{
		Thread.sleep(2000);
		container.waitForElement(10, container.getCreateCPNIButton_xpath(), "xpath");
		CPNICreateButton=container.getCreateCPNIButton();
		CPNICreateButton.click();
	}
	
	public void fillCPNIInformation(List <String> CPNIInfo) throws IOException, InterruptedException
	{
		CommonFunctions.switchToPopUp();
		container.waitForElement(30, container.getCreateCPNIFirstNameTextBox_xpath(), "xpath");
		CPNIFirstName=container.getCreateCPNIFirstNameTextBox();
		CPNIFirstName.sendKeys(CPNIInfo.get(0));
		
		CPNILastName=container.getCreateCPNILastNameTextBox();
		CPNILastName.sendKeys(CPNIInfo.get(1));
		
		CPNIRole=container.getCreateCPNIRoleDropDown();
		CPNIRole.sendKeys(CPNIInfo.get(2));
		
		CPNITitle=container.getCreateCPNITitleTexBox();
		CPNITitle.sendKeys(CPNIInfo.get(3));
		
		CPNIEmail=container.getCreateCPNIEmailTexBox();
		CPNIEmail.sendKeys(CPNIInfo.get(4));
		
		CPNIAddress1=container.getCreateCPNIAddressL1TexBox();
		CPNIAddress1.sendKeys(CPNIInfo.get(5));
		
		CPNIAddress2=container.getCreateCPNIAddressL2TexBox();
		CPNIAddress2.sendKeys(CPNIInfo.get(6));
		
		CPNIAddress3=container.getCreateCPNIAddressL3TexBox();
		CPNIAddress3.sendKeys(CPNIInfo.get(7));
		
		CPNICity=container.getCreateCPNICityTexBox();
		CPNICity.sendKeys(CPNIInfo.get(8));
		
		CPNICountry=container.getCreateCPNICountryDropDown();
		new Select(CPNICountry).selectByVisibleText(CPNIInfo.get(9));
		
		Thread.sleep(2000);
		container.waitForElement(10, container.getCreateCPNIStateDropDown_xpath(),"xpath");
		CPNIState=container.getCreateCPNIStateDropDown();
		new Select(CPNIState).selectByVisibleText(CPNIInfo.get(10));
		
		CPNIZipCode=container.getCreateCPNIZipTextBox();
		CPNIZipCode.sendKeys(CPNIInfo.get(11));
		
		CPNIWorkPhone=container.getCreateCPNIWorkPhone();
		CPNIWorkPhone.sendKeys(CPNIInfo.get(12));

	}
	
	public void clickOnCreateCPNISubmitButton()
	{
		CPNISubmitCreateButton=container.getCreateCPNISubmitCreateButton();
		CPNISubmitCreateButton.click();
	}
	
	public void CPNIConfirmAddressClick() throws IOException
	{
		container.waitForElement(10, container.getCreateCPNIAddressConfirmButton_xpath(), "xpath");
		CPNIAddressConfirmButton=container.getCreateCPNIAddressConfirmButton();
		CPNIAddressConfirmButton.click();
	}
	
	public void viewCPNIInfoConfirmationPopUp() throws IOException
	{
		container.waitForElement(10, container.getCreateCPNISaveChangesButton_xpath(), "xpath");
	}
	
	public void clickOnCPNISaveChanges() throws IOException
	{
		
		container.waitForElement(10, container.getCreateCPNISaveChangesButton_xpath(), "xpath");
		CPNISaveChangesButton=container.getCreateCPNISaveChangesButton();
		CPNISaveChangesButton.click();
	}
	
	public void CPNIProcessSucessfullLabel() throws IOException
	{
		container.waitForElement(40, container.getCreateCPNIProcessSucessfullLabel_css(), "cssSelector");
	}
	
								//REQUEST LEGAL ENTITY NAME CHANGE THROUGH CLE SEARCH//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public void selectCLERequestLegalNameChange() throws IOException
	{
		container.waitForElement(10, container.getCLERequestLegalNameChangeOption_xpath(), "xpath");
		CLERequestLegalNameChangeOption=container.getCLERequestLegalNameChangeOption();
		CLERequestLegalNameChangeOption.click();
	}	
	
	public void fillCLEUpdateLegalNameInfo(String NewUpdateCLEName) throws IOException
	{
		CommonFunctions.switchToPopUp();
		container.waitForElement(10, container.getCGIUpdateCustomerLegalEntityNameTextBox_xpath(), "xpath");
		CGIUpdateCustomerLegalEntityNameTextBox=container.getCGIUpdateCustomerLegalEntityNameTextBox();
		//CGIUpdateCustomerLegalEntityNameCPEOption=container.getCGIUpdateCustomerLegalEntityNameCPEOption();
		CGIUpdateCustomerLegalEntityNameSubmitButton=container.getCLEUpdateCustomerLegalEntityNameSubmitButton();
		
		CGIUpdateCustomerLegalEntityNameTextBox.clear();
		CGIUpdateCustomerLegalEntityNameTextBox.sendKeys(NewUpdateCLEName);
		//new Select(CGIUpdateCustomerLegalEntityNameCPEOption).selectByVisibleText("Yes");
		CGIUpdateCustomerLegalEntityNameSubmitButton.click();
	}
	
											//REQUEST LEGAL ENTITY ADDRESS CHANGE THROUGH CLE SEARCH//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public void selectCLERequestLegalAddressChange() throws IOException
	{
		container.waitForElement(10, container.getCLEUpdateCustomerLegalAddressOption_xpath(), "xpath");
		CLERequestLegalAddressChangeOption=container.getCLEUpdateCustomerLegalAddressOption();
		CLERequestLegalAddressChangeOption.click();
	}	
	
	public void fillCLELegalAddressInformation(List<String> addressInfo) throws IOException
	{
		container.waitForElement(10,container.getCGIUpdateCustomerLegalAddressLine1_xpath(), "xpath");
		CGIUpdateCustomerLegalAddressLine1=container.getCGIUpdateCustomerLegalAddressLine1();
		CGIUpdateCustomerLegalAddressLine2=container.getCGIUpdateCustomerLegalAddressLine2();
		CGIUpdateCustomerLegalAddressLine3=container.getCGIUpdateCustomerLegalAddressLine3();
		CGIUpdateCustomerLegalAddressCity=container.getCGIUpdateCustomerLegalAddressCity();
		CGIUpdateCustomerLegalAddressState=container.getCGIUpdateCustomerLegalAddressState();
		CGIUpdateCustomerLegalAddressZipCode=container.getCGIUpdateCustomerLegalAddressZipCode();
		CLEUpdateCustomerLegalAddressSubmitButton=container.getCLEUpdateCustomerLegalAddressSubmitButton();
		
		CGIUpdateCustomerLegalAddressLine1.clear();
		CGIUpdateCustomerLegalAddressLine2.clear();
		CGIUpdateCustomerLegalAddressLine3.clear();
		CGIUpdateCustomerLegalAddressCity.clear();
		CGIUpdateCustomerLegalAddressZipCode.clear();
		CGIUpdateCustomerLegalAddressLine1.sendKeys(addressInfo.get(0));
		CGIUpdateCustomerLegalAddressLine2.sendKeys(addressInfo.get(1));
		CGIUpdateCustomerLegalAddressLine3.sendKeys(addressInfo.get(2));
		CGIUpdateCustomerLegalAddressCity.sendKeys(addressInfo.get(3));
		new Select(CGIUpdateCustomerLegalAddressState).selectByVisibleText(addressInfo.get(4));
		CGIUpdateCustomerLegalAddressZipCode.sendKeys(addressInfo.get(5));
		CLEUpdateCustomerLegalAddressSubmitButton.click();
	}
	
	public void selectRequestInquiryOptionFromDrowDown() throws IOException
	{
		container.waitForElement(10, container.getCLERequestInquiryOption_xpath(), "xpath");
		CLERequestInquiryOption=container.getCLERequestInquiryOption();
		CLERequestInquiryOption.click();
	}
	
	public void writeRequestInquiryComment(String Comment) throws IOException
	{
		container.waitForElement(10, container.getCLERequestInquiryCommentsTextBox_xpath(),"xpath");
		CLERequestInquiryCommentsTextBox=container.getCLERequestInquiryCommentsTextBox();
		CLERequestInquiryCommentsTextBox.sendKeys(Comment);
	}
	
	public void submitRequestInquiry() throws IOException
	{
		CLERequestInquirySendButton=container.getCLERequestInquirySendButton();
		CLERequestInquirySendButton.click();
		container.waitForElement(10, container.getCLERequestInquiryConfirmationMessage_css(), "cssSelector");
	}
	
												//EDIT BASIC CLE INFO//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public void clickOnEntityInformationTab() throws IOException
	{
		container.waitForElement(10, container.getCLEEntityInformationTab_xpath(), "xpath");
		CLEEntityInformationTab=container.getCLEEntityInformationTab();
		CLEEntityInformationTab.click();
	}
	
	public void clickOnUpdateBasicCLEInfo() throws IOException, InterruptedException
	{
		container.waitForElement(10, container.getCLEUpdateCLEInfoButton_xpath(), "xpath");
		Thread.sleep(2000);
		CLEUpdateBasicInformationButton=container.getCLEUpdateCLEInfoButton();
		Thread.sleep(2000);
		CLEUpdateBasicInformationButton.click();
	}
	
	public void fillBasicCLEInfo(String status, String phone) throws IOException
	{
		container.waitForElement(20, container.getLegalEntityStatusDropDown_xpath(), "xpath");
		LegalEntityStatusDropDown=container.getLegalEntityStatusDropDown();
		new Select(LegalEntityStatusDropDown).selectByVisibleText(status);
		MainPhoneNumberTextBox=container.getMainPhoneNumberTextBox();
		MainPhoneNumberTextBox.clear();
		MainPhoneNumberTextBox.sendKeys(phone);
		UpdateCLEBasicInfoSubmitButton=container.getUpdateCLEBasicInfoSubmitButton();
		UpdateCLEBasicInfoSubmitButton.click();
	}
	

	public void updateCLEBasicInfoOperationSuccessfull() throws IOException
	{
		container.waitForElement(10, container.getUpdateCLEBasicInfoOperationSucessfullButton_xpath(), "xpath");
		UpdateCLEBasicInfoOperationSuccesfullButton=container.getUpdateCLEBasicInfoOperationSucessfullButton();
		UpdateCLEBasicInfoOperationSuccesfullButton.click();
	}
	
	public void clickOnUpdateDUNSIcon() throws IOException, InterruptedException
	{
		container.waitForElement(10, container.getUpdateDUNSIcon_xpath(), "xpath");
		Thread.sleep(2000);
		UpdateDUNSIcon=container.getUpdateDUNSIcon();
		UpdateDUNSIcon.click();
	}
	
	public void updateCLEWithNewDUNS(String NewDUNS) throws IOException
	{
		container.waitForElement(10, container.getUpdateDUNSLookupTextBox_xpath(), "xpath");
		UpdateDUNSLookupTextBox=container.getUpdateDUNSLookupTextBox();
		UpdateDUNSLookupTextBox.clear();
		UpdateDUNSLookupTextBox.sendKeys(NewDUNS);
		UpdateDUNSContinueButton=container.getUpdateDUNSContinueButton();
		UpdateDUNSContinueButton.click();
	}
	
	public void updateDUNSSaveChanges() throws IOException
	{
		container.waitForElement(10, container.getUpdateDUNSSaveChangesButton_xpath(), "xpath");
		UpdateDUNSSaveChangesButton=container.getUpdateDUNSSaveChangesButton();
		UpdateDUNSSaveChangesButton.click();
	}
	
	public void updateDUNSConfirmOperation() throws IOException
	{
		container.waitForElement(10, container.getUpdateDUNSConfirmOperation_xpath(), "xpath");
		UpdateDUNSConfirmOperation=container.getUpdateDUNSConfirmOperation();
		UpdateDUNSConfirmOperation.click();
	}
	
	public void clickOnCreateAliasLabelButton() throws IOException, InterruptedException
	{
		container.waitForElement(10, container.getCreateAliasLabelButton_xpath(), "xpath");
		Thread.sleep(1000);
		CreateAliasLabelButton=container.getCreateAliasLabelButton();
		CreateAliasLabelButton.click();
	}
	
	public void fillAliasLabelInformation(String AliasLabelName, String Type) throws IOException
	{
		container.waitForElement(10, container.getCreateAliasNameTextBox_xpath(), "xpath");
		AliasLabelTextBox=container.getCreateAliasNameTextBox();
		AliasLabelTextBox.sendKeys(AliasLabelName);
		
		AliasLabelType=container.getCreateAliasTypeDropDown();
		new Select(AliasLabelType).selectByVisibleText(Type);
		
		
	}
	
	public void createAliasLabelSaveChanges()
	{
		CreateAliasSaveChanges=container.getCreateAliasSaveChangesButton();
		CreateAliasSaveChanges.click();
	}
	
	public void createAliasLabelOperationSuccessfull() throws IOException
	{
		container.waitForElement(10, container.getCreateAliasOperationSuccessfull_css(), "cssSelector");
		
	}
	
	
	
	
	
}
