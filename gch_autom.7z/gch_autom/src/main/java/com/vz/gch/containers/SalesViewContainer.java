package com.vz.gch.containers;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.vz.gch.views.CommonFunctions;

public class SalesViewContainer {
	
	private WebDriver driver;
	
	public void waitForElement(Integer timeout, String ElementString, String Type) throws IOException{
		CommonFunctions.isElementPresent(driver, timeout, ElementString, Type);
	}
	
	public String getWindowHandle()
	{
		return driver.getWindowHandle();
	}
	
	public SalesViewContainer(WebDriver driver) {
		this.driver = driver;
	}
	
	
	public WebElement getSalesAccounts(){
		return driver.findElement(By.xpath("//ul[@id='globalNavId']/li[5]/a/div"));
	}
	
	public WebElement getCreateBankNASPs(){
		return driver.findElement(By.xpath("//td[3]/ul/li[3]/a"));
	}


	public WebElement getNumberOfNASPID(){
		return driver.findElement(By.xpath("//td[2]/input"));
	}
	
	public WebElement getNASPID_DC(){
		return driver.findElement(By.xpath("//tr[2]/td/input"));
	}
	
	public WebElement getNASPID_F2AlphaC(){
		return driver.findElement(By.xpath("//tr[2]/td[2]/input"));
	}
	
	public WebElement getBranch(){
		return driver.findElement(By.xpath("//td[2]/select"));
	}
	
	
	public WebElement getFinanceRevLoc_Button(){
		return driver.findElement(By.xpath("//td[2]/div/a"));
	}
	
	public WebElement getFinanceRevLoc(){
		return driver.findElement(By.xpath("//span/table/tbody/tr[2]/td/table/tbody/tr[2]/td/input"));
	}
	
	public WebElement getFinanceRevLoc_Description(){
		return driver.findElement(By.xpath("//td[3]/input"));
	}
	
	public WebElement getSelectFinanceRevLoc(){
		return driver.findElement(By.xpath("//td/a"));
	}
	
	public WebElement getFinanceRevLoc_SearchButton(){
		return driver.findElement(By.xpath("//td[5]/div/a"));
	}
	
	public WebElement getNASPType(){
		return driver.findElement(By.xpath("//tr[7]/td[2]/select"));
	}
	
	public WebElement getCancel(){
		return driver.findElement(By.xpath("//table[3]/tbody/tr/td/div/a"));
	}
	
	public WebElement getCancelUpdate(){
		return driver.findElement(By.xpath("//tr[7]/td/table/tbody/tr/td/div/a"));
	}
	
	public WebElement getCreate(){
		return driver.findElement(By.xpath("//td[3]/div/a"));
	}
	
	public WebElement getNASPSearch(){
		return driver.findElement(By.xpath("//td[3]/ul/li/a"));
	}
	
	public WebElement getNASPID(){
		return driver.findElement(By.xpath("//td[2]/input"));
	}
	
	public WebElement getNASPName(){
		return driver.findElement(By.xpath("//tr[2]/td[2]/input"));
	}
	
	public WebElement getGUDUNS(){
		return driver.findElement(By.xpath("//tr[3]/td[2]/input"));
	}
	
	public WebElement getGUDUNSName(){
		return driver.findElement(By.xpath("//tr[4]/td[2]/input"));
	}
	
	public WebElement getDUNS(){
		return driver.findElement(By.xpath("//tr[5]/td[2]/input"));
	}
	
	public WebElement getDUNSName(){
		return driver.findElement(By.xpath("//tr[6]/td[2]/input"));
	}
	
	public WebElement getNASPTypeName(){
		return driver.findElement(By.xpath("//div/select"));
	}
	
	public WebElement getNASPTypeCodeCode(){
		return driver.findElement(By.xpath("//tr[8]/td[2]/div/select"));
	}
	
	public WebElement getBranchNameName(){
		return driver.findElement(By.xpath("//tr[9]/td[2]/div/select"));
	}
	
	public WebElement getSegmentNameName(){
		return driver.findElement(By.xpath("//td[2]/table/tbody/tr/td[2]/div/select"));
	}
	
	public WebElement getSegmentCodeCode(){
		return driver.findElement(By.xpath("//tr[2]/td[2]/div/select"));
	}
	
	public WebElement getRegionNameName(){
		return driver.findElement(By.xpath("//tr[3]/td[2]/div/select"));
	}
	
	public WebElement getRegionCodeCode(){
		return driver.findElement(By.xpath("//tr[4]/td[2]/div/select"));
	}
	
	public WebElement getBranchCodeCode(){
		return driver.findElement(By.xpath("//tr[5]/td[2]/div/select"));
	}
	
	public WebElement getParentNASPSearch_SearchButton(){
		return driver.findElement(By.xpath("//td[3]/div/a"));
	}
	
	public WebElement getCheckButtonNASP_ParentNASPSearchResult(){
		return driver.findElement(By.xpath("//td/center/input"));
		
	}
	
	public WebElement getEditButton(){
		return driver.findElement(By.xpath("//span/a"));
	}
	
	public WebElement getUpdateNASPName(){
		return driver.findElement(By.xpath("//td[2]/input"));
	}
	
	public WebElement getUpdateNASPType(){
		return driver.findElement(By.xpath("//td[2]/select"));
	}
	
	public WebElement getUpdateVerticalReporting(){
		return driver.findElement(By.xpath("//tr[7]/td[2]/select"));
	}
	
	public WebElement getUpdateLowerIndustry(){
		return driver.findElement(By.xpath("//tr[8]/td[2]/select"));
	}
	
	public WebElement getUpdateBranch(){
		return driver.findElement(By.xpath("//tr[3]/td[2]/select"));
	}
	
	public WebElement getUpdateFinanceRevLoc(){
		return driver.findElement(By.xpath("//td[2]/div/a"));
	}
	
	public WebElement getUpdateComments(){
		return driver.findElement(By.xpath("//textarea"));
	}
	
	public WebElement getSaveChanges(){
		return driver.findElement(By.xpath("//tr[7]/td/table/tbody/tr/td[3]/div/a"));
	}
	
	public WebElement getClickExportButtong(){
		return driver.findElement(By.xpath("//td[5]/span/a"));
	}
	
	public WebElement getTextFileCheckButton(){
		return driver.findElement(By.xpath("//fieldset/table/tbody/tr/td/input"));
	}
	
	public WebElement getExcelCheckButton(){
		return driver.findElement(By.xpath("//tr[2]/td/input"));
		
	}
	
	public WebElement getExportParentNASPSearchExport(){
		return driver.findElement(By.xpath("//td/div/div[2]/a"));
	}
	
	public WebElement getDownloadFileParentNASPSearchExport(){
		return driver.findElement(By.xpath("//tr[4]/td/div/div[4]/div/a"));
	}
	
	public WebElement getCancelExport(){
		return driver.findElement(By.xpath("//tr[4]/td/div/div/a"));
	}
	
	public WebElement getDelete(){
		return driver.findElement(By.xpath("//td[3]/span/a"));
	}
	
	public WebElement getDeleteComment(){
		return driver.findElement(By.xpath("//textarea"));
	}
	
	public WebElement getRedDeleteButton(){
		return driver.findElement(By.xpath("//td/div/div[2]/a"));
	}
	
	public WebElement getAccountSearch(){
		return driver.findElement(By.xpath("//td/ul/li/a"));
	}
	
	public WebElement getOriginalAccountID(){
		return driver.findElement(By.xpath("//td[2]/input"));
	}
	
	public WebElement getTranslatedAccountID(){
		return driver.findElement(By.xpath("//tr[2]/td[2]/input"));
	}
	
	public WebElement getParentNaspID(){
		return driver.findElement(By.xpath("//tr[3]/td[2]/input"));
	}
	
	public WebElement getParentNaspName(){
		return driver.findElement(By.xpath("//tr[4]/td[2]/input"));
	}
	
	public WebElement getParentBranch(){
		return driver.findElement(By.xpath("//tr[5]/td[2]/input"));
	}
	
	public WebElement getSubNaspID(){
		return driver.findElement(By.xpath("//tr[6]/td[2]/input"));
	}
	
	public WebElement getSubNaspName(){
		return driver.findElement(By.xpath("//tr[7]/td[2]/input"));
	}
	
	public WebElement getOpcoCode(){
		return driver.findElement(By.xpath("//tr[8]/td[2]/input"));
	}
	
	public WebElement getAccountNameTextbox(){
		return driver.findElement(By.xpath("//td[2]/table/tbody/tr/td[2]/input"));
		
	}
	
	public WebElement getDunsID(){
		return driver.findElement(By.xpath("//td[2]/table/tbody/tr[6]/td[2]/input"));
	}
	
	public WebElement getDunsName(){
		return driver.findElement(By.xpath("//td[2]/table/tbody/tr[7]/td[2]/input"));
	}
	
	public WebElement getAccountSearch_SearchButton(){
		return driver.findElement(By.xpath("//span/a"));
	}
	
	public WebElement getAccountSearch_ExportButton(){
		return driver.findElement(By.xpath("//td[8]/div/a"));
	}
	
	public WebElement getDownloadFileAccountSearchExport(){
		return driver.findElement(By.xpath("//tr[4]/td/div/div[3]/div/a"));
	}
	
	public WebElement getAccountSearchCancel(){
		return driver.findElement(By.xpath("//tr[4]/td/div/div/a"));
	}
	
	public WebElement getSegmentLink(){
		return driver.findElement(By.xpath("//tr[2]/td[3]/ul/li/a"));
	}
	
	public WebElement getSegments_ExportButton(){
		return driver.findElement(By.xpath("//td[3]/div/a"));
	}
	
	public WebElement getDownloadFileSegmentsExport(){
		return driver.findElement(By.xpath("//tr[5]/td/div/div[3]/div/a"));
	}
	
	public WebElement getSegmentsCancel(){
		return driver.findElement(By.xpath("//tr[5]/td/div/div/a"));
	}
	
	public WebElement getRegionsLink(){
		return driver.findElement(By.xpath("//tr[2]/td[3]/ul/li[2]/a"));
	}
	
	public WebElement getRegions_ExportButton(){
		return driver.findElement(By.xpath("//td[4]/div/a"));
	}
	
	public WebElement getDownloadFileRegionsExport(){
		return driver.findElement(By.xpath("//tr[4]/td/div/div[3]/div/a"));
	}
	
	public WebElement getManagerRoles(){
		return driver.findElement(By.xpath("//tr[2]/td[3]/ul/li[4]/a"));
	}
	
	public WebElement getManagerRoles_Export(){
		return driver.findElement(By.xpath("//td[2]/span/a"));
	}
	
	public WebElement getDownloadFileManagerRolesExport(){
		return driver.findElement(By.xpath("//tr[5]/td/div/div[3]/div/a"));	
	}
	
	public WebElement getlevel_A_ManagerRoles(){
		return driver.findElement(By.xpath("//td[9]/a/img"));	
	}
	
	public WebElement getlevel_B_ManagerRoles(){
		return driver.findElement(By.xpath("//tr[2]/td[9]/a/img"));	
	}
	
	public WebElement getlevel_C_ManagerRoles(){
		return driver.findElement(By.xpath("//tr[3]/td[9]/a/img"));	
	}
	
	public WebElement getlevel_D_ManagerRoles(){
		return driver.findElement(By.xpath("//tr[4]/td[9]/a/img"));	
	}
	
	public WebElement getlevel_E_ManagerRoles(){
		return driver.findElement(By.xpath("//tr[5]/td[9]/a/img"));	
	}
	
	public WebElement getlevel_F_ManagerRoles(){
		return driver.findElement(By.xpath("//tr[6]/td[9]/a/img"));	
	}
	
	
	public WebElement getMR_RoleLongName(){
		return driver.findElement(By.xpath("//td[3]/input"));	
	}
	
	public WebElement getMR_RoleShortName(){
		return driver.findElement(By.xpath("//tr[2]/td[3]/input"));	
	}
	
	public WebElement getMR_Comment(){
		return driver.findElement(By.xpath("//textarea"));	
	}
	
	public WebElement getSave_CommentMR(){
		return driver.findElement(By.xpath("//td/div/div[2]/a"));	
	}
	
	public WebElement getBankNASPIDCreatedLabel(){
		return driver.findElement(By.xpath("//td/span"));
	}
	
	public WebElement getNASPIDDeletedConfirmationLabel(){
		return driver.findElement(By.cssSelector("span.iceMsgsInfo.confirmMsg"));
	}
	
	public WebElement getNASPIDDeletedErrorLabel(){
		return driver.findElement(By.cssSelector("span.iceMsgsError.errorMsg"));
	}
	
	public WebElement getSegmentExportButton(){
		return driver.findElement(By.xpath("//td[3]/div/a"));
	}
	
	public WebElement getSegmentExportPopUp(){
		return driver.findElement(By.xpath("//div[3]/table/tbody/tr/td"));
	}
	
	public WebElement getAccountSearchLink(){
		return driver.findElement(By.xpath("//td/ul/li/a"));
	}
	
	public WebElement getAccountSearchTextBox(){
		return driver.findElement(By.xpath("//td[2]/input"));
	}
	
	public WebElement getAccountSearchButtonSearch(){
		return driver.findElement(By.xpath("//span/a"));
	}
	
	public WebElement getAccountSearchAccountFound(){
		return driver.findElement(By.xpath("//div[2]/div/table/tbody/tr/td[2]"));
	}
	
	
	

	//***************************************************************XPATH**********************************************************************
	//-----------------------------------------------------------------------------------------------------------------------------------------
	
	
	public String getSalesAccountsxpath(){
		return "//ul[@id='globalNavId']/li[5]/a/div";
	}
	
	public String getCreateBankNASPsxpath(){
		return "//td[3]/ul/li[3]/a";
	}
	
	public String getNumberOfNASPIDxpath(){
		return "//li[5]/a/div";
	}
	
	public String getNASPID_DCxpath(){
		return "//td[@id='j_id65:j_id672-1-0']/input";
	}
	
	public String getNASPID_F2AlphaCsxpath(){
		return "//tr[2]/td[2]/input";
	}
	
	public String getBranchxpath(){
		return "//tr[2]/td/input";
	}
	
	
	public String getFinanceRevLoc_Buttonxpath(){
		return "//td[2]/div/a";
	}
	
	public String getFinanceRevLocxpath(){
		return "//span/table/tbody/tr[2]/td/table/tbody/tr[2]/td/input";
	}
	
	
	
	public String getFinanceRevLoc_Descriptionxpath(){
		return "//td[3]/input";
	}
	
	
	public String getSelectFinanceRevLocxpath(){
		return "//td/a";
	}  

	
	public String getFinanceRevLoc_SearchButtonxpath(){
		return "//td[5]/div/a";
	}
	public String getNASPTypexpath(){
		return "//tr[7]/td[2]/select";
	}
	
	
	public String getCancelxpath(){
		return "//table[3]/tbody/tr/td/div/a";
	}
	
	public String getCancelUpdatexpath(){
		return "//tr[7]/td/table/tbody/tr/td/div/a";
	}
	
	public String getCreatexpath(){
		return "//td[3]/div/a";
	}

    
	public String getNASPSearchxpath(){
		return "//td[3]/ul/li/a";
	}
	
	public String getNASPIDxpath(){
		return "//td[2]/input";
	}
	
	public String getNASPNamexpath(){
		return "//tr[2]/td[2]/input";
	}
	
	public String getGUDUNSxpath(){
		return "//tr[3]/td[2]/input";
	}
	
	public String getGUDUNSNamexpath(){
		return "//tr[4]/td[2]/input";
	}
	
	public String getDUNSxpath(){
		return "//tr[5]/td[2]/input";
	}
	
	public String getDUNSNamexpath(){
		return "//tr[6]/td[2]/input";
	}
	
	public String getNASPTypeNamexpath(){
		return "//div/select";
	}
	
	public String getNASPTypeCodeCodexpath(){
		return "//tr[8]/td[2]/div/select";
	}
	
	public String getBranchNameNamexpath(){
		return "//tr[9]/td[2]/div/select";
	}
	
	public String getSegmentNameNamexpath(){
		return "//td[2]/table/tbody/tr/td[2]/div/select";
	}
	
	public String getSegmentCodeCodexpath(){
		return "//tr[2]/td[2]/div/select";
	}
	
	public String getRegionNameNamexpath(){
		return "//tr[3]/td[2]/div/select";
	}
	
	public String getRegionCodeCodexpath(){
		return "//tr[4]/td[2]/div/select";
	}
	
	public String getBranchCodeCodexpath(){
		return "//tr[5]/td[2]/div/select";
	}
	
	public String getParentNASPSearch_SearchButtonxpath(){
		return "//td[3]/div/a";
	}
	
	public String getCheckButtonNASP_ParentNASPSearchResultxpath(){
		return "//td/center/input";
	}
	
	public String getEditButtonxpath(){
		return "//span/a";
	}
	
	public String getUpdateNASPNamexpath(){
		return "//td[2]/input";
	}
	
	public String getUpdateNASPTypexpath(){
		return "//td[2]/select";
	}
	
	public String getUpdateVerticalReportingxpath(){
		return "//tr[7]/td[2]/select";
	}
	
	public String getUpdateLowerIndustryxpath(){
		return "//tr[8]/td[2]/select";
	}
	
	public String getUpdateBranchxpath(){
		return "//tr[3]/td[2]/select";
	}
	
	public String getUpdateFinanceRevLocxpath(){
		return "//td[2]/div/a";
	}
	
	public String getUpdateCommentsxpath(){
		return "//textarea";
	}
	
	public String getSaveChangesxpath(){
		return "//tr[7]/td/table/tbody/tr/td[3]/div/a";
	}
	
	public String getClickExportButtonxpath(){
		return "//td[5]/span/a";
	}
	
	public String getTextFileCheckButtonxpath(){
		return "//fieldset/table/tbody/tr/td/input";
	}
	
	public String getExcelCheckButtonxpath(){
		return "//tr[2]/td/input";
	}
	
	public String getExportParentNASPSearchExportxpath(){
		return "//td/div/div[2]/a";
	}
	
	public String getDownloadFileParentNASPSearchExportxpath(){
		return "//tr[4]/td/div/div[4]/div/a";
	}
	
	public String getCancelExportxpath(){
		return "//tr[4]/td/div/div/a";
	}
	
	public String getDeletexpath(){
		return "//td[3]/span/a";
	}
	
	public String getDeleteCommentxpath(){
		return "//textarea";
	}
	
	public String getRedDeleteButtonxpath(){
		return "//td/div/div[2]/a";
	}
	
	public String getAccountSearchxpath(){
		return "//td/ul/li/a";
	}
	
	public String getOriginalAccountIDxpath(){
		return "//td[2]/input";
	}
	
	public String getTranslatedAccountIDxpath(){
		return "//tr[2]/td[2]/input";
	}
	
	public String getParentNaspIDxpath(){
		return "//tr[3]/td[2]/input";
	}
	
	public String getParentNaspNamexpath(){
		return "//tr[4]/td[2]/input";
	}
	
	public String getParentBranchxpath(){
		return "//tr[5]/td[2]/input";
	}
	
	public String getSubNaspIDxpath(){
		return "//tr[6]/td[2]/input";
	}
	
	public String getSubNaspNamexpath(){
		return "//tr[7]/td[2]/input";
	}
	
	public String getOpcoCodexpath(){
		return "//tr[8]/td[2]/input";
	}
	
	public String getAccountNameTextboxxpath(){
		return "//td[2]/table/tbody/tr/td[2]/input";
	}
	
	public String getDunsIDxpath(){
		return "//td[2]/table/tbody/tr[6]/td[2]/input";
	}
	
	public String getDunsNamexpath(){
		return "//td[2]/table/tbody/tr[7]/td[2]/input";
	}
	
	public String getAccountSearch_SearchButtonxpath(){
		return "//span/a";
	}
	
	public String getAccountSearch_ExportButtonxpath(){
		return "//td[8]/div/a";
	}
	
	public String getDownloadFileAccountSearchExportxpath(){
		return "//tr[4]/td/div/div[3]/div/a";
	}
	
	public String getAccountSeachCancelxpath(){
		return "//tr[4]/td/div/div/a";
	}
	
	public String getSegmentsLinkxpath(){
		return "//tr[2]/td[3]/ul/li/a";
	}
	
	
	public String getSegments_ExportButtonxpath(){
		return "//td[3]/div/a";
	}
	
	public String getDownloadFileSegmentsExportxpath(){
		return "//tr[5]/td/div/div[3]/div/a";
	}
	
	public String getSegmentsCancelxpath(){
		return "//tr[5]/td/div/div/a";
	}
	
	public String getRegionsLinkxpath(){
		return "//tr[2]/td[3]/ul/li[2]/a";
	}
	
	public String getRegions_ExportButtonxpath(){
		return "//td[4]/div/a";
	}
	
	
	public String getDownloadFileRegionsExportxpath(){
		return "//tr[4]/td/div/div[3]/div/a";
	}
	
	public String getManagerRolesxpath(){
		return "//tr[2]/td[3]/ul/li[4]/a";
	}
	
	public String getManagerRoles_Exportxpath(){
		return "//td[2]/span/a";
	}
	
	public String getDownloadFileManagerRolesExportxpath(){
		return "//tr[5]/td/div/div[3]/div/a";	
	}
	
	public String getlevel_A_ManagerRolesxpath(){
		return "//td[9]/a/img";	
	}
	
	public String getlevel_B_ManagerRolesxpath(){
		return "//tr[2]/td[9]/a/img";	
	}
	
	public String getlevel_C_ManagerRolesxpath(){
		return "//tr[3]/td[9]/a/img";	
	}
	
	public String getlevel_D_ManagerRolesxpath(){
		return "//tr[4]/td[9]/a/img";	
	}
	
	public String getlevel_E_ManagerRolesxpath(){
		return "//tr[5]/td[9]/a/img";	
	}
	
	public String getlevel_F_ManagerRolesxpath(){
		return "//tr[6]/td[9]/a/img";	
	}
	
	public String getMR_RoleLongNamexpath(){
		return "//td[3]/input";	
	}
	
	public String getMR_RoleShortNamexpath(){
		return "//tr[2]/td[3]/input";	
	}
	
	public String getMR_Commentxpath(){
		return "//textarea";	
	}
	
	public String getSave_CommentMRxpath(){
		return "//td/div/div[2]/a";	
	}
	
	public String getBankNASPIDCreatedLabel_xpath(){
		return "//td/span";
	}
	
	public String getNASPIDDeletedConfirmationLabel_css(){
		return "span.iceMsgsInfo.confirmMsg";
	}
	
	public String getNASPIDDeletedErrorLabel_css(){
		return "span.iceMsgsError.errorMsg";
	}
	
	public String getNASPIDExportPopUp_xpath(){
		return "//td/div/div[2]/a";
	}
	
	public String getSegmentExportButton_xpath(){
		return "//td[3]/div/a";
	}
	
	public String getSegmentExportPopUp_xpath(){
		return "//div[3]/table/tbody/tr/td";
	}
	
	public String getRegionExportPopUp_xpath(){
		return "//td/div/div[2]/a";
	}
	
	public String getManageRolesExportPopUp_xpath(){
		return "//td/div/div[2]/a";
	}
	
	public String getAccountSearchLink_xpath(){
		return "//td/ul/li/a";
	}
	
	public String getAccountSearchTextBox_xpath(){
		return "//td[2]/input";
	}
	
	public String getAccountSearchButtonSearch_xpath(){
		return "//span/a";
	}
	
	public String getAccountSearchAccountFound_xpath(){
		return "//div[2]/div/table/tbody/tr/td[2]";
	}
}








