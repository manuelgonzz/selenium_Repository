package com.vz.gch.containers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ById;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.vz.gch.views.CommonFunctions;

public class LegalViewContainer {
	
	private WebDriver driver;
	private WebElement li;
	public WebElement workflowTab;
	
	 ArrayList<String> HMTInfoLinesLabel =  new ArrayList<String>();
	HashMap<String, String> HMTInfoLines  = new HashMap<String, String>();
	
	public void waitForElement(Integer timeout, String ElementString, String Type) throws IOException{
		CommonFunctions.isElementPresent(driver, timeout, ElementString, Type);
	}
	public String getWindowTitle()
	{
		return driver.switchTo().window(driver.getWindowHandle()).getTitle();
	}
	
	public WebElement getWorkFlowTabElement()
	{
		List<WebElement> wftabs=driver.findElements(By.cssSelector("div.headerTabs"));
		WebElement element=null;
		
		
		for(WebElement e: wftabs)
		{
			if(e.getText().equalsIgnoreCase("Workflow Tasks"))
			{
			 element= e.findElement(By.linkText("Workflow Tasks"));
			break;
			}
		}
		
		return element;
		
		
	}
	
	
/*	
 
	public void receiveHMTInfoLines()
	{
		Integer Position=0;
		HMTInfoLinesLabel.add("Top Co Name");
	    HMTInfoLinesLabel.add("Top Co ID");
	    HMTInfoLinesLabel.add("Company Name");
	    HMTInfoLinesLabel.add("Company ID");
	    HMTInfoLinesLabel.add("Country");
	    HMTInfoLinesLabel.add("Marketing Segment");
	    HMTInfoLinesLabel.add("Account Manager");
	    HMTInfoLinesLabel.add("Program Name");
	    
		// Grab the table 
		WebElement table = driver.findElement(By.id("result:erv")); 

		// Now get all the TR elements from the table 
		List<WebElement> allRows = table.findElements(By.tagName("tr")); 

		// And iterate over them, getting the cells 
		for (WebElement row : allRows) { 
		    List<WebElement> cells = row.findElements(By.tagName("td")); 
	
		    // Print the contents of each cell
		    for (WebElement cell : cells) { 
		    	HMTInfoLines.put("Company ID", cell.getText());
		    /*	if(Position==7)
			     {
			    	 Position=0;
			     }
			    else{
			    	Position++;
			    }
		    	/
		    
		    }
		    
		}
		getSortByLabel("Company ID");
		
		
	}
	
	public void getSortByLabel(String Label)
	{
		Iterator<Map.Entry<String, String>> entries = HMTInfoLines.entrySet().iterator();
		while (entries.hasNext()) {
		    Entry<String, String> entry = entries.next();
		    if(entry.getKey().equalsIgnoreCase(Label))
		    {
		    	System.out.println(entry.getValue());
		    }
		    else{
		    	System.out.println("no encontro el key");
		    }
		    
		}
		
	}*/
	
	public boolean sortTopCompanyName() {
		
		ArrayList<String> TopCoName = new ArrayList<String>();
		
		for(int i=0; i<3; i++)
		{
			TopCoName.add(driver.findElement(By.id(getTopCoNameColumnFirst()+i+getTopCoNameColumnLast())).getText());
			if(!(driver.findElements(By.id(getTopCoNameColumnFirst()+(++i)+getTopCoNameColumnLast())).size() > 0))
			{
				break;
			}
		}
		
		String previous = "";
		for (final String current: TopCoName) {
		    if (current.compareTo(previous) < 0)
		        return false;
		    previous = current;
		}

		return true;
		
	}
	
public boolean sortTopCompanyID() {
		
		ArrayList<String> TopCoID = new ArrayList<String>();
		
		for(int i=0; i<3; i++)
		{
			TopCoID.add(driver.findElement(By.id(getTopCoIDColumnFirst()+i+getTopCoIDColumnLast())).getText());
			if(!(driver.findElements(By.id(getTopCoIDColumnFirst()+(++i)+getTopCoIDColumnLast())).size() > 0))
			{
				break;
			}
		}
		
		String previous = "";
		for (final String current: TopCoID) {
		    if (current.compareTo(previous) < 0)
		        return false;
		    previous = current;
		}

		return true;
		
	}
	
	public WebElement getLegalViewTab(){
		return driver.findElement(By.xpath("//li[3]/a/label"));
	}
	
	public WebElement getLegalViewCompanyNameTextBox(){
		return driver.findElement(By.xpath("//input[@id='result:compNm']"));
	}
	
	public WebElement getLegalViewCompany_BillingAccRadioButton(){
		return driver.findElement(By.xpath("//td[2]/label/input"));
	}
	
	public WebElement getLegalViewCompanyIDTextBox(){
		return driver.findElement(By.xpath("//td[4]/input"));
	}
	
	public WebElement getLegalViewBillingNameTextBox(){
		return driver.findElement(By.id("result:billNm"));
	}
	
	public WebElement getLegalViewBillingAccNumbTextBox(){
		return driver.findElement(By.id("result:billId"));
	}
	
	public WebElement getLegalViewSearchButton(){
		return driver.findElement(By.xpath("//tr[6]/td[4]/input"));
	}
	
	public WebElement getLegalViewHTMSearchButton(){
		return driver.findElement(By.xpath("//tr[3]/td/input"));
	}
	
	public WebElement getSearchCompanyResults(){
		return driver.findElement(By.id("result:erv:0:topCompNm1"));
	}
	
	public WebElement getSearchBillingResults(){
		return driver.findElement(By.id("result:erv1:0:banId"));
	}
	
	public WebElement getLegalViewFrame(){
		return driver.findElement(By.id("frameSearch"));
	}
	
	public WebElement getLegalViewNoRecordsLabel(){
		return driver.findElement(By.id("table1"));
	}
	
	public WebElement getTopCompanyNameSort(){
		return driver.findElement(By.id("result:erv:link2"));
	}
	
	public WebElement getFirstSortPosition(){
		return driver.findElement(By.id("result:erv:link2"));
	}

	public WebElement getTopCompanyIDSort(){
		return driver.findElement(By.id("result:erv:link3"));
	}
	
	public WebElement getCompanyNameSort(){
		return driver.findElement(By.xpath("//th[5]/a"));
	}
	
	public WebElement getCompanyIDSort(){
		return driver.findElement(By.xpath("//th[6]/a"));
	}
	
	public WebElement getCountrySort(){
		return driver.findElement(By.xpath("//th[7]/a"));
	}
	
	public WebElement getMarketingSegmentSort(){
		return driver.findElement(By.xpath("//th[8]/a"));
	}
	
	public WebElement getAccountManagerSort(){
		return driver.findElement(By.xpath("//th[9]/a"));
	}
	
	public WebElement getProgramNameSort(){
		return driver.findElement(By.xpath("//th[10]/a"));
	}
	
	public WebElement getPaginationSort(){
		return driver.findElement(By.id("result:pnext1"));
	}
	
	public WebElement getOrphanBansCheckboxSort(){
		return driver.findElement(By.id("result:onlyOrphan"));
	}
	
	public WebElement getmanaged_summaryCheckboxSort(){
		return driver.findElement(By.id("result:onlySBAN"));
	}
	
	public WebElement getSalesViewBansCheckboxSort(){
		return driver.findElement(By.id("result:svBAN"));
	}
	
	public WebElement getTreeViewIcon(){
		return driver.findElement(By.xpath("//td[2]/a/img"));
	}
	
	public WebElement getAccountMgrTextBox(){
		return driver.findElement(By.id("result:acntMgrId"));
	}
	
	public WebElement getTreeViewLabel(){
		return driver.findElement(By.cssSelector("b"));
	}
	
	public WebElement getWorkflowTaskTab(){
		return driver.findElement(By.xpath("//a[contains(text(),'Workflow Tasks')]"));
	}
	
	public WebElement getSourceCompanyNameTextBox(){
		return driver.findElement(By.xpath("//td[2]/input"));
	}
	
	public WebElement getSourceCompanySegmentDropDown(){
		return driver.findElement(By.id("workflowsearch:sourceSegment"));
	}
	
	public WebElement getStatusFilterDropDown(){
		return driver.findElement(By.xpath("//tr[4]/td[2]/select"));
	}
	
	public WebElement getTaskIdTextBox(){
		return driver.findElement(By.xpath("//tr[5]/td[2]/input"));
	}
	
	public WebElement getTargetCompanyNameTextBox(){
		return driver.findElement(By.xpath("//td[4]/input"));
	}
	
	public WebElement getTargetCompanySegmentDropDown(){
		return driver.findElement(By.xpath("//td[4]/select"));
	}
	
	public WebElement getRequestorDropDown(){
		return driver.findElement(By.xpath("//tr[4]/td[4]/select"));
	}
	
	public WebElement getEventTypeDropDown(){
		return driver.findElement(By.xpath("//tr[5]/td[4]/select"));
	}
	
	public WebElement getWorkflowTaskSearchButton(){
		return driver.findElement(By.xpath("//tr[6]/td[4]/input"));
	}
	
	public WebElement getWorkFlowTaskSearchResults(){
		return driver.findElement(By.xpath("//table[2]/tbody/tr/td/table/tbody/tr/td"));
	}
	
	public WebElement getDnBCompanyNameTextBox(){
		return driver.findElement(By.xpath("//form[@id='DBsearch']/table/tbody/tr/td[2]/input"));
	}
	
	public WebElement getDnBDunsTextBox(){
		return driver.findElement(By.xpath("//tr[2]/td[2]/input"));
	}
	
	public WebElement getDnBCityTextBox(){
		return driver.findElement(By.xpath("//tr[3]/td[2]/input"));
	}
	
	public WebElement getDnBGudunsNameTextBox(){
		return driver.findElement(By.xpath("//td[4]/input"));
	}
	
	public WebElement getDnBTradeStyleNameTextBox(){
		return driver.findElement(By.xpath("//tr[2]/td[4]/input"));
	}
	
	public WebElement getDnBStateDropDown(){
		return driver.findElement(By.xpath("//select"));
	}
	
	public WebElement getDnBGudunsTextBox(){
		return driver.findElement(By.xpath("//td[6]/input"));
	}
	
	public WebElement getDnBSecondaryTradeStyleNameTextBox(){
		return driver.findElement(By.xpath("//tr[2]/td[6]/input"));
	}
	
	public WebElement getDnBZipTextBox(){
		return driver.findElement(By.xpath("//tr[3]/td[6]/input"));
	}
	
	public WebElement getDnBStreetTextBox(){
		return driver.findElement(By.xpath("//td[8]/input"));
	}
	
	public WebElement getDnBCountryTextBox(){
		return driver.findElement(By.xpath("//tr[3]/td[8]/input"));
	}
	
	public WebElement getDnBSearchButton(){
		return driver.findElement(By.xpath("//td[10]/input"));
	}
	
	public WebElement getDnBLookupTab(){
		return driver.findElement(By.xpath("//li[5]/a"));
	}
	
	public WebElement getDnBSearchResults(){
		return driver.findElement(By.id("result:erv"));
	}
	
	public WebElement getDnBPaginationButton(){
		return driver.findElement(By.xpath("//table[3]/tbody/tr/td[2]/input"));
	}
	
	public WebElement getWorkFlowTaskNoRecordsLabel(){
		return driver.findElement(By.xpath("//form[@id='workflowtask']/table/thead/tr/th"));
	}
	
	public WebElement getDnBNoRecordsLabel(){
		return driver.findElement(By.xpath("//form[@id='result']/table/thead/tr/th"));
	}
	
	
						////////////////////////////////////////////////XPATH/////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public String getWindowHandle()
	{
		return driver.getWindowHandle();
	}
	
	public LegalViewContainer(WebDriver driver) {
		this.driver = driver;
	}
	
	public String getLegalViewFrame_id(){
		return "frameSearch";
	}
	public String getLegalViewTab_xpath(){
		return "//li[3]/a/label";
	}
	
	public String getLegalViewCompanyNameTextBox_xpath(){
		return "//input[@id='result:compNm']";
	}
	
	public String getLegalViewCompany_BillingAccRadioButton_xpath(){
		return "//td[2]/label/input";
	}
	
	public String getLegalViewCompanyIDTextBox_xpath(){
		return "//td[4]/input";
	}
	
	public String getLegalViewBillingNameTextBox_id(){
		return "result:billNm";
	}
	
	public String getLegalViewBillingAccNumbTextBox_id(){
		return "result:billId";
	}
	
	public String getLegalViewSearchButton_xpath(){
		return "//tr[3]/td/input legal";
	}
	
	public String getSearchBillingResults_id(){
		return "result:erv1:0:banId";
	}
	
	public String getSearchCompanyResults_id(){
		return "result:erv:0:topCompNm1";
	}
	
	public String getTopCompanyNameSort_id(){
		return "result:erv:link2";
	}
	
	public String getTopCompanyIDSort_id(){
		return "result:erv:link3";
	}
	
	public String getCompanyNameSort_xpath(){
		return "//th[5]/a";
	}
	
	public String getCompanyIDSort_xpath(){
		return "//th[6]/a";
	}
	
	public String getCountrySort_xpath(){
		return "//th[7]/a";
	}
	
	public String getMarketingSegmentSort_xpath(){
		return "//th[8]/a";
	}
	
	public String getAccountManagerSort_xpath(){
		return "//th[9]/a";
	}
	
	public String getProgramNameSort_xpath(){
		return "//th[10]/a";
	}
	
	public String getPaginationSort_id(){
		return "result:pnext1";
	}
	
	public String getOrphanBansCheckboxSort_id(){
		return "result:onlyOrphan";
	}
	
	public String getmanaged_summaryCheckboxSort_id(){
		return "result:onlySBAN";
	}
	
	public String getSalesViewBansCheckboxSort_id(){
		return "result:svBAN";
	}
	
	public String getTreeViewIcon_css(){
		return "//td[2]/a/img";
	}
	
	public String getFirstSortPosition_id(){
		return "result:erv:link2";
	}
	
	public String getTopCoNameColumnFirst(){
		return "result:erv:";
	}
	
	public String getTopCoNameColumnLast(){
		return ":topCompNm1";
	}
	
	public String getTopCoIDColumnFirst(){
		return "result:erv:";
	}
	
	public String getTopCoIDColumnLast(){
		return ":panel2";
	}
	
	public String getAccountMgrTextBox_id(){
		return "result:acntMgrId";
	}
	
	public String getTreeViewLabel_css(){
		return "b";
	}
	
	public String getWorkflowTaskTab_xpath(){
		return "//a[contains(text(),'Workflow Tasks')]";
	}
	
	public String getSourceCompanyNameTextBox_xpath(){
		return "//td[2]/input";
	}
	
	public String getSourceCompanySegmentDropDown_id(){
		return "workflowsearch:sourceSegment";
	}
	
	public String getStatusFilterDropDown_xpath(){
		return "//tr[4]/td[2]/select";
	}
	
	public String getTaskIdTextBox_xpath(){
		return "//tr[5]/td[2]/input";
	}
	
	public String getTargetCompanyNameTextBox_xpath(){
		return "//td[4]/input";
	}
	
	public String getTargetCompanySegmentDropDown_xpath(){
		return "//td[4]/select";
	}
	
	public String getRequestorDropDown_xpath(){
		return "//tr[4]/td[4]/select";
	}
	
	public String getEventTypeDropDown_xpath(){
		return "//tr[5]/td[4]/select";
	}
	
	public String getWorkflowTaskSearchButton_xpath(){
		return "//tr[6]/td[4]/input";
	}
	
	public String getWorkFlowTaskSearchResults_xpath(){
		return "//a/img";
	}
	
	public String getDnBCompanyNameTextBox_xpath(){
		return "//form[@id='DBsearch']/table/tbody/tr/td[2]/input";
	}
	
	public String getDnBDunsTextBox_xpath(){
		return "//tr[2]/td[2]/input";
	}
	
	public String getDnBCityTextBox_xpath(){
		return "//tr[3]/td[2]/input";
	}
	
	public String getDnBGudunsNameTextBox_xpath(){
		return "//td[4]/input";
	}
	
	public String getDnBTradeStyleNameTextBox_xpath(){
		return "//tr[2]/td[4]/input";
	}
	
	public String getDnBStateDropDown_xpath(){
		return "//select";
	}
	
	public String getDnBGudunsTextBox_xpath(){
		return "//td[6]/input";
	}
	
	public String getDnBSecondaryTradeStyleNameTextBox_xpath(){
		return "//tr[2]/td[6]/input";
	}
	
	public String getDnBZipTextBox_xpath(){
		return "//tr[3]/td[6]/input";
	}
	
	public String getDnBStreetTextBox_xpath(){
		return "//td[8]/input";
	}
	
	public String getDnBCountryTextBox_xpath(){
		return "//tr[3]/td[8]/input";
	}
	
	public String getDnBSearchButton_xpath(){
		return "//td[10]/input";
	}
	
	public String getDnBLookupTab_xpath(){
		return "//li[5]/a";
	}
	
	public String getDnBSearchResults_id(){
		return "result:erv";
	}
	
	public String getDnBPaginationButton_xpath(){
		return "//table[3]/tbody/tr/td[2]/input";
	}
	
	public String getWorkFlowTaskNoRecordsLabel_xpath(){
		return "//form[@id='workflowtask']/table/thead/tr/th";
	}
	
	public String getDnBNoRecordsLabel_xpath(){
		return "//form[@id='result']/table/thead/tr/th";
	}
}
