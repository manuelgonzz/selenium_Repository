package com.vz.gch.views;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.vz.gch.containers.LegalEntityContainer;
import com.vz.gch.containers.LegalViewContainer;
import com.vz.gch.containers.SalesViewContainer;
import com.vz.gch.containers.SingleSearchContainer;



public class CommonFunctions {
	
	
	static WebDriver driver;
	private static String xPath1="//a[contains(text(),'";
	private static String xPath2="')]";
	public static boolean acceptNextAlert;
	private static LegalEntityContainer container;
	private static LegalViewContainer LVContainer;
	private static SingleSearchContainer SSContainer;
	private static SalesViewContainer SVContainer;
	private static String[] lines;
	public static String oldCGINamePos;
	public CommonFunctions(WebDriver driver){
		this.driver=driver;
		container = new LegalEntityContainer(driver);
		LVContainer= new LegalViewContainer(driver);
		SSContainer= new SingleSearchContainer(driver);
		SVContainer= new SalesViewContainer(driver);
	}
	

	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
												//FIND ELEMENT METHOD//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	public static boolean isElementPresent(WebDriver driver, Integer Timeout, String ElementString, String SearchType) throws IOException  {
		 HashMap<String, Integer> SearchBy = new HashMap<String, Integer>();
		 SearchBy.put("ByName",1);
		 SearchBy.put("ById",2);
		 SearchBy.put("xpath", 3);
		 SearchBy.put("cssSelector",4);
		 SearchBy.put("linkText", 5);
		 SearchBy.put("className", 6);
		 WebDriverWait wait = new WebDriverWait(driver, Timeout);
	    	Integer ByWhich=SearchBy.get(SearchType);
	    try {
	    	
	    	
	    	
	    	switch(ByWhich){
	    	
	    	case 1: 
	    		
	    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.name(ElementString)));
	    		break;
	    		
	    	case 2: 
	    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(ElementString)));
	    		break;
	    		
	    	case 3: 
	    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ElementString)));
	    		break;
	    		
	    	case 4: 
	    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(ElementString)));
	    		break;
	    		
	    	case 5: 
	    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText(ElementString)));
	    		break;
	    		
	    	case 6: 
	    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className(ElementString)));
	    		break;

	    	
	    	}
	    	
	      return true;
	    } catch (Exception e) {
	    	
	    	if(ElementString.equalsIgnoreCase("generalForm:searchInputText"))
	    	{
	    		
	    		if(driver.findElements( By.xpath("//p[contains(text(),'Your login attempt has failed.')]") ).size() != 0)
	    		{
	    			takeScreenshot();
	    			Assert.assertTrue("Invalid Username/Password", false);
	    			
	    		}
	    		//isElementPresent(driver, 10,"//p[contains(text(),'Your login attempt has failed.')]", "xpath");
	    	}
	    	else if(ElementString.equalsIgnoreCase(container.getCLEisCreatedButton_xpath()))
	    	{
	    		takeScreenshot();
	    		Assert.assertTrue(driver.findElement(By.xpath("//div/table/tbody/tr/td/span")).getText(),false);
	    	}
	    	
	    	else if(ElementString.equalsIgnoreCase(container.getMBACLESearchLink_xpath()))
	    	{
	    		takeScreenshot();
	    		Assert.assertTrue(driver.findElement(By.xpath("//td/div/div/span")).getText(),false);
	    	}
	    	
	    	else if(ElementString.equalsIgnoreCase(container.getCreateCGIResultLabelPassed_css()))
	    	{
	    		takeScreenshot();
	    		Assert.assertTrue(driver.findElement(By.cssSelector(container.getCreateCGIResultLabelFailed_css())).getText(),false);
	    	}
	    	
	    	else if(ElementString.equalsIgnoreCase(container.getCGIUpdateCustomerLegalEntityNameTextBox_xpath()))
	    	{	String PendingLabel=container.getUpdateNamePendingLabel().getText();
	    		
	    		 lines = PendingLabel.split("\\r?\\n");
	    		 for(int i=0; i<lines.length; i++)
	    		 {
	    			 if(lines[i].contains("Pending"))
	    			 {
	    				 Assert.assertTrue(lines[i],false);
	    			 }
	    		 }
	    		 takeScreenshot();
	    	}
	    	
	    	else if(ElementString.equalsIgnoreCase(container.getCGIUpdateCustomerLegalNameConfirmationButton_xpath()))
	    	{
	    		takeScreenshot();
	    		Assert.assertTrue(container.getUpdateNameNoChangesFound().getText(), false);
	    	}
	    	
	    	else if(ElementString.equalsIgnoreCase(container.getCGIUpdateCustomerLegalAddressLine1_xpath()))
	    	{
	    		takeScreenshot();
	    		Assert.assertTrue(container.getUpdateAddressPendingLabel().getText(),false);
	    	}
	    	
	    	else if(ElementString.equalsIgnoreCase(container.getCGIUpdateCustomerLegalAddressConfirmAddressButton_xpath()))
	    	{
	    		takeScreenshot();
	    		Assert.assertTrue(container.getUpdateAddressValidationBeforeSubmit().getText(),false);
	    	}
	    	
	    	else if(ElementString.equalsIgnoreCase(container.getCGIChangeCGIConfirmationTextLabelPassed_css()))
	    	{
	    		takeScreenshot();
	    		Assert.assertTrue(container.getCGIChangeCGIConfirmationTextLabelFailed().getText(),false);
	   		}
	    	
	    	else if(ElementString.equalsIgnoreCase(container.getMBACGIRenameSubmitbutton_xpath(oldCGINamePos)))
	    	{
	    		takeScreenshot();
	    		Assert.assertTrue("Customer Group Identifier to rename not found",false);
	    	}
	    	
	    	else if(ElementString.equalsIgnoreCase(container.getCreateCPNIAddressConfirmButton_xpath()))
	    	{
	    		takeScreenshot();
	    		Assert.assertTrue(container.getCreateCPNIErrorMessage().getText(), false);
	    	}
	    	
	    	else if(ElementString.equalsIgnoreCase(container.getCLEDropDownLittleArrow_xpath()))
	    	{
	    		takeScreenshot();
	    		Assert.assertTrue(container.getCLESearchNotFoundLabel().getText(), false);
	    	}
	    	
	    	else if(ElementString.equalsIgnoreCase(container.getUpdateCLEBasicInfoOperationSucessfullButton_xpath()))
	    	{
	    		takeScreenshot();
	    		Assert.assertTrue(container.getUpdateCLEBasicInfoErrorLabel().getText(), false);
	    	}
	    	
	    	else if(ElementString.equalsIgnoreCase(container.getUpdateDUNSConfirmOperation_xpath()))
	    	{
	    		takeScreenshot();
	    		Assert.assertTrue(container.getUpdateDUNSErrorLabel().getText(), false);
	    	}
	    	
	    	else if(ElementString.equalsIgnoreCase(container.getUpdateDUNSSaveChangesButton_xpath()))
	    	{
	    		takeScreenshot();
	    		Assert.assertTrue(container.getUpdateDUNSErrorLabel().getText(), false);
	    	}
	    	
	    	else if(ElementString.equalsIgnoreCase(container.getCreateAliasOperationSuccessfull_css()))
	    	{
	    		takeScreenshot();
	    		Assert.assertTrue(container.getCreateAliasErrorLabel().getText(),false);
	    	}
	    	
	    	else if(ElementString.equalsIgnoreCase(LVContainer.getSearchCompanyResults_id()))
	    	{
	    		takeScreenshot();
	    		Assert.assertTrue(LVContainer.getLegalViewNoRecordsLabel().getText(),false);
	    	}
	    	
	    	else if(ElementString.equalsIgnoreCase(LVContainer.getSearchBillingResults_id()))
	    	{
	    		takeScreenshot();
	    		Assert.assertTrue(LVContainer.getLegalViewNoRecordsLabel().getText(),false);
	    	}
	    	
	    	else if(ElementString.equalsIgnoreCase(LVContainer.getPaginationSort_id()))
	    	{
	    		takeScreenshot();
	    		Assert.assertTrue("Search result has no more pages to test pagination", false);
	    	}
	    	
	    	else if(ElementString.equalsIgnoreCase(LVContainer.getWorkFlowTaskSearchResults_xpath()))
	    	{
	    		takeScreenshot();
	    		Assert.assertTrue(LVContainer.getWorkFlowTaskNoRecordsLabel().getText(), false);
	    	}
	    	
	    	else if(ElementString.equalsIgnoreCase(LVContainer.getDnBSearchResults_id()))
	    	{
	    		takeScreenshot();
	    		Assert.assertTrue(LVContainer.getDnBNoRecordsLabel().getText(), false);
	    	}
	    	
	    	else if(ElementString.equalsIgnoreCase(SSContainer.getSSBICFound_xpath()))
	    	{
	    		takeScreenshot();
	    		Assert.assertTrue(SSContainer.getSSCustomerNotFoundToaster().getText(), false);
	    	}
	    	
	    	else if(ElementString.equalsIgnoreCase(SVContainer.getNASPIDDeletedConfirmationLabel_css()))
	    	{
	    		takeScreenshot();
	    		Assert.assertTrue(SVContainer.getNASPIDDeletedErrorLabel().getText(), false);
	    	}
	    	
	    	else if(ElementString.equalsIgnoreCase(SSContainer.getSSVECRMScreen_ID()))
	    	{
	    		takeScreenshot();
	    		Assert.assertTrue("Cannot find VECRM Screen", false);
	    	}
	    	
	    	else if(ElementString.equalsIgnoreCase(container.getSign_OnButton_xpath()))
	    	{
	    		takeScreenshot();
	    		
	    		isElementPresent(driver, 10, SSContainer.getSSServiceMgmtReportingScreen_xpath(), "xpath");
	    		//Assert.assertTrue("Cannot find VECRM Screen", false);
	    	}
	    	
	    	else{
	    	
	    		takeScreenshot();
	    	Assert.assertTrue("Page Timeout. Element was not found", false);
	     
	    	}
	    	
	    	return false;
	    }
	  }

	
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
										//TAKE A SCREENSHOT AND SAVE IN FILE//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	public static void takeScreenshot() throws IOException{
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		//Now you can do whatever you need to do with it, for example copy somewhere
		FileUtils.copyFile(scrFile, new File("C:\\Users\\magonzalez\\Desktop\\Selenium TC\\Automation Error Screenshots\\ElementNotFound.png"));
	}
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
										//ACCEPT AND CLOSE ALERT METHOD//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	public static String closeAlertAndGetItsText() {
	    try {
	      Alert alert = driver.switchTo().alert();
	      String alertText = alert.getText();
	      if (acceptNextAlert) {
	        alert.accept();
	      } else {
	        alert.dismiss();
	      }
	      return alertText;
	    } finally {
	      acceptNextAlert = true;
	    }
	  }
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
										//BUILD XPATH FROM ELEMENT LABEL METHOD//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	public static String ConcatenateXpath(String textInside){
		return xPath1+textInside+xPath2;
		
	}
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
										//SWITCH TO A NEW POPUP METHOD//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	public static void switchToPopUp(){
		String parentWindowHandler = driver.getWindowHandle(); 
		String subWindowHandler = null;

		Set<String> handles = driver.getWindowHandles(); 
		Iterator<String> iterator = handles.iterator();
		while (iterator.hasNext()){
		    subWindowHandler = iterator.next();
		}
		driver.switchTo().window(subWindowHandler); 
	}
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
									  //GET CUSTOMER GROUP IDENTIFIER NAMES FROM LIST METHOD//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	public static ArrayList<String> getMBAcustomerGNames() throws IOException
	{
		
		ArrayList<String> CGN = new ArrayList<String>();

		
		isElementPresent(driver, 10, "//tr[@id='generalForm:manageCGIBANTab:0:customerGroupsId:0']/td[2]/span", "xpath");
		int i=0;
		
		while (driver.findElements(By.xpath("//tr[@id='generalForm:manageCGIBANTab:0:customerGroupsId:"+i+"']/td[2]/span")).size() > 0)
		{
			CGN.add(driver.findElement(By.xpath("//tr[@id='generalForm:manageCGIBANTab:0:customerGroupsId:"+i+"']/td[2]/span")).getText());
			i++;
		}
		
		System.out.println(CGN);
		
		return CGN;
		
	}
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
									//GET SPECIFIC CUSTOMER GROUP IDENTIFIER FROM LIST//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	public static String getCGIfromGroup(String CGIName, ArrayList<String> CustomGlobalName){
		
		Integer i=0;
		while(CustomGlobalName.size() != 0){
			if(CGIName.equalsIgnoreCase(CustomGlobalName.get(i)))
			{
				CGIName= i.toString();
				break;
			}
			i++;
			if(i == CustomGlobalName.size())
			{
				System.out.println("El valor de i es "+i);
				Assert.assertTrue("CGI Name not found",false);
			}
			
			
		}
		
		return CGIName;
	}
	
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
											//SWITCH TO CERTAIN WINDOW//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	public static void switchToWindow(String Window)
	{
		driver.switchTo().window(Window);
	}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
											//SELECT ACCOUNT CHECKBOX//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
public static void selectAccount(String AccountNumb) throws IOException
{
	Integer Position = 0;
    
    
    ArrayList<String> Acc = new ArrayList<String>();

	 
	isElementPresent(driver, 10, "//td[2]/div/span", "xpath");
	int i=1;
	
	while (driver.findElements(By.xpath("//tr["+i+"]/td[2]/div/span")).size() > 0)
	{
		Acc.add(driver.findElement(By.xpath("//tr["+i+"]/td[2]/div/span")).getText());
		i++;
	}
	
	if(Acc.contains(AccountNumb))
	{
		for(int j=0; j<Acc.size(); j++)
		{
			if(AccountNumb.equalsIgnoreCase(Acc.get(j)))
			{
				Position = j;
				System.out.print("Account found!!\n");
				driver.findElement(By.xpath("//tr["+Position+1+"]/td/center/input")).click();
			}
		}
		
	}
	
	else {
	System.out.print("Account not found\n");
	}
	
  }
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
											//SWITCH TO NEW FRAME//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public static void switchFrame(WebElement Frame)
	{
		driver.switchTo().frame(Frame);
	}
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
											//GET PARENT FRAME//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public static void getParentFrame(){
		 driver.switchTo().parentFrame();
	}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
											//WAIT FOR PAGE TO LOAD//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public static void waitForPageToLoad(Integer time) throws InterruptedException{
		while(LVContainer.getWindowTitle().equals("Processing...")  || LVContainer.getWindowTitle().contains("Connecting") );
		{
			Thread.sleep(time);
		}
		
	}
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
											  //MAXIMIZE BROWSER//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	public static void maximizeBrowser(){
		 driver.manage().window().maximize();
	}
	
	public void setImplicitWaitTime(int waitTime)
	{
		driver.manage().timeouts().implicitlyWait(waitTime, TimeUnit.SECONDS);
	}
	
	/**
	 * Wait for an arbitrary amount of time
	 * @param millis
	 * @throws InterruptedException
	 */
	public void explicitWait(int millis) throws InterruptedException
	{
		Thread.sleep(millis*1000);
	}
	
	public boolean isAlertPresent() 
	{ 
	    try 
	    { 
	        driver.switchTo().alert().dismiss();;
	        
	        return true; 
	    }   // try 
	    catch (NoAlertPresentException Ex) 
	    { 
	        return false; 
	    }   // catch 
	}   // isAlertPresent()
	public static boolean isWithinRange(Date testDate, Date startDate, Date endDate) {
		   return !(testDate.before(startDate) || testDate.after(endDate));
		}
}
	
	


