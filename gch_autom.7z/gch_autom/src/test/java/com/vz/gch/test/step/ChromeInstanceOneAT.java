package com.vz.gch.test.step;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "features/gchInstance1@Chrome.feature", 
		plugin = {"json:reports/gchInstance1@Chrome.json"},
		monochrome = true)
public class ChromeInstanceOneAT {

}
