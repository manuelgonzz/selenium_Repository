package com.vz.gch.test.step.definitions;

import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;



import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

import  java.sql.Connection;		
import  java.sql.Statement;		
import  java.sql.ResultSet;		
import  java.sql.DriverManager;		
import  java.sql.SQLException;	

public class BrowserConfig {
	


	public static WebDriver driver;
	public static String CLEName;
	

	    @Before("@chrome")
	    public static void setUpChrome() throws InterruptedException {
	    
	    	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\magonzalez\\Desktop\\GCH\\Automation Chrome Driver\\chromedriver.exe");

	    	  driver = new ChromeDriver();
	    	  driver.manage().timeouts().pageLoadTimeout(1200, TimeUnit.SECONDS);
  
	    }
	    
	    @Before("@firefox")
	    public static void setUpFirefox() throws InterruptedException {
	    	
	    	System.setProperty("webdriver.gecko.driver", "C:\\Users\\magonzalez\\Desktop\\GCH\\geckodriver-v0.14.0\\geckodriver-v0.10.0-win64\\geckodriver.exe");
	    	    driver = new FirefoxDriver();
	    	    
	    	    //C:\\Users\\magonzalez\\Desktop\\GCH\\geckodriver-v0.14.0\\geckodriver-v0.10.0-win64\\geckodriver.exe
	    	    //C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe
	    }
	    
	   
	    
	    @After
	    public static void setDownClass() {
	         //driver.quit();
	    	for(String winHandle : driver.getWindowHandles()) {
	            driver.switchTo().window(winHandle);
	            driver.close();
	        }
	    }
	

}
