package com.vz.gch.test.step;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import net.serenitybdd.cucumber.CucumberWithSerenity;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(
		features = "features/gchInstance_NASPTool@firefox.feature", 
		plugin = {"json:reports/gchInstance_NASPTool@firefox.json"},
		monochrome = true)
public class FirefoxInstance_NASPToolAT {

}