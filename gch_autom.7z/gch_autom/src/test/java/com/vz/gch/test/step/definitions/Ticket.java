package com.vz.gch.test.step.definitions;

public class Ticket {

	private String ticketNumber;
	private String pin;
	private String ticketServiceType;
	private String serviceId;
	private String priority;
	
	public Ticket(String ticketNumber, String pin) {
		this.ticketNumber = ticketNumber;
		this.pin = pin;
		this.ticketServiceType = null;
	}
	
	public Ticket(String ticketNumber, String pin, String ticketServiceType) {
		this.ticketNumber = ticketNumber;
		this.pin = pin;
		this.ticketServiceType = ticketServiceType;
	}
	
	public Ticket(String ticketNumber) {
		this.ticketNumber = ticketNumber;
		this.pin = null;
		this.ticketServiceType = null;
	}
	
	public Ticket() {
		this.ticketNumber = null;
		this.pin = null;
		this.ticketServiceType = null;
	}
	
	public void setTicketDetails(String serviceId, String priority){
		this.serviceId = serviceId;
		this.priority = priority;
	}
	
	public void setTicketServiceType(String ticketServiceType){
		this.ticketServiceType = ticketServiceType;
	}
	
	public void setTicketNumber(String ticketNumber){
		this.ticketNumber = ticketNumber;
	}
	
	public void setPin(String pin){
		this.pin = pin;
	}
	
	public String getTicketNumber(){
		return this.ticketNumber;
	}
	
	public String getPin(){
		return this.pin;
	}
	
	public String getTicketServiceType(){
		return this.ticketServiceType;
	}
	
	public String getServiceId(){
		return this.serviceId;
	}
	
	public String getPriority(){
		return this.priority;
	}

}
